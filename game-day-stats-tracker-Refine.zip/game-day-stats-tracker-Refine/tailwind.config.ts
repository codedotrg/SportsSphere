
import type { Config } from "tailwindcss";

export default {
	darkMode: ["class"], // Keep class strategy if ever needed, but default is dark via index.css
	content: [
		"./pages/**/*.{ts,tsx}",
		"./components/**/*.{ts,tsx}",
		"./app/**/*.{ts,tsx}",
		"./src/**/*.{ts,tsx}",
	],
	prefix: "",
	theme: {
		container: {
			center: true,
			padding: '2rem',
			screens: {
				'2xl': '1400px'
			}
		},
		extend: {
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
      },
			colors: {
				border: 'hsl(var(--border))',
				input: 'hsl(var(--input))',
				ring: 'hsl(var(--ring))',
				background: 'hsl(var(--background))',
				foreground: 'hsl(var(--foreground))',
				primary: {
					DEFAULT: 'hsl(var(--primary))',
					foreground: 'hsl(var(--primary-foreground))'
				},
				secondary: {
					DEFAULT: 'hsl(var(--secondary))',
					foreground: 'hsl(var(--secondary-foreground))'
				},
				destructive: {
					DEFAULT: 'hsl(var(--destructive))',
					foreground: 'hsl(var(--destructive-foreground))'
				},
				muted: {
					DEFAULT: 'hsl(var(--muted))',
					foreground: 'hsl(var(--muted-foreground))'
				},
				accent: {
					DEFAULT: 'hsl(var(--accent))',
					foreground: 'hsl(var(--accent-foreground))'
				},
				popover: {
					DEFAULT: 'hsl(var(--popover))',
					foreground: 'hsl(var(--popover-foreground))'
				},
				card: {
					DEFAULT: 'hsl(var(--card))',
					foreground: 'hsl(var(--card-foreground))'
				},
			},
			borderRadius: {
				lg: 'var(--radius)',
				md: 'calc(var(--radius) - 2px)',
				sm: 'calc(var(--radius) - 4px)'
			},
			keyframes: {
				'accordion-down': {
					from: {
						height: '0'
					},
					to: {
						height: 'var(--radix-accordion-content-height)'
					}
				},
				'accordion-up': {
					from: {
						height: 'var(--radix-accordion-content-height)'
					},
					to: {
						height: '0'
					}
				},
        'fade-in-up': {
          '0%': {
            opacity: '0',
            transform: 'translateY(20px)'
          },
          '100%': {
            opacity: '1',
            transform: 'translateY(0)'
          },
        },
        // Sports-inspired animations
        'bounce-sport': {
          '0%, 20%, 53%, 80%, 100%': {
            transform: 'translate3d(0,0,0)'
          },
          '40%, 43%': {
            transform: 'translate3d(0,-15px,0)'
          },
          '70%': {
            transform: 'translate3d(0,-8px,0)'
          },
          '90%': {
            transform: 'translate3d(0,-3px,0)'
          }
        },
        'pulse-energy': {
          '0%': {
            transform: 'scale(1)',
            opacity: '1'
          },
          '100%': {
            transform: 'scale(1.05)',
            opacity: '0.8'
          }
        },
        'slide-victory': {
          '0%': {
            transform: 'translateX(-100%)',
            opacity: '0'
          },
          '100%': {
            transform: 'translateX(0)',
            opacity: '1'
          }
        },
        'shake-action': {
          '0%, 100%': { transform: 'translateX(0)' },
          '10%, 30%, 50%, 70%, 90%': { transform: 'translateX(-2px)' },
          '20%, 40%, 60%, 80%': { transform: 'translateX(2px)' }
        },
        'energy-pulse': {
          '0%': {
            boxShadow: '0 0 0 0 hsl(var(--primary) / 0.7)'
          },
          '70%': {
            boxShadow: '0 0 0 10px hsl(var(--primary) / 0)'
          },
          '100%': {
            boxShadow: '0 0 0 0 hsl(var(--primary) / 0)'
          }
        },
        'trophy-shine': {
          '0%': {
            transform: 'translateX(-100%) translateY(-100%) rotate(45deg)'
          },
          '50%': {
            transform: 'translateX(100%) translateY(100%) rotate(45deg)'
          },
          '100%': {
            transform: 'translateX(-100%) translateY(-100%) rotate(45deg)'
          }
        },
        'loading-sport': {
          '0%': {
            left: '-100%'
          },
          '100%': {
            left: '100%'
          }
        }
			},
			animation: {
				'accordion-down': 'accordion-down 0.2s ease-out',
				'accordion-up': 'accordion-up 0.2s ease-out',
        'fade-in-up': 'fade-in-up 0.5s ease-out forwards',
        // Sports animations
        'bounce-sport': 'bounce-sport 2s infinite',
        'pulse-energy': 'pulse-energy 1.5s ease-in-out infinite alternate',
        'slide-victory': 'slide-victory 0.6s ease-out',
        'shake-action': 'shake-action 0.5s ease-in-out',
        'energy-pulse': 'energy-pulse 2s infinite',
        'trophy-shine': 'trophy-shine 3s infinite',
        'loading-sport': 'loading-sport 1.5s infinite'
			},
      backgroundImage: {
        'sport-gradient': 'var(--gradient-sport)',
        'energy-gradient': 'var(--gradient-energy)',
        'victory-gradient': 'var(--gradient-victory)'
      }
		}
	},
	plugins: [require("tailwindcss-animate")],
} satisfies Config;
