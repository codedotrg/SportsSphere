
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const sportRadarKey = Deno.env.get('SPORT_RADAR_API_KEY')
    
    if (!sportRadarKey) {
      console.log('SPORT_RADAR_API_KEY not configured, using enhanced mock data')
      
      // Enhanced mock data with recent timestamps
      const mockResults = [
        {
          homeTeam: "India",
          awayTeam: "Australia", 
          homeScore: 289,
          awayScore: 295,
          sport: "Cricket",
          date: new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString(), // 6 hours ago
          competition: "Border-Gavaskar Trophy",
          status: "closed",
          format: "Test Match"
        },
        {
          homeTeam: "Mumbai Indians",
          awayTeam: "Chennai Super Kings",
          homeScore: 185,
          awayScore: 189,
          sport: "Cricket", 
          date: new Date(Date.now() - 18 * 60 * 60 * 1000).toISOString(), // 18 hours ago
          competition: "IPL 2024",
          status: "closed",
          format: "T20"
        },
        {
          homeTeam: "England",
          awayTeam: "New Zealand",
          homeScore: 234,
          awayScore: 238,
          sport: "Cricket",
          date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(), // 2 days ago
          competition: "T20 World Cup",
          status: "closed",
          format: "T20"
        },
        {
          homeTeam: "Manchester City",
          awayTeam: "Arsenal",
          homeScore: 2,
          awayScore: 1,
          sport: "Football",
          date: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(), // 3 days ago
          competition: "Premier League",
          status: "closed"
        },
        {
          homeTeam: "Lakers",
          awayTeam: "Warriors",
          homeScore: 112,
          awayScore: 108,
          sport: "Basketball",
          date: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString(), // 4 days ago
          competition: "NBA",
          status: "closed"
        }
      ]
      
      return new Response(
        JSON.stringify({ results: mockResults }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        },
      )
    }

    console.log('Fetching sports fixtures with API key')

    // Fetch recent results from SportRadar
    const response = await fetch(
      `https://api.sportradar.us/soccer/trial/v4/en/tournaments/sr:tournament:17/results.json?api_key=${sportRadarKey}`
    )

    if (!response.ok) {
      console.error(`SportRadar error: ${response.status}`)
      throw new Error(`SportRadar error: ${response.status}`)
    }

    const data = await response.json()
    
    // Filter results to only include recent matches (max 30 days old)
    const thirtyDaysAgo = Date.now() - (30 * 24 * 60 * 60 * 1000)
    
    const formattedResults = data.results?.slice(0, 15)
      .filter((match: any) => new Date(match.scheduled).getTime() > thirtyDaysAgo)
      .map((match: any) => ({
        homeTeam: match.home_competitor?.name || 'Team A',
        awayTeam: match.away_competitor?.name || 'Team B', 
        homeScore: match.home_score || 0,
        awayScore: match.away_score || 0,
        sport: 'Football',
        date: match.scheduled,
        competition: data.tournament?.name || 'Tournament',
        status: match.status
      })) || []

    console.log(`Successfully fetched ${formattedResults.length} recent results`)

    return new Response(
      JSON.stringify({ results: formattedResults }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      },
    )
  } catch (error) {
    console.error('Sports fixtures error:', error)
    
    // Enhanced fallback with recent cricket content
    const mockResults = [
      {
        homeTeam: "India",
        awayTeam: "South Africa",
        homeScore: 278,
        awayScore: 283,
        sport: "Cricket",
        date: new Date(Date.now() - 8 * 60 * 60 * 1000).toISOString(),
        competition: "Test Series",
        status: "closed",
        format: "Test Match"
      },
      {
        homeTeam: "Royal Challengers Bangalore", 
        awayTeam: "Delhi Capitals",
        homeScore: 167,
        awayScore: 171,
        sport: "Cricket",
        date: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
        competition: "IPL 2024",
        status: "closed", 
        format: "T20"
      }
    ]
    
    return new Response(
      JSON.stringify({ results: mockResults }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      },
    )
  }
})
