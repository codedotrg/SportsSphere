
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    const { user_id, message_type } = await req.json()

    const { data, error } = await supabaseClient
      .from('direct_messages')
      .select(`
        *,
        sender:profiles!direct_messages_sender_id_fkey(full_name, email),
        recipient:profiles!direct_messages_recipient_id_fkey(full_name, email)
      `)
      .or(
        message_type === 'received' 
          ? `recipient_id.eq.${user_id}`
          : `sender_id.eq.${user_id}`
      )
      .order('created_at', { ascending: false })

    if (error) throw error

    const processedData = (data || []).map(msg => ({
      ...msg,
      otherUser: message_type === 'received' ? msg.sender : msg.recipient
    }))

    return new Response(
      JSON.stringify(processedData),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
    )
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 },
    )
  }
})
