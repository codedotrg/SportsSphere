
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const newsApiKey = Deno.env.get('NEWS_API_KEY')
    
    if (!newsApiKey) {
      console.log('NEWS_API_KEY not configured, using enhanced cricket-focused mock data')
      
      // Enhanced mock data with more cricket focus and live scores
      const mockNews = [
        {
          title: "India vs Australia Test Series: Virat Kohli Scores Century",
          description: "Virat Kohli's magnificent century puts India in commanding position in the first Test against Australia at Adelaide.",
          url: "https://www.espncricinfo.com/series",
          publishedAt: new Date(Date.now() - 1 * 60 * 60 * 1000).toISOString(), // 1 hour ago
          source: "ESPNCricinfo",
          category: "cricket"
        },
        {
          title: "IPL 2024: Mumbai Indians Beat Chennai Super Kings in Thriller",
          description: "Last-ball finish as Mumbai Indians chase down 182 to beat CSK by 4 wickets in a nail-biting encounter.",
          url: "https://www.iplt20.com/news",
          publishedAt: new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString(), // 3 hours ago
          source: "IPL Official",
          category: "cricket"
        },
        {
          title: "T20 World Cup 2024: England Squad Announced",
          description: "England announces strong squad for upcoming T20 World Cup with Jos Buttler to lead the team.",
          url: "https://www.icc-cricket.com/t20-world-cup",
          publishedAt: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(), // 5 hours ago
          source: "ICC Cricket",
          category: "cricket"
        },
        {
          title: "Pakistan vs New Zealand ODI: Babar Azam's Match-Winning Knock",
          description: "Captain Babar Azam's unbeaten 127 guides Pakistan to a 6-wicket victory over New Zealand in the second ODI.",
          url: "https://www.espncricinfo.com/series",
          publishedAt: new Date(Date.now() - 8 * 60 * 60 * 1000).toISOString(), // 8 hours ago
          source: "ESPNCricinfo",
          category: "cricket"
        },
        {
          title: "Women's Cricket: India Defeats Australia in Final",
          description: "Spectacular bowling performance leads India women to victory over Australia in the tri-series final.",
          url: "https://www.icc-cricket.com/womens-cricket",
          publishedAt: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(), // 12 hours ago
          source: "ICC Cricket",
          category: "cricket"
        },
        {
          title: "Premier League: Manchester City vs Arsenal Clash",
          description: "Title contenders clash as Manchester City hosts Arsenal in a crucial Premier League encounter.",
          url: "https://www.premierleague.com",
          publishedAt: new Date(Date.now() - 18 * 60 * 60 * 1000).toISOString(), // 18 hours ago
          source: "Premier League",
          category: "football"
        },
        {
          title: "NBA: Lakers vs Warriors Showdown Tonight",
          description: "LeBron James and Stephen Curry set for another epic battle as Lakers take on Warriors.",
          url: "https://www.nba.com/news",
          publishedAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(), // 1 day ago
          source: "NBA Official",
          category: "basketball"
        }
      ]
      
      return new Response(
        JSON.stringify({ news: mockNews }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        },
      )
    }

    console.log('Fetching sports news with API key')
    
    // Fetch cricket-focused and general sports news
    const [cricketResponse, sportsResponse] = await Promise.all([
      fetch(`https://newsapi.org/v2/everything?q="cricket" OR "IPL" OR "T20" OR "Test cricket" OR "ODI" OR "ICC" OR "Virat Kohli" OR "Babar Azam" OR "Joe Root"&sortBy=publishedAt&pageSize=15&from=${new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString()}&apiKey=${newsApiKey}`),
      fetch(`https://newsapi.org/v2/everything?q=sports&sortBy=publishedAt&pageSize=10&from=${new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString()}&apiKey=${newsApiKey}`)
    ])

    if (!cricketResponse.ok && !sportsResponse.ok) {
      throw new Error(`NewsAPI error: ${cricketResponse.status} and ${sportsResponse.status}`)
    }

    const [cricketData, sportsData] = await Promise.all([
      cricketResponse.ok ? cricketResponse.json() : { articles: [] },
      sportsResponse.ok ? sportsResponse.json() : { articles: [] }
    ])
    
    // Prioritize cricket articles and combine with other sports
    const cricketArticles = (cricketData.articles || []).map((article: any) => ({
      ...article,
      category: 'cricket'
    }))
    
    const otherSportsArticles = (sportsData.articles || [])
      .filter((article: any) => !article.title.toLowerCase().includes('cricket'))
      .map((article: any) => ({
        ...article,
        category: 'sports'
      }))
    
    // Combine and limit articles
    const allArticles = [
      ...cricketArticles.slice(0, 8), // Prioritize cricket news
      ...otherSportsArticles.slice(0, 4) // Add some other sports
    ]
    
    // Remove duplicates and filter recent articles (max 30 days old)
    const thirtyDaysAgo = Date.now() - (30 * 24 * 60 * 60 * 1000)
    const uniqueArticles = allArticles
      .filter((article, index, self) => 
        index === self.findIndex(a => a.title === article.title)
      )
      .filter(article => new Date(article.publishedAt).getTime() > thirtyDaysAgo)
    
    const formattedNews = uniqueArticles.slice(0, 12).map((article: any) => ({
      title: article.title,
      description: article.description,
      url: article.url,
      publishedAt: article.publishedAt,
      source: article.source.name,
      urlToImage: article.urlToImage,
      category: article.category
    }))

    console.log(`Successfully fetched ${formattedNews.length} recent news articles (${cricketArticles.length} cricket-focused)`)

    return new Response(
      JSON.stringify({ news: formattedNews }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      },
    )
  } catch (error) {
    console.error('Sports news error:', error)
    
    // Enhanced fallback data with cricket focus
    const fallbackNews = [
      {
        title: "Live Cricket Updates: ICC Tournament Latest",
        description: "Stay updated with the latest cricket match results, player performances, and upcoming fixtures from international cricket.",
        url: "https://www.icc-cricket.com",
        publishedAt: new Date(Date.now() - 1 * 60 * 60 * 1000).toISOString(),
        source: "ICC Cricket",
        category: "cricket"
      },
      {
        title: "IPL 2024: Team Performance Analysis and Live Scores",
        description: "Detailed analysis of team performances, player statistics, and live match updates from the current IPL season.",
        url: "https://www.iplt20.com",
        publishedAt: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString(),
        source: "IPL Official",
        category: "cricket"
      }
    ]
    
    return new Response(
      JSON.stringify({ news: fallbackNews }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      },
    )
  }
})
