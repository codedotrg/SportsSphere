
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const weatherApiKey = Deno.env.get('OPENWEATHER_API_KEY')
    
    if (!weatherApiKey) {
      console.log('OPENWEATHER_API_KEY not configured, using mock data')
      // Return mock weather data when API key is not available
      const mockWeather = {
        location: "Your Location",
        temperature: Math.floor(Math.random() * 15) + 15,
        condition: "Partly Cloudy", 
        humidity: Math.floor(Math.random() * 40) + 40,
        windSpeed: Math.floor(Math.random() * 15) + 5,
        icon: "Clouds"
      }
      
      return new Response(
        JSON.stringify({ weather: mockWeather }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        },
      )
    }

    // Get coordinates from request body
    const { lat, lon } = await req.json()
    const latitude = lat || '40.7128'
    const longitude = lon || '-74.0060'

    console.log(`Fetching weather for coordinates: ${latitude}, ${longitude}`)

    const response = await fetch(
      `https://api.openweathermap.org/data/2.5/weather?lat=${latitude}&lon=${longitude}&appid=${weatherApiKey}&units=metric`
    )

    if (!response.ok) {
      console.error(`Weather API error: ${response.status}`)
      throw new Error(`Weather API error: ${response.status}`)
    }

    const data = await response.json()
    
    const weatherData = {
      location: data.name || "Unknown Location",
      temperature: Math.round(data.main?.temp || 20),
      condition: data.weather?.[0]?.description || "Clear",
      humidity: data.main?.humidity || 50,
      windSpeed: Math.round((data.wind?.speed || 0) * 3.6), // Convert m/s to km/h
      icon: data.weather?.[0]?.main || "Clear"
    }

    console.log('Successfully fetched weather data:', weatherData)

    return new Response(
      JSON.stringify({ weather: weatherData }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      },
    )
  } catch (error) {
    console.error('Weather data error:', error)
    
    // Return fallback mock data on error
    const fallbackWeather = {
      location: "Your Location",
      temperature: Math.floor(Math.random() * 15) + 15,
      condition: "Partly Cloudy",
      humidity: Math.floor(Math.random() * 40) + 40, 
      windSpeed: Math.floor(Math.random() * 15) + 5,
      icon: "Clouds"
    }
    
    return new Response(
      JSON.stringify({ weather: fallbackWeather }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      },
    )
  }
})
