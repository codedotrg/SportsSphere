
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const cricketApiKey = Deno.env.get('cricket_api')?.trim()
    
    if (!cricketApiKey) {
      console.log('Cricket API key not found, using mock data')
      return getMockData()
    }

    console.log('Fetching cricket scores with API key:', cricketApiKey.substring(0, 8) + '...')
    
    // Try the main CricAPI endpoint
    const apiUrl = `https://api.cricapi.com/v1/currentMatches?apikey=${cricketApiKey}&offset=0`
    
    console.log('Making request to CricAPI:', apiUrl.replace(cricketApiKey, 'KEY_HIDDEN'))
    
    const response = await fetch(apiUrl, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'User-Agent': 'SportsApp/1.0'
      },
      // Add timeout to prevent hanging
      signal: AbortSignal.timeout(15000) // 15 second timeout
    })
    
    console.log('API Response Status:', response.status)
    console.log('API Response Headers:', Object.fromEntries(response.headers.entries()))
    
    if (!response.ok) {
      const errorText = await response.text()
      console.log('API Error Response:', errorText)
      
      if (response.status === 401) {
        console.log('API Key authentication failed - check if key is valid')
        throw new Error('Invalid API key - please verify your cricket API key')
      } else if (response.status === 429) {
        console.log('API rate limit exceeded')
        throw new Error('API rate limit exceeded - try again later')
      } else if (response.status === 402) {
        console.log('API payment required - check subscription status')
        throw new Error('API subscription required - upgrade your plan')
      }
      
      throw new Error(`API Error: ${response.status} - ${errorText}`)
    }

    const data = await response.json()
    console.log('API Response received, processing data...')
    console.log('Raw API data structure:', JSON.stringify(data, null, 2).substring(0, 1000) + '...')

    if (!data) {
      console.log('Invalid API response structure: null data')
      throw new Error('Invalid API response structure')
    }

    // Handle different response structures
    let matches = []
    if (data.data && Array.isArray(data.data)) {
      matches = data.data
    } else if (Array.isArray(data)) {
      matches = data
    } else if (data.matches && Array.isArray(data.matches)) {
      matches = data.matches
    } else {
      console.log('No matches array found in response:', Object.keys(data))
      throw new Error('No matches found in API response')
    }

    console.log(`Found ${matches.length} matches from API`)
    
    if (matches.length === 0) {
      console.log('No matches found from API, using enhanced fallback data')
      return getEnhancedFallbackData()
    }

    const formattedScores = matches.slice(0, 6).map((match: any) => {
      console.log('Processing match:', match.name || match.title || 'Unknown match')
      
      return {
        match: match.name || match.title || `${match.teamInfo?.[0]?.name || 'Team 1'} vs ${match.teamInfo?.[1]?.name || 'Team 2'}`,
        status: getMatchStatus(match),
        score: formatMatchScore(match),
        result: getMatchResult(match),
        venue: match.venue || match.ground || 'TBD',
        format: match.matchType || match.format || match.type || 'Unknown'
      }
    })

    console.log(`Successfully processed ${formattedScores.length} cricket scores`)

    return new Response(
      JSON.stringify({ 
        scores: formattedScores,
        source: 'CricAPI Live',
        timestamp: new Date().toISOString(),
        success: true,
        total_matches: matches.length
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      },
    )

  } catch (error) {
    console.error('Cricket scores error:', error.message)
    console.error('Error details:', error)
    
    return getEnhancedFallbackData()
  }
})

function getMatchStatus(match: any): string {
  if (match.status) return match.status
  if (match.matchStatus) return match.matchStatus
  if (match.state) return match.state
  if (match.matchStarted && match.matchEnded) return 'Finished'
  if (match.matchStarted && !match.matchEnded) return 'Live'
  return 'Upcoming'
}

function formatMatchScore(match: any): string {
  // Handle different score formats from CricAPI
  if (match.score && match.score.length > 0) {
    const scores = match.score
    if (scores.length >= 2) {
      const team1Score = `${scores[0]?.inning || 'Team 1'}: ${scores[0]?.r || 0}/${scores[0]?.w || 0}`
      const team2Score = `${scores[1]?.inning || 'Team 2'}: ${scores[1]?.r || 0}/${scores[1]?.w || 0}`
      return `${team1Score} | ${team2Score}`
    } else if (scores.length === 1) {
      return `${scores[0]?.inning || 'Current'}: ${scores[0]?.r || 0}/${scores[0]?.w || 0} (${scores[0]?.o || 0} ov)`
    }
  }
  
  // Alternative score format
  if (match.teams && match.teams.length >= 2) {
    const team1 = match.teams[0]
    const team2 = match.teams[1]
    if (team1.score && team2.score) {
      return `${team1.name}: ${team1.score} | ${team2.name}: ${team2.score}`
    }
  }

  // Check for teamInfo with scores
  if (match.teamInfo && match.teamInfo.length >= 2) {
    const team1 = match.teamInfo[0]
    const team2 = match.teamInfo[1]
    if (team1.score || team2.score) {
      return `${team1.name}: ${team1.score || '0/0'} | ${team2.name}: ${team2.score || '0/0'}`
    }
  }
  
  return 'Score updating...'
}

function getMatchResult(match: any): string {
  if (match.status === 'Match not started') return 'Upcoming match'
  if (match.status?.includes('won')) return match.status
  if (match.matchWinner) return `${match.matchWinner} won`
  if (match.result) return match.result
  if (match.status?.toLowerCase().includes('live')) return 'Match in progress'
  if (match.status?.toLowerCase().includes('finished')) return 'Match completed'
  return match.status || 'Status updating...'
}

function getMockData() {
  const mockScores = [
    {
      match: "India vs Australia - 1st Test",
      status: "Day 2, Session 2",
      score: "IND: 245/4 (78.2 ov)",
      result: "India trailing by 89 runs",
      venue: "Adelaide Oval",
      format: "Test"
    },
    {
      match: "England vs New Zealand - ODI",
      status: "Match Finished",
      score: "ENG: 287/5 | NZ: 291/7",
      result: "New Zealand won by 3 wickets",
      venue: "Lord's",
      format: "ODI"
    },
    {
      match: "Mumbai Indians vs CSK - IPL",
      status: "Live",
      score: "MI: 156/6 (18.4 ov)",
      result: "Target: 182 runs",
      venue: "Wankhede Stadium",
      format: "T20"
    }
  ]
  
  return new Response(
    JSON.stringify({ 
      scores: mockScores,
      source: 'Mock Data',
      note: 'API key not configured',
      success: false
    }),
    {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    },
  )
}

function getEnhancedFallbackData() {
  const fallbackScores = [
    {
      match: "India vs Australia - BGT 2024",
      status: "Live - Day 2",
      score: "IND: 280/5 (85.4 ov) | AUS: 320/8d",
      result: "Australia leads by 40 runs",
      venue: "Melbourne Cricket Ground",
      format: "Test"
    },
    {
      match: "England vs Pakistan - ODI Series",
      status: "Live",
      score: "ENG: 156/4 (28.3 ov)",
      result: "Chasing 275 runs",
      venue: "The Oval",
      format: "ODI"
    },
    {
      match: "CSK vs MI - IPL 2024",
      status: "Match Finished",
      score: "CSK: 182/4 | MI: 186/6",
      result: "Mumbai Indians won by 4 wickets",
      venue: "Wankhede Stadium",
      format: "T20"
    },
    {
      match: "SA vs WI - T20I",
      status: "Upcoming",
      score: "Match starts in 2 hours",
      result: "Toss at 6:30 PM IST",
      venue: "SuperSport Park",
      format: "T20I"
    }
  ]
  
  return new Response(
    JSON.stringify({ 
      scores: fallbackScores,
      source: 'Enhanced Fallback',
      error: 'API temporarily unavailable',
      success: false,
      timestamp: new Date().toISOString()
    }),
    {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    },
  )
}
