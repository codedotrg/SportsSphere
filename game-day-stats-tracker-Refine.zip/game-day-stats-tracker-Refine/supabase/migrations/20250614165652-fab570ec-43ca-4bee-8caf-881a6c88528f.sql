
-- Create team join requests table
CREATE TABLE public.team_join_requests (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  team_formation_id uuid NOT NULL REFERENCES public.team_formations(id) ON DELETE CASCADE,
  player_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  message text,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  requested_at timestamp with time zone NOT NULL DEFAULT now(),
  responded_at timestamp with time zone,
  responded_by uuid REFERENCES public.profiles(id),
  UNIQUE(team_formation_id, player_id)
);

-- Create messages table for team/event communication
CREATE TABLE public.messages (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  event_id uuid NOT NULL REFERENCES public.events(id) ON DELETE CASCADE,
  sender_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  recipient_id uuid REFERENCES public.profiles(id) ON DELETE CASCADE,
  message_type text NOT NULL DEFAULT 'general' CHECK (message_type IN ('general', 'team_request', 'join_request')),
  content text NOT NULL,
  team_formation_id uuid REFERENCES public.team_formations(id) ON DELETE CASCADE,
  is_read boolean NOT NULL DEFAULT false,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Create event join requests table
CREATE TABLE public.event_join_requests (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  event_id uuid NOT NULL REFERENCES public.events(id) ON DELETE CASCADE,
  player_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  message text,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  requested_at timestamp with time zone NOT NULL DEFAULT now(),
  responded_at timestamp with time zone,
  responded_by uuid REFERENCES public.profiles(id),
  UNIQUE(event_id, player_id)
);

-- Enable RLS on new tables
ALTER TABLE public.team_join_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.event_join_requests ENABLE ROW LEVEL SECURITY;

-- RLS policies for team_join_requests
CREATE POLICY "Users can view requests involving them" 
  ON public.team_join_requests 
  FOR SELECT 
  USING (
    player_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM public.team_formations tf 
      WHERE tf.id = team_join_requests.team_formation_id AND tf.created_by = auth.uid()
    ) OR
    EXISTS (
      SELECT 1 FROM public.team_formations tf
      JOIN public.events e ON e.id = tf.event_id
      WHERE tf.id = team_join_requests.team_formation_id AND e.organizer_id = auth.uid()
    )
  );

CREATE POLICY "Users can create join requests" 
  ON public.team_join_requests 
  FOR INSERT 
  WITH CHECK (player_id = auth.uid());

CREATE POLICY "Team creators and event organizers can update requests" 
  ON public.team_join_requests 
  FOR UPDATE 
  USING (
    EXISTS (
      SELECT 1 FROM public.team_formations tf 
      WHERE tf.id = team_formation_id AND tf.created_by = auth.uid()
    ) OR
    EXISTS (
      SELECT 1 FROM public.team_formations tf
      JOIN public.events e ON e.id = tf.event_id
      WHERE tf.id = team_formation_id AND e.organizer_id = auth.uid()
    )
  );

-- RLS policies for messages
CREATE POLICY "Users can view messages they sent or received" 
  ON public.messages 
  FOR SELECT 
  USING (
    sender_id = auth.uid() OR 
    recipient_id = auth.uid() OR
    (recipient_id IS NULL AND EXISTS (
      SELECT 1 FROM public.event_participants ep 
      WHERE ep.event_id = messages.event_id AND ep.player_id = auth.uid()
    ))
  );

CREATE POLICY "Users can send messages" 
  ON public.messages 
  FOR INSERT 
  WITH CHECK (sender_id = auth.uid());

CREATE POLICY "Users can update their own messages" 
  ON public.messages 
  FOR UPDATE 
  USING (sender_id = auth.uid() OR recipient_id = auth.uid());

-- RLS policies for event_join_requests
CREATE POLICY "Users can view event join requests involving them" 
  ON public.event_join_requests 
  FOR SELECT 
  USING (
    player_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM public.events e 
      WHERE e.id = event_join_requests.event_id AND e.organizer_id = auth.uid()
    )
  );

CREATE POLICY "Users can create event join requests" 
  ON public.event_join_requests 
  FOR INSERT 
  WITH CHECK (player_id = auth.uid());

CREATE POLICY "Event organizers can update join requests" 
  ON public.event_join_requests 
  FOR UPDATE 
  USING (
    EXISTS (
      SELECT 1 FROM public.events e 
      WHERE e.id = event_id AND e.organizer_id = auth.uid()
    )
  );

-- Create indexes for better performance
CREATE INDEX idx_team_join_requests_team_id ON public.team_join_requests(team_formation_id);
CREATE INDEX idx_team_join_requests_player_id ON public.team_join_requests(player_id);
CREATE INDEX idx_messages_event_id ON public.messages(event_id);
CREATE INDEX idx_messages_sender_id ON public.messages(sender_id);
CREATE INDEX idx_messages_recipient_id ON public.messages(recipient_id);
CREATE INDEX idx_event_join_requests_event_id ON public.event_join_requests(event_id);
CREATE INDEX idx_event_join_requests_player_id ON public.event_join_requests(player_id);
