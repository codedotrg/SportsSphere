
-- Create player_requirements table
CREATE TABLE public.player_requirements (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  event_id UUID NOT NULL REFERENCES public.events(id) ON DELETE CASCADE,
  role_name TEXT NOT NULL,
  description TEXT,
  experience_level TEXT,
  max_players INTEGER,
  created_by UUID NOT NULL REFERENCES public.profiles(id),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.player_requirements ENABLE ROW LEVEL SECURITY;

-- Create policies for player requirements
CREATE POLICY "Users can view all player requirements" 
  ON public.player_requirements 
  FOR SELECT 
  USING (true);

CREATE POLICY "Event organizers can create requirements for their events" 
  ON public.player_requirements 
  FOR INSERT 
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.events 
      WHERE id = event_id AND organizer_id = auth.uid()
    )
  );

CREATE POLICY "Event organizers can update requirements for their events" 
  ON public.player_requirements 
  FOR UPDATE 
  USING (
    EXISTS (
      SELECT 1 FROM public.events 
      WHERE id = event_id AND organizer_id = auth.uid()
    )
  );

CREATE POLICY "Event organizers can delete requirements for their events" 
  ON public.player_requirements 
  FOR DELETE 
  USING (
    EXISTS (
      SELECT 1 FROM public.events 
      WHERE id = event_id AND organizer_id = auth.uid()
    )
  );
