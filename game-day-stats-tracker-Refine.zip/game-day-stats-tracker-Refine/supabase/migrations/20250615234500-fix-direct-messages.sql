
-- Fix the messages table constraint to properly support direct messages
ALTER TABLE public.messages 
DROP CONSTRAINT IF EXISTS messages_either_event_or_direct;

-- Add the correct constraint for message validation
ALTER TABLE public.messages 
ADD CONSTRAINT messages_either_event_or_direct CHECK (
  (event_id IS NOT NULL AND message_type IN ('general', 'announcement', 'team_request', 'join_request')) OR
  (event_id IS NULL AND message_type = 'direct' AND recipient_id IS NOT NULL)
);

-- Update the message notification function to handle direct messages correctly
CREATE OR REPLACE FUNCTION public.create_message_notification()
RETURNS TRIGGER AS $$
DECLARE
  sender_name TEXT;
BEGIN
  -- Only create notifications for direct messages
  IF NEW.message_type = 'direct' AND NEW.recipient_id IS NOT NULL AND NEW.event_id IS NULL THEN
    -- Get sender name
    SELECT p.full_name INTO sender_name
    FROM public.profiles p 
    WHERE p.id = NEW.sender_id;
    
    -- Create notification for recipient
    INSERT INTO public.notifications (user_id, type, title, content, related_id)
    VALUES (
      NEW.recipient_id,
      'message',
      'New Message',
      COALESCE(sender_name, 'Someone') || ' sent you a message',
      NEW.id
    );
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
