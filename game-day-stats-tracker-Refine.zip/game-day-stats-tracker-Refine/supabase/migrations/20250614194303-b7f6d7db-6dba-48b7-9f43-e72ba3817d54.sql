
-- Drop existing policies if they exist to avoid conflicts
DROP POLICY IF EXISTS "Users can view their own messages" ON public.messages;
DROP POLICY IF EXISTS "Users can send messages" ON public.messages;
DROP POLICY IF EXISTS "Users can update their own messages" ON public.messages;
DROP POLICY IF EXISTS "Users can view their own notifications" ON public.notifications;
DROP POLICY IF EXISTS "Users can update their own notifications" ON public.notifications;
DROP POLICY IF EXISTS "Users can delete their own notifications" ON public.notifications;
DROP POLICY IF EXISTS "Users can view follows" ON public.user_follows;
DROP POLICY IF EXISTS "Users can create follows" ON public.user_follows;
DROP POLICY IF EXISTS "Users can delete their own follows" ON public.user_follows;

-- Drop existing trigger and function if they exist
DROP TRIGGER IF EXISTS message_notification_trigger ON public.messages;
DROP FUNCTION IF EXISTS public.create_message_notification();

-- First, let's ensure the messages table supports direct messaging properly
ALTER TABLE public.messages 
ALTER COLUMN event_id DROP NOT NULL;

-- Add constraint for message validation
ALTER TABLE public.messages 
DROP CONSTRAINT IF EXISTS messages_either_event_or_direct;

ALTER TABLE public.messages 
ADD CONSTRAINT messages_either_event_or_direct CHECK (
  (event_id IS NOT NULL AND message_type IN ('general', 'announcement')) OR
  (event_id IS NULL AND message_type = 'direct' AND recipient_id IS NOT NULL)
);

-- Enable RLS on all tables
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_follows ENABLE ROW LEVEL SECURITY;

-- Create policies for messages table
CREATE POLICY "Users can view their own messages" ON public.messages
FOR SELECT USING (
  auth.uid() = sender_id OR 
  auth.uid() = recipient_id OR
  (event_id IS NOT NULL AND EXISTS (
    SELECT 1 FROM event_participants 
    WHERE event_id = messages.event_id AND player_id = auth.uid()
  ))
);

CREATE POLICY "Users can send messages" ON public.messages
FOR INSERT WITH CHECK (auth.uid() = sender_id);

CREATE POLICY "Users can update their own messages" ON public.messages
FOR UPDATE USING (auth.uid() = recipient_id OR auth.uid() = sender_id);

-- Create policies for notifications table
CREATE POLICY "Users can view their own notifications" ON public.notifications
FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own notifications" ON public.notifications
FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own notifications" ON public.notifications
FOR DELETE USING (auth.uid() = user_id);

-- Create policies for user_follows table
CREATE POLICY "Users can view follows" ON public.user_follows
FOR SELECT USING (
  auth.uid() = follower_id OR 
  auth.uid() = following_id
);

CREATE POLICY "Users can create follows" ON public.user_follows
FOR INSERT WITH CHECK (auth.uid() = follower_id);

CREATE POLICY "Users can delete their own follows" ON public.user_follows
FOR DELETE USING (auth.uid() = follower_id);

-- Create function to automatically create message notifications
CREATE OR REPLACE FUNCTION public.create_message_notification()
RETURNS TRIGGER AS $$
DECLARE
  sender_name TEXT;
BEGIN
  -- Only create notifications for direct messages
  IF NEW.message_type = 'direct' AND NEW.recipient_id IS NOT NULL THEN
    -- Get sender name
    SELECT p.full_name INTO sender_name
    FROM public.profiles p 
    WHERE p.id = NEW.sender_id;
    
    -- Create notification for recipient
    INSERT INTO public.notifications (user_id, type, title, content, related_id)
    VALUES (
      NEW.recipient_id,
      'message',
      'New Message',
      COALESCE(sender_name, 'Someone') || ' sent you a message',
      NEW.id
    );
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for message notifications
CREATE TRIGGER message_notification_trigger
  AFTER INSERT ON public.messages
  FOR EACH ROW EXECUTE FUNCTION public.create_message_notification();
