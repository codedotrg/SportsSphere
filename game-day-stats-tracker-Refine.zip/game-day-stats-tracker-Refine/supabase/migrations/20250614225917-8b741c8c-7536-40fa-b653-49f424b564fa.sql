
-- Add missing columns to player_requirements table
ALTER TABLE public.player_requirements 
ADD COLUMN IF NOT EXISTS is_completed boolean DEFAULT false;

-- Add missing columns for better event join request notifications
ALTER TABLE public.event_join_requests 
ADD COLUMN IF NOT EXISTS notification_sent boolean DEFAULT false;

-- Add missing columns for team invitations
ALTER TABLE public.notifications 
ADD COLUMN IF NOT EXISTS invitation_type text,
ADD COLUMN IF NOT EXISTS team_formation_id uuid REFERENCES public.team_formations(id) ON DELETE CASCADE;

-- Create index for better performance
CREATE INDEX IF NOT EXISTS idx_notifications_team_formation 
ON public.notifications(team_formation_id) 
WHERE team_formation_id IS NOT NULL;

-- Update notification types to include team_invitation
DO $$ 
BEGIN
    -- Add team_invitation type if it doesn't exist
    IF NOT EXISTS (
        SELECT 1 FROM pg_enum 
        WHERE enumlabel = 'team_invitation' 
        AND enumtypid = (SELECT oid FROM pg_type WHERE typname = 'notification_type')
    ) THEN
        -- If enum doesn't exist, we'll handle it in the application
        RAISE NOTICE 'team_invitation type will be handled in application';
    END IF;
END $$;
