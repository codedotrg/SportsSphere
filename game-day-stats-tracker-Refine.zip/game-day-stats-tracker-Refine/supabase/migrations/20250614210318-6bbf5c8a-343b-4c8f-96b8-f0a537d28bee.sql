
-- Create table for team chemistry tracking
CREATE TABLE public.team_chemistry (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  team_formation_id UUID NOT NULL,
  player1_id UUID NOT NULL,
  player2_id UUID NOT NULL,
  chemistry_score INTEGER DEFAULT 50 CHECK (chemistry_score >= 0 AND chemistry_score <= 100),
  games_played_together INTEGER DEFAULT 0,
  positive_interactions INTEGER DEFAULT 0,
  negative_interactions INTEGER DEFAULT 0,
  last_interaction_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(team_formation_id, player1_id, player2_id)
);

-- Create table for mentorship program
CREATE TABLE public.mentorship_relationships (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  mentor_id UUID NOT NULL,
  mentee_id UUID NOT NULL,
  sport TEXT,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'active', 'completed', 'cancelled')),
  started_at TIMESTAMP WITH TIME ZONE,
  completed_at TIMESTAMP WITH TIME ZONE,
  mentor_rating INTEGER CHECK (mentor_rating >= 1 AND mentor_rating <= 5),
  mentee_rating INTEGER CHECK (mentee_rating >= 1 AND mentee_rating <= 5),
  feedback TEXT,
  goals TEXT[],
  progress JSONB DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(mentor_id, mentee_id)
);

-- Create table for player skill assessments
CREATE TABLE public.player_skills (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  player_id UUID NOT NULL,
  sport TEXT NOT NULL,
  skill_type TEXT NOT NULL, -- 'technical', 'tactical', 'physical', 'mental'
  skill_name TEXT NOT NULL, -- 'passing', 'shooting', 'endurance', etc.
  skill_level INTEGER NOT NULL CHECK (skill_level >= 1 AND skill_level <= 10),
  verified_by UUID, -- ID of player who verified this skill
  verified_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(player_id, sport, skill_name)
);

-- Create table for player endorsements
CREATE TABLE public.player_endorsements (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  endorser_id UUID NOT NULL,
  endorsed_id UUID NOT NULL,
  endorsement_type TEXT NOT NULL, -- 'skill', 'teamwork', 'leadership', 'sportsmanship'
  skill_name TEXT, -- specific skill being endorsed
  comment TEXT,
  strength_rating INTEGER CHECK (strength_rating >= 1 AND strength_rating <= 5),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(endorser_id, endorsed_id, endorsement_type, skill_name)
);

-- Create table for social challenges
CREATE TABLE public.social_challenges (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  created_by UUID NOT NULL,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  challenge_type TEXT NOT NULL, -- 'individual', 'team', 'community'
  sport TEXT,
  difficulty_level TEXT NOT NULL CHECK (difficulty_level IN ('easy', 'medium', 'hard')),
  points_reward INTEGER DEFAULT 0,
  start_date TIMESTAMP WITH TIME ZONE NOT NULL,
  end_date TIMESTAMP WITH TIME ZONE NOT NULL,
  max_participants INTEGER,
  requirements JSONB DEFAULT '{}',
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create table for challenge participation
CREATE TABLE public.challenge_participants (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  challenge_id UUID NOT NULL,
  participant_id UUID NOT NULL,
  team_formation_id UUID, -- for team challenges
  joined_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  completed_at TIMESTAMP WITH TIME ZONE,
  progress JSONB DEFAULT '{}',
  final_score INTEGER,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'completed', 'dropped')),
  UNIQUE(challenge_id, participant_id)
);

-- Create table for player connections (enhanced networking)
CREATE TABLE public.player_connections (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  player1_id UUID NOT NULL,
  player2_id UUID NOT NULL,
  connection_strength INTEGER DEFAULT 1 CHECK (connection_strength >= 1 AND connection_strength <= 5),
  common_sports TEXT[],
  events_together INTEGER DEFAULT 0,
  messages_exchanged INTEGER DEFAULT 0,
  last_interaction_at TIMESTAMP WITH TIME ZONE,
  connection_notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(player1_id, player2_id)
);

-- Create table for player availability
CREATE TABLE public.player_availability (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  player_id UUID NOT NULL,
  day_of_week INTEGER NOT NULL CHECK (day_of_week >= 0 AND day_of_week <= 6), -- 0 = Sunday
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  timezone TEXT DEFAULT 'UTC',
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Add RLS policies for team_chemistry
ALTER TABLE public.team_chemistry ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Team members can view their team chemistry" 
  ON public.team_chemistry 
  FOR SELECT 
  USING (
    EXISTS (
      SELECT 1 FROM public.team_members tm
      WHERE tm.team_formation_id = team_chemistry.team_formation_id 
      AND tm.player_id = auth.uid()
    )
  );

CREATE POLICY "Team members can update their team chemistry" 
  ON public.team_chemistry 
  FOR INSERT 
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.team_members tm
      WHERE tm.team_formation_id = team_chemistry.team_formation_id 
      AND tm.player_id = auth.uid()
    )
  );

-- Add RLS policies for mentorship_relationships
ALTER TABLE public.mentorship_relationships ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their mentorship relationships" 
  ON public.mentorship_relationships 
  FOR SELECT 
  USING (auth.uid() = mentor_id OR auth.uid() = mentee_id);

CREATE POLICY "Users can create mentorship relationships as mentor" 
  ON public.mentorship_relationships 
  FOR INSERT 
  WITH CHECK (auth.uid() = mentor_id);

CREATE POLICY "Users can update their mentorship relationships" 
  ON public.mentorship_relationships 
  FOR UPDATE 
  USING (auth.uid() = mentor_id OR auth.uid() = mentee_id);

-- Add RLS policies for player_skills
ALTER TABLE public.player_skills ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view player skills" 
  ON public.player_skills 
  FOR SELECT 
  USING (true);

CREATE POLICY "Users can create their own skills" 
  ON public.player_skills 
  FOR INSERT 
  WITH CHECK (auth.uid() = player_id);

CREATE POLICY "Users can update their own skills or verify others" 
  ON public.player_skills 
  FOR UPDATE 
  USING (auth.uid() = player_id OR auth.uid() = verified_by);

-- Add RLS policies for player_endorsements
ALTER TABLE public.player_endorsements ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view endorsements" 
  ON public.player_endorsements 
  FOR SELECT 
  USING (true);

CREATE POLICY "Users can create endorsements for others" 
  ON public.player_endorsements 
  FOR INSERT 
  WITH CHECK (auth.uid() = endorser_id AND endorser_id != endorsed_id);

-- Add RLS policies for social_challenges
ALTER TABLE public.social_challenges ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view active challenges" 
  ON public.social_challenges 
  FOR SELECT 
  USING (is_active = true);

CREATE POLICY "Users can create challenges" 
  ON public.social_challenges 
  FOR INSERT 
  WITH CHECK (auth.uid() = created_by);

CREATE POLICY "Challenge creators can update their challenges" 
  ON public.social_challenges 
  FOR UPDATE 
  USING (auth.uid() = created_by);

-- Add RLS policies for challenge_participants
ALTER TABLE public.challenge_participants ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their challenge participation" 
  ON public.challenge_participants 
  FOR SELECT 
  USING (auth.uid() = participant_id);

CREATE POLICY "Users can join challenges" 
  ON public.challenge_participants 
  FOR INSERT 
  WITH CHECK (auth.uid() = participant_id);

CREATE POLICY "Users can update their challenge participation" 
  ON public.challenge_participants 
  FOR UPDATE 
  USING (auth.uid() = participant_id);

-- Add RLS policies for player_connections
ALTER TABLE public.player_connections ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their connections" 
  ON public.player_connections 
  FOR SELECT 
  USING (auth.uid() = player1_id OR auth.uid() = player2_id);

CREATE POLICY "Users can create connections" 
  ON public.player_connections 
  FOR INSERT 
  WITH CHECK (auth.uid() = player1_id OR auth.uid() = player2_id);

CREATE POLICY "Users can update their connections" 
  ON public.player_connections 
  FOR UPDATE 
  USING (auth.uid() = player1_id OR auth.uid() = player2_id);

-- Add RLS policies for player_availability
ALTER TABLE public.player_availability ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view others' availability" 
  ON public.player_availability 
  FOR SELECT 
  USING (is_active = true);

CREATE POLICY "Users can manage their own availability" 
  ON public.player_availability 
  FOR ALL 
  USING (auth.uid() = player_id);

-- Create function to calculate team chemistry
CREATE OR REPLACE FUNCTION public.calculate_team_chemistry(
  _team_formation_id UUID,
  _player1_id UUID,
  _player2_id UUID
) RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  chemistry_score INTEGER;
  games_together INTEGER;
  positive_ratio DECIMAL;
BEGIN
  SELECT 
    COALESCE(tc.chemistry_score, 50),
    COALESCE(tc.games_played_together, 0),
    CASE 
      WHEN (tc.positive_interactions + tc.negative_interactions) > 0 
      THEN tc.positive_interactions::decimal / (tc.positive_interactions + tc.negative_interactions)
      ELSE 0.5
    END
  INTO chemistry_score, games_together, positive_ratio
  FROM public.team_chemistry tc
  WHERE tc.team_formation_id = _team_formation_id
    AND ((tc.player1_id = _player1_id AND tc.player2_id = _player2_id)
         OR (tc.player1_id = _player2_id AND tc.player2_id = _player1_id));
  
  -- Calculate new chemistry score based on games played and interaction ratio
  chemistry_score := LEAST(100, 
    chemistry_score + 
    (games_together * 2) + 
    ((positive_ratio - 0.5) * 20)::INTEGER
  );
  
  RETURN GREATEST(0, chemistry_score);
END;
$$;

-- Create function to update connection strength
CREATE OR REPLACE FUNCTION public.update_connection_strength(
  _player1_id UUID,
  _player2_id UUID
) RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  events_count INTEGER;
  messages_count INTEGER;
  new_strength INTEGER;
BEGIN
  -- Count events played together
  SELECT COUNT(DISTINCT ep1.event_id)
  INTO events_count
  FROM public.event_participants ep1
  JOIN public.event_participants ep2 ON ep1.event_id = ep2.event_id
  WHERE ep1.player_id = _player1_id AND ep2.player_id = _player2_id;
  
  -- Count messages exchanged
  SELECT COUNT(*)
  INTO messages_count
  FROM public.messages
  WHERE (sender_id = _player1_id AND recipient_id = _player2_id)
     OR (sender_id = _player2_id AND recipient_id = _player1_id);
  
  -- Calculate new strength (1-5 scale)
  new_strength := LEAST(5, 
    1 + 
    (events_count / 3) + 
    (messages_count / 10)
  );
  
  -- Upsert connection record
  INSERT INTO public.player_connections (
    player1_id, player2_id, connection_strength, events_together, messages_exchanged, last_interaction_at
  ) VALUES (
    LEAST(_player1_id, _player2_id),
    GREATEST(_player1_id, _player2_id),
    new_strength,
    events_count,
    messages_count,
    now()
  )
  ON CONFLICT (player1_id, player2_id)
  DO UPDATE SET
    connection_strength = new_strength,
    events_together = events_count,
    messages_exchanged = messages_count,
    last_interaction_at = now(),
    updated_at = now();
END;
$$;
