
-- Update the handle_new_user function to set a default role when none is provided
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $function$
BEGIN
  -- Extract role from raw_app_meta_data, default to 'player' if not provided
  -- Assumes role is passed during sign_up in options.data
  INSERT INTO public.profiles (id, full_name, email, role)
  VALUES (
    NEW.id,
    NEW.raw_user_meta_data ->> 'full_name', -- Expect full_name in meta_data
    NEW.email,
    COALESCE((NEW.raw_app_meta_data ->> 'role')::public.app_role, 'player'::public.app_role) -- Default to 'player' if no role provided
  );
  RETURN NEW;
END;
$function$
