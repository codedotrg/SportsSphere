
-- First, drop all RLS policies that depend on the role column
DROP POLICY IF EXISTS "Organizers can add participants to their events." ON public.event_participants;
DROP POLICY IF EXISTS "Organizers can create events." ON public.events;
DROP POLICY IF EXISTS "Organizers can create ratings for players in their events." ON public.ratings;
DROP POLICY IF EXISTS "Organizers can delete ratings they gave." ON public.ratings;
DROP POLICY IF EXISTS "Organizers can delete their own events." ON public.events;
DROP POLICY IF EXISTS "Organizers can remove participants from their events." ON public.event_participants;
DROP POLICY IF EXISTS "Organizers can update ratings they gave." ON public.ratings;
DROP POLICY IF EXISTS "Organizers can update their own events." ON public.events;
DROP POLICY IF EXISTS "Players can join events." ON public.event_participants;
DROP POLICY IF EXISTS "Players can leave events (delete their participation)." ON public.event_participants;

-- Now remove the role column from profiles table
ALTER TABLE public.profiles DROP COLUMN IF EXISTS role;

-- Drop the app_role enum since we no longer need it
DROP TYPE IF EXISTS public.app_role CASCADE;

-- Update the handle_new_user function to not include role
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $function$
BEGIN
  INSERT INTO public.profiles (id, full_name, email)
  VALUES (
    NEW.id,
    NEW.raw_user_meta_data ->> 'full_name',
    NEW.email
  );
  RETURN NEW;
END;
$function$;

-- Create simplified RLS policies for the unified user type
-- Users can view all events
CREATE POLICY "Users can view all events" ON public.events FOR SELECT USING (true);

-- Users can create events
CREATE POLICY "Users can create events" ON public.events FOR INSERT WITH CHECK (auth.uid() = organizer_id);

-- Users can update their own events
CREATE POLICY "Users can update their own events" ON public.events FOR UPDATE USING (auth.uid() = organizer_id);

-- Users can delete their own events
CREATE POLICY "Users can delete their own events" ON public.events FOR DELETE USING (auth.uid() = organizer_id);

-- Users can view all event participants
CREATE POLICY "Users can view all event participants" ON public.event_participants FOR SELECT USING (true);

-- Users can join events
CREATE POLICY "Users can join events" ON public.event_participants FOR INSERT WITH CHECK (auth.uid() = player_id);

-- Users can leave events they joined
CREATE POLICY "Users can leave events they joined" ON public.event_participants FOR DELETE USING (auth.uid() = player_id);

-- Users can view all ratings
CREATE POLICY "Users can view all ratings" ON public.ratings FOR SELECT USING (true);

-- Users can create ratings
CREATE POLICY "Users can create ratings" ON public.ratings FOR INSERT WITH CHECK (auth.uid() = rater_id);

-- Users can update their own ratings
CREATE POLICY "Users can update their own ratings" ON public.ratings FOR UPDATE USING (auth.uid() = rater_id);

-- Users can delete their own ratings
CREATE POLICY "Users can delete their own ratings" ON public.ratings FOR DELETE USING (auth.uid() = rater_id);
