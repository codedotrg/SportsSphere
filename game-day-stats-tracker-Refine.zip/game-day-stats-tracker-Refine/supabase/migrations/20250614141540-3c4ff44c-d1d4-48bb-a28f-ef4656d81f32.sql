
-- Add location column and remove separate address fields
ALTER TABLE public.profiles 
ADD COLUMN location TEXT;

-- Copy existing address data to location field (combining address, city, state)
UPDATE public.profiles 
SET location = CONCAT_WS(', ', 
  NULLIF(address, ''), 
  NULLIF(city, ''), 
  NULLIF(state, '')
)
WHERE address IS NOT NULL OR city IS NOT NULL OR state IS NOT NULL;

-- Remove the old address columns
ALTER TABLE public.profiles 
DROP COLUMN address,
DROP COLUMN city,
DROP COLUMN state;
