
-- Add gender field to the profiles table
ALTER TABLE public.profiles 
ADD COLUMN gender TEXT;
