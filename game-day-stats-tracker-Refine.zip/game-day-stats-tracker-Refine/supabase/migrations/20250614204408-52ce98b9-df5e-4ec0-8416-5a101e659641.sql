
-- Create table for user activities (for activity feed)
CREATE TABLE public.user_activities (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  activity_type TEXT NOT NULL, -- 'event_joined', 'event_created', 'message_sent', 'profile_updated', etc.
  description TEXT NOT NULL,
  related_id UUID, -- ID of related entity (event_id, message_id, etc.)
  metadata JSONB, -- Additional activity data
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create table for achievements system
CREATE TABLE public.achievements (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT NOT NULL,
  icon TEXT, -- Icon name or URL
  category TEXT NOT NULL, -- 'social', 'events', 'activity', etc.
  points INTEGER DEFAULT 0,
  criteria JSONB, -- Conditions to unlock achievement
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create table for user achievements
CREATE TABLE public.user_achievements (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  achievement_id UUID NOT NULL,
  earned_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id, achievement_id)
);

-- Create table for user preferences (for smart recommendations)
CREATE TABLE public.user_preferences (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL UNIQUE,
  preferred_sports TEXT[], -- Array of preferred sports
  skill_level TEXT, -- 'beginner', 'intermediate', 'advanced'
  max_distance INTEGER, -- Maximum distance in km for events
  notification_settings JSONB, -- Notification preferences
  calendar_sync_enabled BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create table for message attachments
CREATE TABLE public.message_attachments (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  message_id UUID NOT NULL,
  file_name TEXT NOT NULL,
  file_type TEXT NOT NULL, -- 'image', 'document', etc.
  file_size INTEGER,
  storage_path TEXT NOT NULL, -- Path in Supabase storage
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Add RLS policies for user_activities
ALTER TABLE public.user_activities ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own activities and followed users activities" 
  ON public.user_activities 
  FOR SELECT 
  USING (
    auth.uid() = user_id OR 
    EXISTS (
      SELECT 1 FROM public.user_follows 
      WHERE follower_id = auth.uid() AND following_id = user_id
    )
  );

CREATE POLICY "Users can create their own activities" 
  ON public.user_activities 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

-- Add RLS policies for achievements
ALTER TABLE public.achievements ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view achievements" 
  ON public.achievements 
  FOR SELECT 
  USING (true);

-- Add RLS policies for user_achievements
ALTER TABLE public.user_achievements ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view all user achievements" 
  ON public.user_achievements 
  FOR SELECT 
  USING (true);

CREATE POLICY "Users can create their own achievements" 
  ON public.user_achievements 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

-- Add RLS policies for user_preferences
ALTER TABLE public.user_preferences ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own preferences" 
  ON public.user_preferences 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own preferences" 
  ON public.user_preferences 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own preferences" 
  ON public.user_preferences 
  FOR UPDATE 
  USING (auth.uid() = user_id);

-- Add RLS policies for message_attachments
ALTER TABLE public.message_attachments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view attachments of their messages" 
  ON public.message_attachments 
  FOR SELECT 
  USING (
    EXISTS (
      SELECT 1 FROM public.messages 
      WHERE id = message_id AND (sender_id = auth.uid() OR recipient_id = auth.uid())
    )
  );

CREATE POLICY "Users can create attachments for their messages" 
  ON public.message_attachments 
  FOR INSERT 
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.messages 
      WHERE id = message_id AND sender_id = auth.uid()
    )
  );

-- Create storage bucket for message attachments
INSERT INTO storage.buckets (id, name, public) 
VALUES ('message-attachments', 'message-attachments', false);

-- Create storage policies for message attachments
CREATE POLICY "Users can upload their own message attachments"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'message-attachments' AND
  auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Users can view message attachments they have access to"
ON storage.objects FOR SELECT
USING (
  bucket_id = 'message-attachments' AND (
    auth.uid()::text = (storage.foldername(name))[1] OR
    EXISTS (
      SELECT 1 FROM public.message_attachments ma
      JOIN public.messages m ON ma.message_id = m.id
      WHERE ma.storage_path = name AND (m.sender_id = auth.uid() OR m.recipient_id = auth.uid())
    )
  )
);

-- Insert some sample achievements
INSERT INTO public.achievements (name, description, icon, category, points, criteria) VALUES
('First Event', 'Join your first sports event', 'Trophy', 'events', 10, '{"events_joined": 1}'),
('Social Butterfly', 'Send 10 messages to other players', 'MessageCircle', 'social', 15, '{"messages_sent": 10}'),
('Event Organizer', 'Create your first event', 'Calendar', 'events', 20, '{"events_created": 1}'),
('Team Player', 'Join 5 different teams', 'Users', 'social', 25, '{"teams_joined": 5}'),
('Active Player', 'Participate in 10 events', 'Zap', 'activity', 50, '{"events_participated": 10}');
