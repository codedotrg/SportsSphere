
-- Create missing tables first
CREATE TABLE IF NOT EXISTS public.ai_matchmaking_preferences (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  preferred_skill_level text,
  preferred_age_range int4range,
  max_distance_km integer DEFAULT 50,
  preferred_play_times jsonb DEFAULT '[]'::jsonb,
  ai_personality_match boolean DEFAULT true,
  preferred_sports text[] DEFAULT '{}',
  avoid_users uuid[] DEFAULT '{}',
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now(),
  UNIQUE(user_id)
);

CREATE TABLE IF NOT EXISTS public.player_performance_stats (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  player_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  event_id uuid REFERENCES public.events(id) ON DELETE SET NULL,
  sport text NOT NULL,
  performance_metrics jsonb DEFAULT '{}'::jsonb,
  individual_rating integer DEFAULT 0,
  recorded_by uuid NOT NULL REFERENCES auth.users(id),
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.smart_schedules (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  schedule_data jsonb DEFAULT '{}'::jsonb,
  preferences jsonb DEFAULT '{}'::jsonb,
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now()
);

-- Now create the functions
CREATE OR REPLACE FUNCTION public.get_user_preferences(p_user_id uuid)
RETURNS TABLE (
  id uuid,
  user_id uuid,
  preferred_skill_level text,
  preferred_age_range int4range,
  max_distance_km integer,
  preferred_play_times jsonb,
  ai_personality_match boolean,
  preferred_sports text[],
  avoid_users uuid[]
)
LANGUAGE sql
SECURITY DEFINER
AS $$
  SELECT 
    amp.id,
    amp.user_id,
    amp.preferred_skill_level,
    amp.preferred_age_range,
    amp.max_distance_km,
    amp.preferred_play_times,
    amp.ai_personality_match,
    amp.preferred_sports,
    amp.avoid_users
  FROM public.ai_matchmaking_preferences amp
  WHERE amp.user_id = p_user_id;
$$;

CREATE OR REPLACE FUNCTION public.upsert_ai_preferences(
  p_user_id uuid,
  p_preferences jsonb
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  INSERT INTO public.ai_matchmaking_preferences (
    user_id,
    preferred_skill_level,
    max_distance_km,
    preferred_play_times,
    ai_personality_match,
    preferred_sports,
    avoid_users
  ) VALUES (
    p_user_id,
    COALESCE((p_preferences->>'preferred_skill_level')::text, null),
    COALESCE((p_preferences->>'max_distance_km')::integer, 50),
    COALESCE(p_preferences->'preferred_play_times', '[]'::jsonb),
    COALESCE((p_preferences->>'ai_personality_match')::boolean, true),
    CASE 
      WHEN p_preferences->'preferred_sports' IS NOT NULL 
      THEN ARRAY(SELECT jsonb_array_elements_text(p_preferences->'preferred_sports'))
      ELSE '{}'::text[]
    END,
    CASE 
      WHEN p_preferences->'avoid_users' IS NOT NULL 
      THEN ARRAY(SELECT (jsonb_array_elements_text(p_preferences->'avoid_users'))::uuid)
      ELSE '{}'::uuid[]
    END
  )
  ON CONFLICT (user_id)
  DO UPDATE SET
    preferred_skill_level = EXCLUDED.preferred_skill_level,
    max_distance_km = EXCLUDED.max_distance_km,
    preferred_play_times = EXCLUDED.preferred_play_times,
    ai_personality_match = EXCLUDED.ai_personality_match,
    preferred_sports = EXCLUDED.preferred_sports,
    avoid_users = EXCLUDED.avoid_users,
    updated_at = now();
END;
$$;

CREATE OR REPLACE FUNCTION public.save_performance_stats(
  p_player_id uuid,
  p_event_id text,
  p_sport text,
  p_metrics jsonb,
  p_individual_rating integer,
  p_recorded_by uuid
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  event_uuid uuid;
BEGIN
  BEGIN
    event_uuid := p_event_id::uuid;
  EXCEPTION
    WHEN invalid_text_representation THEN
      event_uuid := null;
  END;
  
  INSERT INTO public.player_performance_stats (
    player_id,
    event_id,
    sport,
    performance_metrics,
    individual_rating,
    recorded_by
  ) VALUES (
    p_player_id,
    event_uuid,
    p_sport,
    p_metrics,
    p_individual_rating,
    p_recorded_by
  );
END;
$$;

-- Enable RLS and create policies
ALTER TABLE public.ai_matchmaking_preferences ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.player_performance_stats ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.smart_schedules ENABLE ROW LEVEL SECURITY;

-- Policies for ai_matchmaking_preferences
CREATE POLICY "Users can view their own AI preferences" ON public.ai_matchmaking_preferences
FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own AI preferences" ON public.ai_matchmaking_preferences
FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own AI preferences" ON public.ai_matchmaking_preferences
FOR UPDATE USING (auth.uid() = user_id);

-- Policies for player_performance_stats
CREATE POLICY "Users can view all performance stats" ON public.player_performance_stats
FOR SELECT USING (true);

CREATE POLICY "Users can insert performance stats" ON public.player_performance_stats
FOR INSERT WITH CHECK (auth.uid() = recorded_by);

-- Policies for smart_schedules
CREATE POLICY "Users can view their own smart schedules" ON public.smart_schedules
FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own smart schedules" ON public.smart_schedules
FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own smart schedules" ON public.smart_schedules
FOR UPDATE USING (auth.uid() = user_id);
