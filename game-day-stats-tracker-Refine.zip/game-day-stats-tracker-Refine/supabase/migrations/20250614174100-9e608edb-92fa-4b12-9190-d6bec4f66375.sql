
-- Create user_follows table for the follow system
CREATE TABLE public.user_follows (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  follower_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  following_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(follower_id, following_id),
  CHECK (follower_id != following_id)
);

-- Add RLS policies for user_follows
ALTER TABLE public.user_follows ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view follows they are involved in" 
  ON public.user_follows 
  FOR SELECT 
  USING (auth.uid() = follower_id OR auth.uid() = following_id);

CREATE POLICY "Users can create follows" 
  ON public.user_follows 
  FOR INSERT 
  WITH CHECK (auth.uid() = follower_id);

CREATE POLICY "Users can delete their own follows" 
  ON public.user_follows 
  FOR DELETE 
  USING (auth.uid() = follower_id);

-- Add missing columns to team_formations table
ALTER TABLE public.team_formations 
ADD COLUMN IF NOT EXISTS description TEXT,
ADD COLUMN IF NOT EXISTS max_members INTEGER DEFAULT 5;

-- Create notifications table for enhanced messaging
CREATE TABLE public.notifications (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  type TEXT NOT NULL CHECK (type IN ('event_join_request', 'team_join_request', 'follow', 'message', 'event_invite')),
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  related_id UUID, -- Can reference events, teams, users, etc.
  is_read BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Add RLS policies for notifications
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own notifications" 
  ON public.notifications 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own notifications" 
  ON public.notifications 
  FOR UPDATE 
  USING (auth.uid() = user_id);

-- Add indexes for better performance
CREATE INDEX idx_user_follows_follower ON public.user_follows(follower_id);
CREATE INDEX idx_user_follows_following ON public.user_follows(following_id);
CREATE INDEX idx_notifications_user_id ON public.notifications(user_id);
CREATE INDEX idx_notifications_type ON public.notifications(type);
CREATE INDEX idx_notifications_is_read ON public.notifications(is_read);

-- Create function to create notifications for event join requests
CREATE OR REPLACE FUNCTION public.create_event_join_request_notification()
RETURNS TRIGGER AS $$
DECLARE
  organizer_id UUID;
  event_title TEXT;
  requester_name TEXT;
BEGIN
  -- Get event organizer and title
  SELECT e.organizer_id, e.title INTO organizer_id, event_title
  FROM public.events e 
  WHERE e.id = NEW.event_id;
  
  -- Get requester name
  SELECT p.full_name INTO requester_name
  FROM public.profiles p 
  WHERE p.id = NEW.player_id;
  
  -- Create notification for organizer
  INSERT INTO public.notifications (user_id, type, title, content, related_id)
  VALUES (
    organizer_id,
    'event_join_request',
    'New Event Join Request',
    requester_name || ' has requested to join your event "' || event_title || '"',
    NEW.event_id
  );
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for event join request notifications
CREATE TRIGGER on_event_join_request_created
  AFTER INSERT ON public.event_join_requests
  FOR EACH ROW
  EXECUTE FUNCTION public.create_event_join_request_notification();

-- Create function to create notifications for team join requests
CREATE OR REPLACE FUNCTION public.create_team_join_request_notification()
RETURNS TRIGGER AS $$
DECLARE
  team_creator_id UUID;
  team_name TEXT;
  requester_name TEXT;
BEGIN
  -- Get team creator and name
  SELECT tf.created_by, tf.team_name INTO team_creator_id, team_name
  FROM public.team_formations tf 
  WHERE tf.id = NEW.team_formation_id;
  
  -- Get requester name
  SELECT p.full_name INTO requester_name
  FROM public.profiles p 
  WHERE p.id = NEW.player_id;
  
  -- Create notification for team creator
  INSERT INTO public.notifications (user_id, type, title, content, related_id)
  VALUES (
    team_creator_id,
    'team_join_request',
    'New Team Join Request',
    requester_name || ' has requested to join your team "' || team_name || '"',
    NEW.team_formation_id
  );
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for team join request notifications
CREATE TRIGGER on_team_join_request_created
  AFTER INSERT ON public.team_join_requests
  FOR EACH ROW
  EXECUTE FUNCTION public.create_team_join_request_notification();

-- Create function to create follow notifications
CREATE OR REPLACE FUNCTION public.create_follow_notification()
RETURNS TRIGGER AS $$
DECLARE
  follower_name TEXT;
BEGIN
  -- Get follower name
  SELECT p.full_name INTO follower_name
  FROM public.profiles p 
  WHERE p.id = NEW.follower_id;
  
  -- Create notification for the person being followed
  INSERT INTO public.notifications (user_id, type, title, content, related_id)
  VALUES (
    NEW.following_id,
    'follow',
    'New Follower',
    follower_name || ' started following you',
    NEW.follower_id
  );
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for follow notifications
CREATE TRIGGER on_follow_created
  AFTER INSERT ON public.user_follows
  FOR EACH ROW
  EXECUTE FUNCTION public.create_follow_notification();
