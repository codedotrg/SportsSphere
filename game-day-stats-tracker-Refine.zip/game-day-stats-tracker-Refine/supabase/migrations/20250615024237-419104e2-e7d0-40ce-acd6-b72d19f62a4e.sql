
-- Fix the syntax error and enable RLS on the remaining table
ALTER TABLE public.ai_matchmaking_preferences ENABLE ROW LEVEL SECURITY;

-- Create the missing AI matchmaking preferences policies
CREATE POLICY "Users can manage their own AI preferences" 
  ON public.ai_matchmaking_preferences 
  FOR ALL 
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);
