
-- Update RLS policies for messages to properly handle direct messages
DROP POLICY IF EXISTS "Users can view their own messages" ON public.messages;
DROP POLICY IF EXISTS "Users can send messages" ON public.messages;
DROP POLICY IF EXISTS "Users can update their own messages" ON public.messages;

-- Create updated policies for messages
CREATE POLICY "Users can view their own messages" ON public.messages
FOR SELECT USING (
  -- Can view if they're the sender or recipient
  auth.uid() = sender_id OR 
  auth.uid() = recipient_id OR
  -- Can view event messages if they're a participant
  (event_id IS NOT NULL AND EXISTS (
    SELECT 1 FROM event_participants 
    WHERE event_id = messages.event_id AND player_id = auth.uid()
  ))
);

CREATE POLICY "Users can send messages" ON public.messages
FOR INSERT WITH CHECK (
  auth.uid() = sender_id AND
  (
    -- For direct messages: must have recipient and no event
    (message_type = 'direct' AND recipient_id IS NOT NULL AND event_id IS NULL) OR
    -- For event messages: must have event and proper message type
    (event_id IS NOT NULL AND message_type IN ('general', 'announcement', 'team_request', 'join_request'))
  )
);

CREATE POLICY "Users can update their own messages" ON public.messages
FOR UPDATE USING (
  -- Recipients can mark as read
  (auth.uid() = recipient_id AND is_read IS DISTINCT FROM OLD.is_read) OR
  -- Senders can update their own messages
  auth.uid() = sender_id
);
