
-- Add player ratings and reviews system
CREATE TABLE public.player_ratings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  rater_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  rated_player_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  event_id UUID NOT NULL REFERENCES public.events(id) ON DELETE CASCADE,
  rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
  review TEXT,
  skills_rating INTEGER CHECK (skills_rating >= 1 AND skills_rating <= 5),
  teamwork_rating INTEGER CHECK (teamwork_rating >= 1 AND teamwork_rating <= 5),
  sportsmanship_rating INTEGER CHECK (sportsmanship_rating >= 1 AND sportsmanship_rating <= 5),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(rater_id, rated_player_id, event_id)
);

-- Add event participation status tracking
ALTER TABLE public.event_participants 
ADD COLUMN status TEXT DEFAULT 'joined' CHECK (status IN ('joined', 'pending', 'declined', 'waitlist'));

-- Add team formations table
CREATE TABLE public.team_formations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  event_id UUID NOT NULL REFERENCES public.events(id) ON DELETE CASCADE,
  team_name TEXT NOT NULL,
  formation_type TEXT, -- e.g., "4-4-2", "3-5-2" for football
  created_by UUID NOT NULL REFERENCES public.profiles(id),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Add team members table
CREATE TABLE public.team_members (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  team_formation_id UUID NOT NULL REFERENCES public.team_formations(id) ON DELETE CASCADE,
  player_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  position TEXT,
  is_captain BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(team_formation_id, player_id)
);

-- Add event announcements table
CREATE TABLE public.event_announcements (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  event_id UUID NOT NULL REFERENCES public.events(id) ON DELETE CASCADE,
  author_id UUID NOT NULL REFERENCES public.profiles(id),
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  is_important BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on all new tables
ALTER TABLE public.player_ratings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.team_formations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.team_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.event_announcements ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for player_ratings
CREATE POLICY "Users can view all ratings" 
  ON public.player_ratings 
  FOR SELECT 
  USING (true);

CREATE POLICY "Users can rate players they played with" 
  ON public.player_ratings 
  FOR INSERT 
  WITH CHECK (
    auth.uid() = rater_id AND
    EXISTS (
      SELECT 1 FROM public.event_participants ep1
      WHERE ep1.event_id = player_ratings.event_id 
      AND ep1.player_id = auth.uid()
    ) AND
    EXISTS (
      SELECT 1 FROM public.event_participants ep2
      WHERE ep2.event_id = player_ratings.event_id 
      AND ep2.player_id = player_ratings.rated_player_id
    )
  );

CREATE POLICY "Users can update their own ratings" 
  ON public.player_ratings 
  FOR UPDATE 
  USING (auth.uid() = rater_id);

-- Create RLS policies for team_formations
CREATE POLICY "Users can view team formations for events they participate in" 
  ON public.team_formations 
  FOR SELECT 
  USING (
    EXISTS (
      SELECT 1 FROM public.event_participants 
      WHERE event_id = team_formations.event_id 
      AND player_id = auth.uid()
    ) OR 
    EXISTS (
      SELECT 1 FROM public.events 
      WHERE id = team_formations.event_id 
      AND organizer_id = auth.uid()
    )
  );

CREATE POLICY "Event organizers can create team formations" 
  ON public.team_formations 
  FOR INSERT 
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.events 
      WHERE id = event_id AND organizer_id = auth.uid()
    )
  );

-- Create RLS policies for team_members
CREATE POLICY "Users can view team members for events they participate in" 
  ON public.team_members 
  FOR SELECT 
  USING (
    EXISTS (
      SELECT 1 FROM public.team_formations tf
      JOIN public.event_participants ep ON ep.event_id = tf.event_id
      WHERE tf.id = team_members.team_formation_id 
      AND ep.player_id = auth.uid()
    ) OR
    EXISTS (
      SELECT 1 FROM public.team_formations tf
      JOIN public.events e ON e.id = tf.event_id
      WHERE tf.id = team_members.team_formation_id 
      AND e.organizer_id = auth.uid()
    )
  );

-- Create RLS policies for event_announcements
CREATE POLICY "Users can view announcements for events they participate in" 
  ON public.event_announcements 
  FOR SELECT 
  USING (
    EXISTS (
      SELECT 1 FROM public.event_participants 
      WHERE event_id = event_announcements.event_id 
      AND player_id = auth.uid()
    ) OR 
    EXISTS (
      SELECT 1 FROM public.events 
      WHERE id = event_announcements.event_id 
      AND organizer_id = auth.uid()
    )
  );

CREATE POLICY "Event organizers can create announcements" 
  ON public.event_announcements 
  FOR INSERT 
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.events 
      WHERE id = event_id AND organizer_id = auth.uid()
    )
  );
