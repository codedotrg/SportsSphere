
-- Fix the messages table constraint to properly support direct messages
ALTER TABLE public.messages 
DROP CONSTRAINT IF EXISTS messages_either_event_or_direct;

-- Add the correct constraint for message validation
ALTER TABLE public.messages 
ADD CONSTRAINT messages_either_event_or_direct CHECK (
  (event_id IS NOT NULL AND message_type IN ('general', 'announcement', 'team_request', 'join_request')) OR
  (event_id IS NULL AND message_type = 'direct' AND recipient_id IS NOT NULL)
);

-- Update the message notification function to handle direct messages correctly
CREATE OR REPLACE FUNCTION public.create_message_notification()
RETURNS TRIGGER AS $$
DECLARE
  sender_name TEXT;
BEGIN
  -- Only create notifications for direct messages
  IF NEW.message_type = 'direct' AND NEW.recipient_id IS NOT NULL AND NEW.event_id IS NULL THEN
    -- Get sender name
    SELECT p.full_name INTO sender_name
    FROM public.profiles p 
    WHERE p.id = NEW.sender_id;
    
    -- Create notification for recipient
    INSERT INTO public.notifications (user_id, type, title, content, related_id)
    VALUES (
      NEW.recipient_id,
      'message',
      'New Message',
      COALESCE(sender_name, 'Someone') || ' sent you a message',
      NEW.id
    );
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Update RLS policies for messages to properly handle direct messages
DROP POLICY IF EXISTS "Users can view their own messages" ON public.messages;
DROP POLICY IF EXISTS "Users can send messages" ON public.messages;
DROP POLICY IF EXISTS "Users can update their own messages" ON public.messages;

-- Create updated policies for messages
CREATE POLICY "Users can view their own messages" ON public.messages
FOR SELECT USING (
  -- Can view if they're the sender or recipient
  auth.uid() = sender_id OR 
  auth.uid() = recipient_id OR
  -- Can view event messages if they're a participant
  (event_id IS NOT NULL AND EXISTS (
    SELECT 1 FROM event_participants 
    WHERE event_id = messages.event_id AND player_id = auth.uid()
  ))
);

CREATE POLICY "Users can send messages" ON public.messages
FOR INSERT WITH CHECK (
  auth.uid() = sender_id AND
  (
    -- For direct messages: must have recipient and no event
    (message_type = 'direct' AND recipient_id IS NOT NULL AND event_id IS NULL) OR
    -- For event messages: must have event and proper message type
    (event_id IS NOT NULL AND message_type IN ('general', 'announcement', 'team_request', 'join_request'))
  )
);

CREATE POLICY "Users can update their own messages" ON public.messages
FOR UPDATE USING (
  -- Recipients can mark messages as read
  auth.uid() = recipient_id OR
  -- Senders can update their own messages
  auth.uid() = sender_id
);
