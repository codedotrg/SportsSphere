
-- First, let's check and fix the message_type constraint
ALTER TABLE public.messages 
DROP CONSTRAINT IF EXISTS messages_message_type_check;

-- Add the correct constraint that includes 'direct' message type
ALTER TABLE public.messages 
ADD CONSTRAINT messages_message_type_check CHECK (
  message_type IN ('general', 'announcement', 'team_request', 'join_request', 'direct')
);

-- Create the trigger for message notifications if it doesn't exist
DROP TRIGGER IF EXISTS create_message_notification_trigger ON public.messages;
CREATE TRIGGER create_message_notification_trigger
  AFTER INSERT ON public.messages
  FOR EACH ROW
  EXECUTE FUNCTION public.create_message_notification();
