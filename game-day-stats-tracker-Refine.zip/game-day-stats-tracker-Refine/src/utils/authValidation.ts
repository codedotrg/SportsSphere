
interface AuthFormData {
  email: string;
  password: string;
  confirmPassword?: string;
  fullName?: string;
}

export const validateAuthInput = (data: AuthFormData): string | null => {
  // Email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(data.email)) {
    return 'Please enter a valid email address';
  }

  // Password validation
  if (data.password.length < 8) {
    return 'Password must be at least 8 characters long';
  }

  if (!/(?=.*[a-z])/.test(data.password)) {
    return 'Password must contain at least one lowercase letter';
  }

  if (!/(?=.*[A-Z])/.test(data.password)) {
    return 'Password must contain at least one uppercase letter';
  }

  if (!/(?=.*\d)/.test(data.password)) {
    return 'Password must contain at least one number';
  }

  if (!/(?=.*[!@#$%^&*(),.?":{}|<>])/.test(data.password)) {
    return 'Password must contain at least one special character';
  }

  // Confirm password validation (for signup)
  if (data.confirmPassword !== undefined && data.password !== data.confirmPassword) {
    return 'Passwords do not match';
  }

  // Full name validation (for signup)
  if (data.fullName !== undefined) {
    if (!data.fullName.trim()) {
      return 'Full name is required';
    }
    if (data.fullName.length > 100) {
      return 'Full name must be less than 100 characters';
    }
  }

  return null;
};
