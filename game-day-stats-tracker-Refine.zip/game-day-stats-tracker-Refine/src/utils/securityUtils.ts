
// Security utility functions for monitoring and logging

export const logSecurityEvent = (event: string, details: any, severity: 'low' | 'medium' | 'high' = 'medium') => {
  console.log(`[SECURITY ${severity.toUpperCase()}] ${event}:`, {
    timestamp: new Date().toISOString(),
    details,
    userAgent: navigator.userAgent,
    url: window.location.href
  });
  
  // In production, you would send this to your security monitoring service
  if (severity === 'high') {
    console.warn('HIGH SEVERITY SECURITY EVENT DETECTED');
  }
};

export const logInputValidationFailure = (field: string, value: string, reason: string) => {
  logSecurityEvent('Input Validation Failure', {
    field,
    valueLength: value.length,
    reason,
    valuePreview: value.substring(0, 50) + (value.length > 50 ? '...' : '')
  }, 'medium');
};

export const logAuthenticationEvent = (event: 'login_attempt' | 'login_success' | 'login_failure' | 'signup_attempt' | 'signup_success' | 'signup_failure', email?: string) => {
  logSecurityEvent('Authentication Event', {
    event,
    email: email ? email.substring(0, 3) + '***' : 'unknown' // Partial email for privacy
  }, event.includes('failure') ? 'high' : 'low');
};

export const detectSuspiciousInput = (input: string): boolean => {
  const suspiciousPatterns = [
    /<script[^>]*>.*?<\/script>/gi,
    /javascript:/gi,
    /on\w+\s*=/gi,
    /eval\s*\(/gi,
    /document\.cookie/gi,
    /window\.location/gi,
    /<iframe[^>]*>/gi,
    /data:text\/html/gi,
    /vbscript:/gi,
    /expression\s*\(/gi,
    /url\s*\(/gi,
    /@import/gi,
    /behavior:/gi,
    /binding:/gi,
    /-moz-binding/gi,
    /\\x[0-9a-fA-F]{2}/gi,
    /&#x/gi,
    /\x3c/gi,
    /\x3e/gi,
    /\x22/gi,
    /\x27/gi,
    /\x2f/gi,
    /\x5c/gi,
    /\x00/gi
  ];

  for (const pattern of suspiciousPatterns) {
    if (pattern.test(input)) {
      logInputValidationFailure('suspicious_content', input, `Matched pattern: ${pattern.source}`);
      return true;
    }
  }

  return false;
};

export const validateCSRFToken = (): boolean => {
  // In a real application, you would implement CSRF token validation here
  // For now, we'll just return true since Supabase handles CSRF protection
  return true;
};

export const sanitizeForDisplay = (input: string): string => {
  return input
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;')
    .replace(/\//g, '&#x2F;');
};

// Content Security Policy helpers
export const isValidImageUrl = (url: string): boolean => {
  if (!url || typeof url !== 'string') return false;
  
  try {
    const parsedUrl = new URL(url);
    const allowedDomains = [
      window.location.hostname,
      'supabase.co',
      'githubusercontent.com',
      'gravatar.com',
      'unsplash.com'
    ];
    
    return allowedDomains.some(domain => 
      parsedUrl.hostname === domain || parsedUrl.hostname.endsWith('.' + domain)
    );
  } catch {
    return false;
  }
};

// Session security
export const validateSession = (): boolean => {
  try {
    const sessionStorage = window.sessionStorage;
    const localStorage = window.localStorage;
    
    // Check for session tampering
    const expectedOrigin = window.location.origin;
    if (document.referrer && !document.referrer.startsWith(expectedOrigin)) {
      logSecurityEvent('Suspicious referrer detected', { referrer: document.referrer }, 'medium');
    }
    
    return true;
  } catch (error) {
    logSecurityEvent('Session validation error', { error }, 'high');
    return false;
  }
};

// XSS protection helpers
export const createSecureElement = (tagName: string, textContent?: string): HTMLElement => {
  const element = document.createElement(tagName);
  if (textContent) {
    element.textContent = textContent; // Use textContent instead of innerHTML
  }
  return element;
};
