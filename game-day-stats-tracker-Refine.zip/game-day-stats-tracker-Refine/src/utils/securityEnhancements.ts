
import { supabase } from '@/integrations/supabase/client';

// Enhanced rate limiting with IP tracking
interface RateLimitEntry {
  count: number;
  resetTime: number;
  ip?: string;
}

const rateLimitStorage = new Map<string, RateLimitEntry>();

export const enhancedRateLimit = (
  key: string, 
  maxAttempts: number, 
  windowMs: number,
  includeIP = false
): boolean => {
  const now = Date.now();
  const fullKey = includeIP ? `${key}_${getClientIP()}` : key;
  const entry = rateLimitStorage.get(fullKey);

  if (!entry) {
    rateLimitStorage.set(fullKey, {
      count: 1,
      resetTime: now + windowMs,
      ip: includeIP ? getClientIP() : undefined
    });
    return true;
  }

  if (now > entry.resetTime) {
    // Reset the window
    rateLimitStorage.set(fullKey, {
      count: 1,
      resetTime: now + windowMs,
      ip: includeIP ? getClientIP() : undefined
    });
    return true;
  }

  if (entry.count >= maxAttempts) {
    return false;
  }

  entry.count++;
  return true;
};

// Get client IP (simplified for client-side)
const getClientIP = (): string => {
  return 'client_side'; // In production, this would be handled server-side
};

// CSRF token generation and validation
export const generateCSRFToken = (): string => {
  const array = new Uint8Array(32);
  crypto.getRandomValues(array);
  return Array.from(array, byte => byte.toString(16).padStart(2, '0')).join('');
};

export const validateCSRFToken = (token: string, storedToken: string): boolean => {
  return token === storedToken && token.length === 64;
};

// Session security utilities
export const isSessionValid = async (): Promise<boolean> => {
  try {
    const { data: { session }, error } = await supabase.auth.getSession();
    return !error && !!session && session.expires_at! > Date.now() / 1000;
  } catch {
    return false;
  }
};

export const invalidateSession = async (): Promise<void> => {
  try {
    await supabase.auth.signOut();
    // Clear any local storage
    localStorage.removeItem('supabase.auth.token');
    sessionStorage.clear();
  } catch (error) {
    console.error('Error invalidating session:', error);
  }
};

// Enhanced security logging
export const logSecurityEvent = (
  eventType: string,
  details: Record<string, any>,
  severity: 'low' | 'medium' | 'high' | 'critical'
): void => {
  const event = {
    type: eventType,
    timestamp: new Date().toISOString(),
    severity,
    details: {
      ...details,
      userAgent: navigator.userAgent,
      url: window.location.href,
      timestamp: Date.now()
    }
  };

  console.warn(`[SECURITY ${severity.toUpperCase()}]`, event);
  
  // In production, send to security monitoring service
  // securityMonitoringService.logEvent(event);
};

// Input sanitization with XSS prevention
export const sanitizeHTML = (input: string): string => {
  const div = document.createElement('div');
  div.textContent = input;
  return div.innerHTML;
};

export const validateAndSanitizeInput = (
  input: string,
  maxLength: number,
  allowHTML = false
): { isValid: boolean; sanitized: string; errors: string[] } => {
  const errors: string[] = [];
  let sanitized = input.trim();

  // Length validation
  if (sanitized.length === 0) {
    errors.push('Input cannot be empty');
  }
  if (sanitized.length > maxLength) {
    errors.push(`Input cannot exceed ${maxLength} characters`);
    sanitized = sanitized.substring(0, maxLength);
  }

  // XSS prevention
  if (!allowHTML) {
    sanitized = sanitizeHTML(sanitized);
  }

  // SQL injection prevention patterns
  const sqlPatterns = [
    /(\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXEC|UNION)\b)/gi,
    /(--|\/\*|\*\/)/g,
    /('|('')|"|(""))/g
  ];

  for (const pattern of sqlPatterns) {
    if (pattern.test(input)) {
      errors.push('Input contains potentially dangerous content');
      break;
    }
  }

  return {
    isValid: errors.length === 0,
    sanitized,
    errors
  };
};

// File upload security
export const validateFileUpload = (file: File): { isValid: boolean; errors: string[] } => {
  const errors: string[] = [];
  const maxSize = 10 * 1024 * 1024; // 10MB
  const allowedTypes = [
    'image/jpeg',
    'image/png',
    'image/gif',
    'image/webp',
    'application/pdf',
    'text/plain'
  ];

  if (file.size > maxSize) {
    errors.push('File size cannot exceed 10MB');
  }

  if (!allowedTypes.includes(file.type)) {
    errors.push('File type not allowed');
  }

  // Check for suspicious file extensions
  const suspiciousExtensions = ['.exe', '.bat', '.cmd', '.scr', '.pif', '.js', '.vbs'];
  const fileName = file.name.toLowerCase();
  
  for (const ext of suspiciousExtensions) {
    if (fileName.endsWith(ext)) {
      errors.push('File type not allowed for security reasons');
      break;
    }
  }

  return {
    isValid: errors.length === 0,
    errors
  };
};
