
import { validateAndSanitizeInput } from './securityEnhancements';

// Enhanced event validation
export const validateEventData = (data: {
  title: string;
  description?: string;
  location?: string;
  sport?: string;
  event_date: string;
}): { isValid: boolean; sanitizedData: any; errors: string[] } => {
  const errors: string[] = [];
  let sanitizedData: any = {};

  // Title validation
  const titleValidation = validateAndSanitizeInput(data.title, 200);
  if (!titleValidation.isValid) {
    errors.push(...titleValidation.errors);
  } else {
    sanitizedData.title = titleValidation.sanitized;
  }

  // Description validation
  if (data.description) {
    const descValidation = validateAndSanitizeInput(data.description, 2000);
    if (!descValidation.isValid) {
      errors.push(...descValidation.errors.map(e => `Description: ${e}`));
    } else {
      sanitizedData.description = descValidation.sanitized;
    }
  }

  // Location validation
  if (data.location) {
    const locationValidation = validateAndSanitizeInput(data.location, 500);
    if (!locationValidation.isValid) {
      errors.push(...locationValidation.errors.map(e => `Location: ${e}`));
    } else {
      sanitizedData.location = locationValidation.sanitized;
    }
  }

  // Sport validation
  if (data.sport) {
    const sportValidation = validateAndSanitizeInput(data.sport, 100);
    if (!sportValidation.isValid) {
      errors.push(...sportValidation.errors.map(e => `Sport: ${e}`));
    } else {
      sanitizedData.sport = sportValidation.sanitized;
    }
  }

  // Date validation
  const eventDate = new Date(data.event_date);
  const now = new Date();
  if (isNaN(eventDate.getTime())) {
    errors.push('Invalid event date');
  } else if (eventDate <= now) {
    errors.push('Event date must be in the future');
  } else {
    sanitizedData.event_date = data.event_date;
  }

  return {
    isValid: errors.length === 0,
    sanitizedData,
    errors
  };
};

// Enhanced profile validation
export const validateProfileData = (data: {
  full_name?: string;
  location?: string;
  date_of_birth?: string;
  gender?: string;
  zip_code?: string;
}): { isValid: boolean; sanitizedData: any; errors: string[] } => {
  const errors: string[] = [];
  let sanitizedData: any = {};

  // Full name validation
  if (data.full_name) {
    const nameValidation = validateAndSanitizeInput(data.full_name, 100);
    if (!nameValidation.isValid) {
      errors.push(...nameValidation.errors.map(e => `Full name: ${e}`));
    } else {
      // Additional name validation
      if (!/^[a-zA-Z\s'-]+$/.test(nameValidation.sanitized)) {
        errors.push('Full name can only contain letters, spaces, hyphens, and apostrophes');
      } else {
        sanitizedData.full_name = nameValidation.sanitized;
      }
    }
  }

  // Location validation
  if (data.location) {
    const locationValidation = validateAndSanitizeInput(data.location, 200);
    if (!locationValidation.isValid) {
      errors.push(...locationValidation.errors.map(e => `Location: ${e}`));
    } else {
      sanitizedData.location = locationValidation.sanitized;
    }
  }

  // Date of birth validation
  if (data.date_of_birth) {
    const birthDate = new Date(data.date_of_birth);
    const now = new Date();
    const age = now.getFullYear() - birthDate.getFullYear();
    
    if (isNaN(birthDate.getTime())) {
      errors.push('Invalid date of birth');
    } else if (birthDate >= now) {
      errors.push('Date of birth must be in the past');
    } else if (age < 13 || age > 120) {
      errors.push('Age must be between 13 and 120 years');
    } else {
      sanitizedData.date_of_birth = data.date_of_birth;
    }
  }

  // Gender validation
  if (data.gender) {
    const allowedGenders = ['male', 'female', 'non-binary', 'prefer-not-to-say', 'other'];
    if (!allowedGenders.includes(data.gender.toLowerCase())) {
      errors.push('Invalid gender selection');
    } else {
      sanitizedData.gender = data.gender;
    }
  }

  // Zip code validation
  if (data.zip_code) {
    const zipValidation = validateAndSanitizeInput(data.zip_code, 20);
    if (!zipValidation.isValid) {
      errors.push(...zipValidation.errors.map(e => `Zip code: ${e}`));
    } else {
      // Basic zip code pattern validation
      if (!/^[a-zA-Z0-9\s-]+$/.test(zipValidation.sanitized)) {
        errors.push('Invalid zip code format');
      } else {
        sanitizedData.zip_code = zipValidation.sanitized;
      }
    }
  }

  return {
    isValid: errors.length === 0,
    sanitizedData,
    errors
  };
};

// Enhanced message validation
export const validateMessageData = (data: {
  content: string;
  message_type?: string;
}): { isValid: boolean; sanitizedData: any; errors: string[] } => {
  const errors: string[] = [];
  let sanitizedData: any = {};

  // Content validation
  const contentValidation = validateAndSanitizeInput(data.content, 5000);
  if (!contentValidation.isValid) {
    errors.push(...contentValidation.errors);
  } else {
    sanitizedData.content = contentValidation.sanitized;
  }

  // Message type validation
  if (data.message_type) {
    const allowedTypes = ['direct', 'general', 'event', 'team'];
    if (!allowedTypes.includes(data.message_type)) {
      errors.push('Invalid message type');
    } else {
      sanitizedData.message_type = data.message_type;
    }
  }

  return {
    isValid: errors.length === 0,
    sanitizedData,
    errors
  };
};
