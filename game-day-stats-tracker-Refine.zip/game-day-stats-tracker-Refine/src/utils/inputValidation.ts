
import { logInputValidationFailure, detectSuspiciousInput, sanitizeForDisplay } from './securityUtils';

export interface ValidationResult {
  isValid: boolean;
  errors: string[];
}

// Enhanced text content validation with security checks
export const sanitizeTextContent = (input: string): string => {
  if (!input || typeof input !== 'string') {
    return '';
  }

  // Check for suspicious patterns
  if (detectSuspiciousInput(input)) {
    logInputValidationFailure('text_content', input, 'Suspicious content detected');
    return ''; // Return empty string for security
  }

  // Remove potentially dangerous characters and normalize
  return input
    .trim()
    .replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, '') // Remove control characters
    .replace(/[<>]/g, '') // Remove angle brackets
    .substring(0, 1000); // Limit length
};

// Enhanced email validation
export const validateEmail = (email: string): ValidationResult => {
  const errors: string[] = [];
  
  if (!email || typeof email !== 'string') {
    errors.push('Email is required');
    return { isValid: false, errors };
  }

  const sanitizedEmail = email.trim().toLowerCase();
  
  // Check for suspicious patterns
  if (detectSuspiciousInput(sanitizedEmail)) {
    errors.push('Invalid email format');
    return { isValid: false, errors };
  }

  // Enhanced email regex
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(sanitizedEmail)) {
    errors.push('Please enter a valid email address');
  }

  if (sanitizedEmail.length > 254) {
    errors.push('Email address is too long');
  }

  // Check for common suspicious patterns
  const suspiciousPatterns = [
    /\.{2,}/, // Multiple consecutive dots
    /^\./, // Starting with dot
    /\.$/, // Ending with dot
    /@\./, // @ followed by dot
    /\.@/, // Dot followed by @
  ];

  for (const pattern of suspiciousPatterns) {
    if (pattern.test(sanitizedEmail)) {
      errors.push('Invalid email format');
      break;
    }
  }

  return { isValid: errors.length === 0, errors };
};

// Enhanced password validation
export const validatePassword = (password: string): ValidationResult => {
  const errors: string[] = [];
  
  if (!password || typeof password !== 'string') {
    errors.push('Password is required');
    return { isValid: false, errors };
  }

  // Check for suspicious patterns
  if (detectSuspiciousInput(password)) {
    errors.push('Password contains invalid characters');
    return { isValid: false, errors };
  }

  if (password.length < 8) {
    errors.push('Password must be at least 8 characters long');
  }

  if (password.length > 128) {
    errors.push('Password must be less than 128 characters');
  }

  if (!/(?=.*[a-z])/.test(password)) {
    errors.push('Password must contain at least one lowercase letter');
  }

  if (!/(?=.*[A-Z])/.test(password)) {
    errors.push('Password must contain at least one uppercase letter');
  }

  if (!/(?=.*\d)/.test(password)) {
    errors.push('Password must contain at least one number');
  }

  if (!/(?=.*[!@#$%^&*(),.?":{}|<>])/.test(password)) {
    errors.push('Password must contain at least one special character');
  }

  // Check for common weak patterns
  const weakPatterns = [
    /(.)\1{3,}/, // Same character repeated 4+ times
    /123456/, // Sequential numbers
    /abcdef/, // Sequential letters
    /password/i, // Contains "password"
    /qwerty/i, // Contains "qwerty"
  ];

  for (const pattern of weakPatterns) {
    if (pattern.test(password)) {
      errors.push('Password is too weak - avoid common patterns');
      break;
    }
  }

  return { isValid: errors.length === 0, errors };
};

// Event validation function (missing export)
export const validateEventInput = (title: string, description: string, location: string): ValidationResult => {
  const errors: string[] = [];

  // Validate title
  if (!title || title.trim().length === 0) {
    errors.push('Event title is required');
  } else {
    const sanitizedTitle = sanitizeTextContent(title);
    if (sanitizedTitle.length < 3) {
      errors.push('Event title must be at least 3 characters long');
    }
    if (sanitizedTitle.length > 200) {
      errors.push('Event title must be less than 200 characters');
    }
    if (detectSuspiciousInput(title)) {
      errors.push('Event title contains invalid characters');
    }
  }

  // Validate description
  if (description && description.trim().length > 0) {
    const sanitizedDescription = sanitizeTextContent(description);
    if (sanitizedDescription.length > 2000) {
      errors.push('Event description must be less than 2000 characters');
    }
    if (detectSuspiciousInput(description)) {
      errors.push('Event description contains invalid characters');
    }
  }

  // Validate location
  if (!location || location.trim().length === 0) {
    errors.push('Event location is required');
  } else {
    const sanitizedLocation = sanitizeTextContent(location);
    if (sanitizedLocation.length > 500) {
      errors.push('Event location must be less than 500 characters');
    }
    if (detectSuspiciousInput(location)) {
      errors.push('Event location contains invalid characters');
    }
  }

  return { isValid: errors.length === 0, errors };
};

// Profile input validation
export const validateProfileInput = (fullName: string, location: string, zipCode: string): ValidationResult => {
  const errors: string[] = [];

  // Validate full name
  if (fullName) {
    const sanitizedName = sanitizeTextContent(fullName);
    if (sanitizedName !== fullName.trim()) {
      errors.push('Full name contains invalid characters');
    }
    if (sanitizedName.length < 1) {
      errors.push('Full name is required');
    }
    if (sanitizedName.length > 100) {
      errors.push('Full name must be less than 100 characters');
    }
  }

  // Validate location
  if (location) {
    const sanitizedLocation = sanitizeTextContent(location);
    if (sanitizedLocation !== location.trim()) {
      errors.push('Location contains invalid characters');
    }
    if (sanitizedLocation.length > 200) {
      errors.push('Location must be less than 200 characters');
    }
  }

  // Validate zip code
  if (zipCode) {
    const sanitizedZip = sanitizeTextContent(zipCode);
    if (sanitizedZip !== zipCode.trim()) {
      errors.push('Zip code contains invalid characters');
    }
    // Allow various zip code formats (US, UK, CA, etc.)
    const zipRegex = /^[A-Za-z0-9\s\-]{3,10}$/;
    if (!zipRegex.test(sanitizedZip)) {
      errors.push('Please enter a valid zip code');
    }
  }

  return { isValid: errors.length === 0, errors };
};

// Message content validation
export const validateMessageContent = (content: string): ValidationResult => {
  const errors: string[] = [];

  if (!content || typeof content !== 'string') {
    errors.push('Message content is required');
    return { isValid: false, errors };
  }

  const sanitizedContent = sanitizeTextContent(content);
  
  if (sanitizedContent !== content.trim()) {
    errors.push('Message contains invalid characters');
  }

  if (sanitizedContent.length < 1) {
    errors.push('Message cannot be empty');
  }

  if (sanitizedContent.length > 2000) {
    errors.push('Message must be less than 2000 characters');
  }

  return { isValid: errors.length === 0, errors };
};

// Rate limiting helpers
export const checkRateLimit = (key: string, limit: number, windowMs: number): boolean => {
  const now = Date.now();
  const storageKey = `rate_limit_${key}`;
  
  try {
    const stored = localStorage.getItem(storageKey);
    const data = stored ? JSON.parse(stored) : { count: 0, resetTime: now + windowMs };
    
    if (now > data.resetTime) {
      data.count = 0;
      data.resetTime = now + windowMs;
    }
    
    if (data.count >= limit) {
      return false; // Rate limit exceeded
    }
    
    data.count++;
    localStorage.setItem(storageKey, JSON.stringify(data));
    return true;
  } catch {
    return true; // Allow if localStorage fails
  }
};

// Export utility for displaying sanitized content
export const displaySafeContent = (content: string): string => {
  return sanitizeForDisplay(sanitizeTextContent(content));
};
