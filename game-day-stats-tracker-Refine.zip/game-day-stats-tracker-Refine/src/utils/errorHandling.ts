
// Enhanced error handling utilities
export const handleAuthError = (error: any): string => {
  console.error('Auth error:', error);
  
  // Sanitize error messages to prevent information leakage
  switch (error?.message) {
    case 'Invalid login credentials':
      return 'Invalid email or password. Please try again.';
    case 'Email not confirmed':
      return 'Please check your email and click the confirmation link.';
    case 'User already registered':
      return 'An account with this email already exists. Please sign in instead.';
    case 'Password should be at least 6 characters':
      return 'Password must be at least 6 characters long.';
    case 'Invalid email':
      return 'Please enter a valid email address.';
    default:
      return 'An authentication error occurred. Please try again.';
  }
};

export const handleDatabaseError = (error: any): string => {
  console.error('Database error:', error);
  
  // Sanitize database errors to prevent information leakage
  if (error?.code === 'PGRST116') {
    return 'No data found or access denied.';
  }
  
  if (error?.code === '23505') {
    return 'This record already exists.';
  }
  
  if (error?.code === '23503') {
    return 'Cannot complete action due to related data.';
  }
  
  if (error?.message?.includes('RLS')) {
    return 'Access denied. Please ensure you are logged in.';
  }
  
  return 'A database error occurred. Please try again later.';
};

export const logSecurityEvent = (event: string, details?: any) => {
  // In production, this would send to a security monitoring service
  console.warn(`SECURITY EVENT: ${event}`, details);
};

export const sanitizeErrorForLogging = (error: any) => {
  // Remove sensitive information from errors before logging
  const sanitized = {
    message: error?.message,
    code: error?.code,
    status: error?.status,
    timestamp: new Date().toISOString()
  };
  
  return sanitized;
};
