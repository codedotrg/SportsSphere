
import React from 'react';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface BackButtonProps {
  fallbackPath?: string;
  className?: string;
}

export const BackButton: React.FC<BackButtonProps> = ({ 
  fallbackPath = '/', 
  className 
}) => {
  const navigate = useNavigate();

  const handleBack = () => {
    // Use browser's back functionality to preserve scroll position
    if (window.history.length > 1) {
      window.history.back();
    } else {
      // Only use fallback if there's no history
      navigate(fallbackPath);
    }
  };

  return (
    <Button 
      variant="ghost" 
      size="sm" 
      onClick={handleBack}
      className={className}
    >
      <ArrowLeft className="h-4 w-4" />
    </Button>
  );
};
