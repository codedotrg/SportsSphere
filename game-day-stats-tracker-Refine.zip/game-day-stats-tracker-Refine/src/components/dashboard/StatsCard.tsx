
import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Trophy, Users, Calendar, Star } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';

interface UserStats {
  eventsJoined: number;
  teamsJoined: number;
  averageRating: number;
  totalRatings: number;
}

export const StatsCard: React.FC = () => {
  const { user } = useAuth();
  const [stats, setStats] = useState<UserStats>({
    eventsJoined: 0,
    teamsJoined: 0,
    averageRating: 0,
    totalRatings: 0
  });
  const [loading, setLoading] = useState(true);

  const fetchStats = async () => {
    if (!user) return;
    
    try {
      // Fetch events joined
      const { data: eventsData, error: eventsError } = await supabase
        .from('event_participants')
        .select('id')
        .eq('player_id', user.id);

      if (eventsError) throw eventsError;

      // Fetch teams joined
      const { data: teamsData, error: teamsError } = await supabase
        .from('team_members')
        .select('id')
        .eq('player_id', user.id);

      if (teamsError) throw teamsError;

      // Fetch ratings
      const { data: ratingsData, error: ratingsError } = await supabase
        .from('player_ratings')
        .select('rating')
        .eq('rated_player_id', user.id);

      if (ratingsError) throw ratingsError;

      const totalRatings = ratingsData?.length || 0;
      const averageRating = totalRatings > 0 
        ? ratingsData.reduce((sum, r) => sum + r.rating, 0) / totalRatings 
        : 0;

      setStats({
        eventsJoined: eventsData?.length || 0,
        teamsJoined: teamsData?.length || 0,
        averageRating: Math.round(averageRating * 10) / 10,
        totalRatings
      });
    } catch (error) {
      console.error('Error fetching stats:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStats();
  }, [user]);

  const statItems = [
    {
      label: 'Events Joined',
      value: stats.eventsJoined,
      icon: <Calendar className="h-4 w-4" />,
      color: 'text-blue-600'
    },
    {
      label: 'Teams Joined',
      value: stats.teamsJoined,
      icon: <Users className="h-4 w-4" />,
      color: 'text-green-600'
    },
    {
      label: 'Average Rating',
      value: stats.averageRating > 0 ? stats.averageRating.toFixed(1) : '—',
      icon: <Star className="h-4 w-4" />,
      color: 'text-yellow-600'
    },
    {
      label: 'Total Ratings',
      value: stats.totalRatings,
      icon: <Trophy className="h-4 w-4" />,
      color: 'text-purple-600'
    }
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Trophy className="mr-2 h-5 w-5 text-primary" />
          Your Stats
        </CardTitle>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="grid grid-cols-2 gap-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="animate-pulse">
                <div className="h-8 bg-muted rounded mb-2"></div>
                <div className="h-4 bg-muted rounded w-3/4"></div>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-4">
            {statItems.map((item, index) => (
              <div key={index} className="text-center">
                <div className={`flex items-center justify-center mb-2 ${item.color}`}>
                  {item.icon}
                  <span className="ml-1 text-2xl font-bold">{item.value}</span>
                </div>
                <p className="text-xs text-muted-foreground">{item.label}</p>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};
