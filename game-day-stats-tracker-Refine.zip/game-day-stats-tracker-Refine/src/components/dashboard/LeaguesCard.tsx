
import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Trophy, RefreshCw } from 'lucide-react';
import { League, getCurrentLeagues } from './leagues/LeagueData';
import { getLeagueStatus } from './leagues/LeagueStatusUtils';
import { LeagueItem } from './leagues/LeagueItem';

export const LeaguesCard: React.FC = () => {
  const [leagues, setLeagues] = useState<League[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchLeagues = async () => {
    setLoading(true);
    
    try {
      const currentLeagues = getCurrentLeagues();
      
      // Calculate current status for each league
      const leaguesWithStatus = currentLeagues.map(league => ({
        ...league,
        status: getLeagueStatus(league.startDate!, league.endDate!)
      }));
      
      // Filter out finished leagues older than 30 days
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
      
      const activeLeagues = leaguesWithStatus.filter(league => {
        if (league.status === 'Finished') {
          return new Date(league.endDate!) > thirtyDaysAgo;
        }
        return true;
      });
      
      setLeagues(activeLeagues);
    } catch (error) {
      console.error('Error fetching leagues:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLeagues();
  }, []);

  const handleLeagueClick = (url: string) => {
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center">
            <Trophy className="mr-2 h-5 w-5 text-primary" />
            Leagues & Tournaments
          </div>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={fetchLeagues}
            disabled={loading}
          >
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="animate-pulse">
                <div className="h-4 bg-muted rounded w-3/4 mb-2"></div>
                <div className="h-3 bg-muted rounded w-full"></div>
              </div>
            ))}
          </div>
        ) : (
          <div className="space-y-3">
            {leagues.map((league, index) => (
              <LeagueItem 
                key={index} 
                league={league}
                onClick={handleLeagueClick}
              />
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};
