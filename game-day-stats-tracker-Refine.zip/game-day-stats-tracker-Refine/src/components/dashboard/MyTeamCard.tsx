
import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Users, User } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';

interface TeamMember {
  id: string;
  player_id: string;
  position: string;
  is_captain: boolean;
  profiles: {
    full_name: string;
    email: string;
  };
  team_formations: {
    team_name: string;
    event_id: string;
    events: {
      title: string;
    };
  };
}

export const MyTeamCard: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchTeamMembers();
    }
  }, [user]);

  const fetchTeamMembers = async () => {
    if (!user) return;

    try {
      // First, get the teams the user is part of
      const { data: userTeams, error: userTeamsError } = await supabase
        .from('team_members')
        .select('team_formation_id')
        .eq('player_id', user.id);

      if (userTeamsError) throw userTeamsError;

      if (!userTeams || userTeams.length === 0) {
        setTeamMembers([]);
        setLoading(false);
        return;
      }

      const teamIds = userTeams.map(t => t.team_formation_id);

      // Get all team members from those teams
      const { data: members, error: membersError } = await supabase
        .from('team_members')
        .select(`
          id,
          player_id,
          position,
          is_captain,
          profiles:player_id (
            full_name,
            email
          ),
          team_formations:team_formation_id (
            team_name,
            event_id,
            events:event_id (
              title
            )
          )
        `)
        .in('team_formation_id', teamIds)
        .neq('player_id', user.id); // Exclude the current user

      if (membersError) throw membersError;

      setTeamMembers(members || []);
    } catch (error) {
      console.error('Error fetching team members:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>My Team</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">Loading...</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Users className="mr-2 h-5 w-5" />
          My Team
        </CardTitle>
      </CardHeader>
      <CardContent>
        {teamMembers.length === 0 ? (
          <div className="text-center py-4">
            <p className="text-muted-foreground mb-2">No team members found</p>
            <p className="text-sm text-muted-foreground mb-3">
              Join an event to be part of a team!
            </p>
            <Button onClick={() => navigate('/events')}>
              Find Events
            </Button>
          </div>
        ) : (
          <div className="space-y-3">
            {teamMembers.slice(0, 5).map((member) => (
              <div
                key={member.id}
                className="flex items-center space-x-3 p-2 border rounded-lg"
              >
                <div className="bg-primary/10 p-2 rounded-full">
                  <User className="h-4 w-4 text-primary" />
                </div>
                <div className="flex-1">
                  <p className="font-medium">
                    {member.profiles?.full_name || 'Unknown Player'}
                    {member.is_captain && (
                      <span className="ml-2 text-xs bg-yellow-100 text-yellow-800 px-2 py-1 rounded">
                        Captain
                      </span>
                    )}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {member.position || 'No position'}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    Team: {member.team_formations?.team_name}
                  </p>
                </div>
              </div>
            ))}
            {teamMembers.length > 5 && (
              <p className="text-sm text-muted-foreground text-center">
                And {teamMembers.length - 5} more teammates...
              </p>
            )}
            <Button 
              variant="outline" 
              className="w-full"
              onClick={() => navigate('/events')}
            >
              View All Teams
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
};
