
import React from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { Plus, Search, Zap } from 'lucide-react';

export const QuickActionsCard: React.FC = () => {
  const navigate = useNavigate();

  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Zap className="h-5 w-5 text-primary" />
          Quick Actions
        </CardTitle>
        <CardDescription>
          Jump into action and start your sports journey
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <Button 
          className="w-full" 
          onClick={() => navigate('/events/create')}
        >
          <Plus className="mr-2 h-4 w-4" />
          Create New Event
        </Button>
        <Button 
          className="w-full" 
          variant="outline" 
          onClick={() => navigate('/events')}
        >
          <Search className="mr-2 h-4 w-4" />
          Explore Events
        </Button>
      </CardContent>
    </Card>
  );
};
