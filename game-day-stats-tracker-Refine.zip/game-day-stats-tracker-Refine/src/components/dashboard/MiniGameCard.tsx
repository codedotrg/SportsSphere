
import React, { useState, useCallback, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Target, RefreshCw, Trophy, HeartCrack } from 'lucide-react';

const MAX_SHOTS = 10;

export const MiniGameCard: React.FC = () => {
  const [goals, setGoals] = useState(0);
  const [misses, setMisses] = useState(0);
  const [lastResult, setLastResult] = useState<string | null>(null);
  const [shooting, setShooting] = useState(false);
  const [gameStatus, setGameStatus] = useState<'playing' | 'won' | 'lost' | null>(null);
  const [showResult, setShowResult] = useState(false);

  const totalShots = goals + misses;
  const isGameOver = totalShots >= MAX_SHOTS;

  useEffect(() => {
    if (isGameOver && gameStatus === 'playing') {
      // Determine win/loss (need at least 6/10 to win)
      if (goals >= 6) {
        setGameStatus('won');
      } else {
        setGameStatus('lost');
      }
      setShowResult(true);
      
      // Hide result after 3 seconds
      setTimeout(() => {
        setShowResult(false);
      }, 3000);
    }
  }, [isGameOver, goals, gameStatus]);

  const handleShoot = useCallback(() => {
    if (isGameOver) return;
    
    setShooting(true);
    setLastResult(null);
    if (gameStatus === null) setGameStatus('playing');

    setTimeout(() => {
      const outcome = Math.random();
      if (outcome > 0.4) { // 60% chance of scoring
        setGoals(prev => prev + 1);
        setLastResult("Goal! ⚽");
      } else {
        setMisses(prev => prev + 1);
        const missMessages = ["Saved by the keeper! 🧤", "Just wide! 🥅", "Hit the post! 💥"];
        setLastResult(missMessages[Math.floor(Math.random() * missMessages.length)]);
      }
      setShooting(false);
    }, 1000);
  }, [isGameOver, gameStatus]);

  const handleReset = useCallback(() => {
    setGoals(0);
    setMisses(0);
    setLastResult(null);
    setGameStatus(null);
    setShowResult(false);
  }, []);

  return (
    <Card className={showResult ? (gameStatus === 'won' ? 'animate-pulse border-green-500 bg-green-50' : 'animate-pulse border-red-500 bg-red-50') : ''}>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Target className="mr-2 h-5 w-5 text-primary" />
          Penalty Shootout
          <span className="ml-auto text-sm text-muted-foreground">
            {totalShots}/{MAX_SHOTS}
          </span>
        </CardTitle>
      </CardHeader>
      <CardContent className="text-center space-y-4">
        <div className="text-2xl font-bold min-h-[32px] flex items-center justify-center">
          {showResult && gameStatus === 'won' && (
            <div className="animate-bounce text-green-600 flex items-center">
              <Trophy className="mr-2 h-6 w-6" />
              <p>🎉 You Won! Congratulations! 🎉</p>
            </div>
          )}
          {showResult && gameStatus === 'lost' && (
            <div className="animate-bounce text-red-600 flex items-center">
              <HeartCrack className="mr-2 h-6 w-6" />
              <p>😔 Better Luck Next Time! 😔</p>
            </div>
          )}
          {!showResult && lastResult && <p className="animate-fade-in">{lastResult}</p>}
          {!showResult && !lastResult && !shooting && !isGameOver && (
            <p className="text-muted-foreground text-base">Ready to shoot?</p>
          )}
          {!showResult && shooting && <p className="animate-pulse">Shooting...</p>}
          {!showResult && isGameOver && !showResult && (
            <p className="text-muted-foreground text-base">Game Complete!</p>
          )}
        </div>
        
        <div className="flex justify-around text-lg">
          <div>
            <p>Goals</p>
            <p className="font-bold text-3xl text-green-500">{goals}</p>
          </div>
          <div>
            <p>Misses</p>
            <p className="font-bold text-3xl text-red-500">{misses}</p>
          </div>
        </div>
        
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div 
            className="bg-primary h-2 rounded-full transition-all duration-300 ease-out" 
            style={{ width: `${(totalShots / MAX_SHOTS) * 100}%` }}
          ></div>
        </div>
        
        <div className="flex gap-2 justify-center">
          <Button 
            onClick={handleShoot} 
            disabled={shooting || isGameOver} 
            className="w-24"
          >
            {shooting ? '...' : isGameOver ? 'Finished' : 'Shoot'}
          </Button>
          <Button onClick={handleReset} variant="outline" size="icon">
            <RefreshCw className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};
