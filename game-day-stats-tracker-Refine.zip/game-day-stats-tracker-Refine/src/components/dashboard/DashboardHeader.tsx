
import React from 'react';
import { AdvancedSearchBar } from '@/components/search/AdvancedSearchBar';
import { useIsMobile } from '@/hooks/use-mobile';

export const DashboardHeader: React.FC = () => {
  const isMobile = useIsMobile();
  
  return (
    <div className="flex flex-col gap-4 mb-4 sm:mb-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <h1 className="text-2xl sm:text-3xl font-bold">My Dashboard</h1>
        {!isMobile && <AdvancedSearchBar />}
      </div>
      {isMobile && <AdvancedSearchBar />}
    </div>
  );
};
