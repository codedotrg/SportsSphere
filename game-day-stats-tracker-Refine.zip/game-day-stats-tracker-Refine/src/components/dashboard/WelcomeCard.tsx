
import React from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Trophy, Zap, Target } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

export const WelcomeCard: React.FC = () => {
  const { user } = useAuth();

  const getUserDisplayName = () => {
    if (user?.user_metadata?.full_name) {
      return user.user_metadata.full_name;
    }
    if (user?.email) {
      return user.email.split('@')[0];
    }
    return 'Champion';
  };

  return (
    <Card className="mb-8 relative overflow-hidden bg-sport-gradient text-white">
      <div className="absolute inset-0 bg-black/10"></div>
      <CardHeader className="relative z-10">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-white/20 rounded-full animate-bounce-sport">
            <Trophy className="h-8 w-8 text-white" />
          </div>
          <div>
            <CardTitle className="text-white text-3xl font-bold">
              Welcome to SportSphere, {getUserDisplayName()}!
            </CardTitle>
            <CardDescription className="text-white/90 text-lg font-medium">
              Your arena for epic sports adventures and team connections.
            </CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
          <div className="flex items-center gap-3 p-4 bg-white/10 rounded-lg backdrop-blur-sm">
            <Zap className="h-6 w-6 text-yellow-300 animate-pulse-energy" />
            <div>
              <p className="font-semibold text-white">Create Events</p>
              <p className="text-sm text-white/80">Organize your sports activities</p>
            </div>
          </div>
          <div className="flex items-center gap-3 p-4 bg-white/10 rounded-lg backdrop-blur-sm">
            <Target className="h-6 w-6 text-green-300 animate-pulse-energy" />
            <div>
              <p className="font-semibold text-white">Join Teams</p>
              <p className="text-sm text-white/80">Connect with fellow athletes</p>
            </div>
          </div>
          <div className="flex items-center gap-3 p-4 bg-white/10 rounded-lg backdrop-blur-sm">
            <Trophy className="h-6 w-6 text-orange-300 animate-pulse-energy" />
            <div>
              <p className="font-semibold text-white">Track Progress</p>
              <p className="text-sm text-white/80">Monitor your achievements</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
