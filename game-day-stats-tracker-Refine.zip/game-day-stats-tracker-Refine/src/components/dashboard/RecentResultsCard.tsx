
import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Trophy, Calendar, ExternalLink } from 'lucide-react';

export const RecentResultsCard: React.FC = () => {
  const recentResults = [
    {
      id: 1,
      event: 'Premier League',
      date: '2024-06-13',
      result: 'Won',
      score: '2-1',
      opponent: 'Manchester City vs Arsenal',
      sport: 'Football',
      link: 'https://www.premierleague.com/match/91469'
    },
    {
      id: 2,
      event: 'NBA Finals Game 5',
      date: '2024-06-12',
      result: 'Won',
      score: '112-108',
      opponent: 'Boston Celtics vs Dallas Mavericks',
      sport: 'Basketball',
      link: 'https://www.nba.com/game/bos-vs-dal-0042300405'
    },
    {
      id: 3,
      event: 'French Open Final',
      date: '2024-06-11',
      result: 'Won',
      score: '6-3, 6-2, 6-4',
      opponent: 'Carlos Alcaraz vs Alexander Zverev',
      sport: 'Tennis',
      link: 'https://www.rolandgarros.com/en-us/matches'
    },
    {
      id: 4,
      event: 'Champions League',
      date: '2024-06-10',
      result: 'Lost',
      score: '0-2',
      opponent: 'Real Madrid vs Borussia Dortmund',
      sport: 'Football',
      link: 'https://www.uefa.com/uefachampionsleague/match/2029487/'
    },
    {
      id: 5,
      event: 'Stanley Cup Finals',
      date: '2024-06-09',
      result: 'Won',
      score: '4-2',
      opponent: 'Florida Panthers vs Edmonton Oilers',
      sport: 'Hockey',
      link: 'https://www.nhl.com/gamecenter/fla-vs-edm/2024/06/09/2023030415'
    }
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Trophy className="mr-2 h-5 w-5" />
          Recent Sports Results
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {recentResults.map((result) => (
            <div key={result.id} className="flex items-center justify-between p-3 border rounded-lg">
              <div className="flex-1">
                <h4 className="font-medium">{result.event}</h4>
                <div className="flex items-center text-sm text-muted-foreground mt-1">
                  <Calendar className="mr-1 h-3 w-3" />
                  {new Date(result.date).toLocaleDateString()}
                </div>
                <p className="text-sm mt-1">{result.opponent}</p>
                <span className="text-xs bg-muted px-2 py-1 rounded-md mt-1 inline-block">
                  {result.sport}
                </span>
              </div>
              <div className="text-right space-y-2">
                <Badge variant={result.result === 'Won' ? 'default' : 'destructive'}>
                  {result.result}
                </Badge>
                <p className="text-sm font-mono">{result.score}</p>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => window.open(result.link, '_blank')}
                  className="text-xs"
                >
                  <ExternalLink className="mr-1 h-3 w-3" />
                  View Details
                </Button>
              </div>
            </div>
          ))}
        </div>
        {recentResults.length === 0 && (
          <p className="text-center text-muted-foreground py-4">
            No recent results to display
          </p>
        )}
      </CardContent>
    </Card>
  );
};
