
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { MessageCircle, Users, Send, Brain } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useDirectMessages } from '@/hooks/useDirectMessages';
import { useRealtimeNotifications } from '@/hooks/useRealtimeNotifications';

export const MessagingCard: React.FC = () => {
  const navigate = useNavigate();
  const { conversations } = useDirectMessages('inbox');
  const unreadCount = conversations.filter(conv => !conv.is_read).length;
  
  // Enable real-time notifications
  useRealtimeNotifications();

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <MessageCircle className="mr-2 h-5 w-5" />
          Messages
        </CardTitle>
        <CardDescription>
          Stay connected with other players
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
          <div className="flex items-center space-x-3">
            <Users className="h-8 w-8 text-primary" />
            <div>
              <p className="font-medium">Direct Messages</p>
              <p className="text-sm text-muted-foreground">
                {unreadCount > 0 ? `${unreadCount} unread` : 'All caught up!'}
              </p>
            </div>
          </div>
          {unreadCount > 0 && (
            <div className="bg-primary text-primary-foreground rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold">
              {unreadCount}
            </div>
          )}
        </div>

        <div className="grid grid-cols-2 gap-2">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => navigate('/messages')}
          >
            <MessageCircle className="mr-2 h-4 w-4" />
            View All
          </Button>
          <Button 
            size="sm"
            onClick={() => navigate('/messages')}
          >
            <Send className="mr-2 h-4 w-4" />
            New Message
          </Button>
        </div>

        <div className="pt-2 border-t">
          <Button 
            variant="outline"
            size="sm"
            className="w-full"
            onClick={() => navigate('/ai-matchmaking')}
          >
            <Brain className="mr-2 h-4 w-4" />
            AI Matchmaking
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};
