
import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Users, UserCheck, UserPlus } from 'lucide-react';
import { useUserFollows } from '@/hooks/useUserFollows';

interface ConnectionsCardProps {
  onViewFollowers: () => void;
  onViewFollowing: () => void;
}

export const ConnectionsCard: React.FC<ConnectionsCardProps> = ({ onViewFollowers, onViewFollowing }) => {
  const { followers, following, loading } = useUserFollows();

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Users className="mr-2 h-5 w-5 text-primary" />
          My Connections
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex justify-around text-center">
          <div>
            <p className="text-2xl font-bold">{loading ? '-' : followers.length}</p>
            <p className="text-sm text-muted-foreground">Followers</p>
          </div>
          <div>
            <p className="text-2xl font-bold">{loading ? '-' : following.length}</p>
            <p className="text-sm text-muted-foreground">Following</p>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <Button variant="outline" onClick={onViewFollowers}>
            <UserCheck className="mr-2 h-4 w-4" />
            View Followers
          </Button>
          <Button variant="outline" onClick={onViewFollowing}>
            <UserPlus className="mr-2 h-4 w-4" />
            View Following
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};
