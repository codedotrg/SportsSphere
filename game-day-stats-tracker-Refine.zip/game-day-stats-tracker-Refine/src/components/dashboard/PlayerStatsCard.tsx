
import React from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Trophy, Target, Calendar, TrendingUp } from 'lucide-react';

interface PlayerStatsCardProps {
  stats: {
    eventsCreated: number;
    eventsJoined: number;
    totalEventsPlayed: number;
  };
}

export const PlayerStatsCard: React.FC<PlayerStatsCardProps> = ({ stats }) => {
  return (
    <Card className="hover-lift">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TrendingUp className="h-5 w-5 text-accent animate-pulse-energy" />
          Player Statistics
        </CardTitle>
        <CardDescription>Your sports activity summary</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex items-center justify-between p-3 rounded-lg bg-gradient-to-r from-primary/10 to-primary/5 border border-primary/20">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-primary/20 rounded-full">
                <Trophy className="h-4 w-4 text-primary" />
              </div>
              <span className="text-sm font-medium">Events Created</span>
            </div>
            <span className="font-bold text-lg text-primary animate-pulse-energy">{stats.eventsCreated}</span>
          </div>
          
          <div className="flex items-center justify-between p-3 rounded-lg bg-gradient-to-r from-secondary/10 to-secondary/5 border border-secondary/20">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-secondary/20 rounded-full">
                <Target className="h-4 w-4 text-secondary" />
              </div>
              <span className="text-sm font-medium">Events Joined</span>
            </div>
            <span className="font-bold text-lg text-secondary animate-pulse-energy">{stats.eventsJoined}</span>
          </div>
          
          <div className="flex items-center justify-between p-3 rounded-lg bg-gradient-to-r from-accent/10 to-accent/5 border border-accent/20">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-accent/20 rounded-full">
                <Calendar className="h-4 w-4 text-accent" />
              </div>
              <span className="text-sm font-medium">Total Events Played</span>
            </div>
            <span className="font-bold text-lg text-victory trophy-shine">{stats.totalEventsPlayed}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
