
import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Users, Plus, RefreshCw, Calendar, MapPin, CheckCircle, RotateCcw } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';

interface Requirement {
  id: string;
  role_name: string;
  description: string;
  experience_level: string;
  max_players: number;
  created_at: string;
  is_completed: boolean;
  event: {
    id: string;
    title: string;
    sport: string;
    event_date: string;
    location: string;
  };
}

interface RequirementsCardProps {
  onRequirementClick: (requirementId: string) => void;
}

export const RequirementsCard: React.FC<RequirementsCardProps> = ({ onRequirementClick }) => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [requirements, setRequirements] = useState<Requirement[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchRequirements = async () => {
    if (!user) return;
    
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('player_requirements')
        .select(`
          id,
          role_name,
          description,
          experience_level,
          max_players,
          created_at,
          is_completed,
          event:events (
            id,
            title,
            sport,
            event_date,
            location
          )
        `)
        .eq('created_by', user.id)
        .order('created_at', { ascending: false })
        .limit(5);

      if (error) throw error;
      
      // Auto-close requirements for past events
      const now = new Date();
      const updatedRequirements = data?.map(req => {
        const eventDate = new Date(req.event.event_date);
        if (eventDate < now && !req.is_completed) {
          // Auto-close past event requirements
          autoCloseRequirement(req.id);
          return { ...req, is_completed: true };
        }
        return req;
      }) || [];

      setRequirements(updatedRequirements);
    } catch (error) {
      console.error('Error fetching requirements:', error);
      toast({
        title: "Error",
        description: "Failed to load your requirements",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const autoCloseRequirement = async (requirementId: string) => {
    try {
      await supabase
        .from('player_requirements')
        .update({ is_completed: true })
        .eq('id', requirementId);
    } catch (error) {
      console.error('Error auto-closing requirement:', error);
    }
  };

  const handleReopenRequirement = async (requirementId: string, event: React.MouseEvent) => {
    event.stopPropagation();
    
    try {
      const { error } = await supabase
        .from('player_requirements')
        .update({ is_completed: false })
        .eq('id', requirementId);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Requirement has been reopened",
      });

      fetchRequirements();
    } catch (error) {
      console.error('Error reopening requirement:', error);
      toast({
        title: "Error",
        description: "Failed to reopen requirement",
        variant: "destructive"
      });
    }
  };

  useEffect(() => {
    if (user) {
      fetchRequirements();
    }
  }, [user]);

  const getExperienceColor = (level: string) => {
    switch (level?.toLowerCase()) {
      case 'beginner':
        return 'bg-green-100 text-green-600';
      case 'intermediate':
        return 'bg-yellow-100 text-yellow-600';
      case 'advanced':
        return 'bg-orange-100 text-orange-600';
      case 'professional':
        return 'bg-red-100 text-red-600';
      default:
        return 'bg-gray-100 text-gray-600';
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const isEventPast = (eventDate: string) => {
    return new Date(eventDate) < new Date();
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center">
            <Users className="mr-2 h-5 w-5 text-primary" />
            My Player Requirements
          </div>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={fetchRequirements}
            disabled={loading}
          >
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="animate-pulse">
                <div className="h-4 bg-muted rounded w-3/4 mb-2"></div>
                <div className="h-3 bg-muted rounded w-full"></div>
              </div>
            ))}
          </div>
        ) : requirements.length === 0 ? (
          <div className="text-center py-6">
            <Users className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No Requirements Yet</h3>
            <p className="text-muted-foreground mb-4">
              Create player requirements for your events to find the right team members.
            </p>
            <Button onClick={() => navigate('/requirements/create')}>
              <Plus className="mr-2 h-4 w-4" />
              Create First Requirement
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            {requirements.map((requirement) => (
              <div 
                key={requirement.id} 
                className="border border-border rounded-lg p-4 hover:bg-muted/50 transition-colors cursor-pointer"
                onClick={() => onRequirementClick(requirement.id)}
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    <h4 className="font-semibold text-sm">{requirement.role_name}</h4>
                    {requirement.is_completed && (
                      <Badge variant="secondary" className="bg-green-100 text-green-800">
                        <CheckCircle className="w-3 h-3 mr-1" />
                        Completed
                      </Badge>
                    )}
                    {isEventPast(requirement.event.event_date) && (
                      <Badge variant="outline" className="bg-gray-100 text-gray-600">
                        Past Event
                      </Badge>
                    )}
                  </div>
                  <div className="flex items-center space-x-2">
                    {requirement.is_completed && !isEventPast(requirement.event.event_date) && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={(e) => handleReopenRequirement(requirement.id, e)}
                        className="h-6 w-6 p-0"
                      >
                        <RotateCcw className="h-3 w-3" />
                      </Button>
                    )}
                    {requirement.experience_level && (
                      <Badge 
                        variant="outline" 
                        className={`text-xs ${getExperienceColor(requirement.experience_level)}`}
                      >
                        {requirement.experience_level}
                      </Badge>
                    )}
                    {requirement.max_players && (
                      <Badge variant="secondary" className="text-xs">
                        Max {requirement.max_players}
                      </Badge>
                    )}
                  </div>
                </div>
                
                <p className="text-xs text-muted-foreground mb-2">
                  {requirement.event.title}
                </p>
                
                {requirement.description && (
                  <p className="text-xs text-muted-foreground mb-3 line-clamp-2">
                    {requirement.description}
                  </p>
                )}
                
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <div className="flex items-center space-x-3">
                    <div className="flex items-center">
                      <Calendar className="h-3 w-3 mr-1" />
                      {formatDate(requirement.event.event_date)}
                    </div>
                    <div className="flex items-center">
                      <MapPin className="h-3 w-3 mr-1" />
                      {requirement.event.location}
                    </div>
                  </div>
                  <span>Created {formatDate(requirement.created_at)}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};
