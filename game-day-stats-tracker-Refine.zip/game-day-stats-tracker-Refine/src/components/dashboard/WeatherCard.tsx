
import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Cloud, Sun, CloudRain, RefreshCw, MapPin, Snowflake, Wind, Eye, Droplets } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';

interface WeatherData {
  location: string;
  temperature: number;
  condition: string;
  humidity: number;
  windSpeed: number;
  icon: string;
}

export const WeatherCard: React.FC = () => {
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchWeather = async () => {
    setLoading(true);
    setError(null);
    
    try {
      console.log('Fetching weather data...');
      
      // Try to get user's location
      let lat = 40.7128; // Default to NYC
      let lon = -74.0060;
      
      try {
        const position = await new Promise<GeolocationPosition>((resolve, reject) => {
          navigator.geolocation.getCurrentPosition(resolve, reject, { timeout: 5000 });
        });
        lat = position.coords.latitude;
        lon = position.coords.longitude;
        console.log(`Using user location: ${lat}, ${lon}`);
      } catch (geoError) {
        console.log('Geolocation not available, using default location');
      }
      
      const { data, error } = await supabase.functions.invoke('weather-data', {
        body: { lat, lon }
      });
      
      if (error) {
        console.error('Error fetching weather:', error);
        throw error;
      }
      
      console.log('Weather data received:', data);
      setWeather(data.weather);
    } catch (err) {
      console.error('Weather fetch error:', err);
      setError('Unable to fetch weather data');
      
      // Fallback to mock data
      const mockWeather: WeatherData = {
        location: "Your Location",
        temperature: Math.floor(Math.random() * 15) + 15,
        condition: "Partly Cloudy",
        humidity: Math.floor(Math.random() * 40) + 40,
        windSpeed: Math.floor(Math.random() * 15) + 5,
        icon: "Clouds"
      };
      setWeather(mockWeather);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchWeather();
  }, []);

  const getWeatherIcon = (condition: string) => {
    const iconType = condition.toLowerCase();
    if (iconType.includes('clear') || iconType.includes('sun')) 
      return <Sun className="h-12 w-12 text-yellow-500" />;
    if (iconType.includes('rain') || iconType.includes('drizzle')) 
      return <CloudRain className="h-12 w-12 text-blue-500" />;
    if (iconType.includes('snow')) 
      return <Snowflake className="h-12 w-12 text-blue-200" />;
    if (iconType.includes('mist') || iconType.includes('fog')) 
      return <Eye className="h-12 w-12 text-gray-400" />;
    return <Cloud className="h-12 w-12 text-gray-500" />;
  };

  const getWeatherBackground = (condition: string) => {
    const iconType = condition.toLowerCase();
    if (iconType.includes('clear') || iconType.includes('sun')) 
      return "bg-gradient-to-br from-yellow-100 to-orange-100 dark:from-yellow-900/30 dark:to-orange-900/30";
    if (iconType.includes('rain') || iconType.includes('drizzle')) 
      return "bg-gradient-to-br from-blue-100 to-gray-100 dark:from-blue-900/30 dark:to-gray-900/30";
    if (iconType.includes('snow')) 
      return "bg-gradient-to-br from-blue-50 to-white dark:from-blue-900/20 dark:to-gray-900/20";
    if (iconType.includes('mist') || iconType.includes('fog')) 
      return "bg-gradient-to-br from-gray-100 to-gray-200 dark:from-gray-800/30 dark:to-gray-900/30";
    return "bg-gradient-to-br from-gray-100 to-blue-100 dark:from-gray-800/30 dark:to-blue-900/30";
  };

  return (
    <Card className={`transition-all duration-500 ${weather ? getWeatherBackground(weather.icon) : ''}`}>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center">
            <MapPin className="mr-2 h-5 w-5 text-primary" />
            Live Weather
          </div>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={fetchWeather}
            disabled={loading}
          >
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="animate-pulse space-y-3">
            <div className="h-16 bg-muted rounded"></div>
            <div className="h-4 bg-muted rounded w-3/4"></div>
            <div className="h-4 bg-muted rounded w-1/2"></div>
          </div>
        ) : error ? (
          <div className="text-center py-4">
            <p className="text-sm text-muted-foreground mb-2">{error}</p>
            <Button size="sm" onClick={fetchWeather}>
              Try Again
            </Button>
          </div>
        ) : weather ? (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <div className="text-3xl font-bold mb-1">{weather.temperature}°C</div>
                <div className="text-sm font-medium capitalize mb-1">{weather.condition}</div>
                <div className="text-xs text-muted-foreground flex items-center">
                  <MapPin className="h-3 w-3 mr-1" />
                  {weather.location}
                </div>
              </div>
              <div className="flex items-center justify-center">
                {getWeatherIcon(weather.icon)}
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4 text-sm border-t pt-4">
              <div className="flex items-center space-x-2">
                <Droplets className="h-4 w-4 text-blue-500" />
                <div>
                  <div className="text-muted-foreground">Humidity</div>
                  <div className="font-medium">{weather.humidity}%</div>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Wind className="h-4 w-4 text-gray-500" />
                <div>
                  <div className="text-muted-foreground">Wind</div>
                  <div className="font-medium">{weather.windSpeed} km/h</div>
                </div>
              </div>
            </div>
          </div>
        ) : null}
      </CardContent>
    </Card>
  );
};
