import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Newspaper, ExternalLink, RefreshCw, Trophy, Target } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useIsMobile } from '@/hooks/use-mobile';

interface NewsItem {
  title: string;
  description: string;
  url: string;
  publishedAt: string;
  source: string;
  urlToImage?: string;
  category?: string;
}

interface ScoreItem {
  match: string;
  status: string;
  score: string;
  result?: string;
  venue?: string;
  format?: string;
}

export const SportsNewsCard: React.FC = () => {
  const isMobile = useIsMobile();
  const [news, setNews] = useState<NewsItem[]>([]);
  const [scores, setScores] = useState<ScoreItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [scoresLoading, setScoresLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'news' | 'scores'>('news');

  const fetchSportsNews = async () => {
    setLoading(true);
    setError(null);
    
    try {
      console.log('Fetching sports news...');
      const { data, error } = await supabase.functions.invoke('sports-news');
      
      if (error) {
        console.error('Error fetching sports news:', error);
        throw error;
      }

      console.log('Sports news data received:', data);
      
      // Filter out articles older than 30 days and prioritize cricket
      const thirtyDaysAgo = Date.now() - (30 * 24 * 60 * 60 * 1000);
      const recentNews = (data.news || []).filter((item: NewsItem) => 
        new Date(item.publishedAt).getTime() > thirtyDaysAgo
      );
      
      // Sort to prioritize cricket news
      const sortedNews = recentNews.sort((a: NewsItem, b: NewsItem) => {
        const aCricket = a.category === 'cricket' || 
          a.title.toLowerCase().includes('cricket') || 
          a.title.toLowerCase().includes('ipl') ||
          a.title.toLowerCase().includes('t20');
        const bCricket = b.category === 'cricket' || 
          b.title.toLowerCase().includes('cricket') || 
          b.title.toLowerCase().includes('ipl') ||
          b.title.toLowerCase().includes('t20');
        
        if (aCricket && !bCricket) return -1;
        if (!aCricket && bCricket) return 1;
        return new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime();
      });
      
      setNews(sortedNews);
      
    } catch (err) {
      console.error('Error fetching sports news:', err);
      setError('Failed to fetch sports news');
      
      // Enhanced fallback data with more cricket focus
      setNews([
        {
          title: "IPL 2024: Latest Match Results and Top Performers",
          description: "Comprehensive coverage of recent IPL matches with detailed player analysis, team standings, and upcoming fixtures.",
          url: "https://www.iplt20.com",
          publishedAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
          source: "IPL Official",
          category: "cricket"
        },
        {
          title: "India vs Australia Test Series: Day 2 Highlights",
          description: "Complete coverage of the ongoing Test match with live updates, player performances and expert analysis.",
          url: "https://www.espncricinfo.com",
          publishedAt: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString(),
          source: "ESPNCricinfo",
          category: "cricket"
        },
        {
          title: "T20 World Cup 2024: Team Preparations and Squad Updates",
          description: "Latest updates on team preparations and squad announcements for the upcoming T20 World Cup.",
          url: "https://www.icc-cricket.com",
          publishedAt: new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString(),
          source: "ICC Cricket",
          category: "cricket"
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const fetchCricketScores = async () => {
    setScoresLoading(true);
    
    try {
      console.log('Fetching cricket scores...');
      const { data, error } = await supabase.functions.invoke('cricket-scores');
      
      if (error) {
        console.error('Error fetching cricket scores:', error);
        throw error;
      }

      console.log('Cricket scores data received:', data);
      setScores(data.scores || []);
      
    } catch (err) {
      console.error('Error fetching cricket scores:', err);
      
      // Enhanced fallback scores
      setScores([
        {
          match: "India vs Australia - 1st Test",
          status: "Day 2, Session 2",
          score: "IND: 245/4 (78.2 ov)",
          result: "India trailing by 89 runs",
          venue: "Adelaide Oval",
          format: "Test"
        },
        {
          match: "England vs New Zealand - ODI",
          status: "Match Finished",
          score: "ENG: 287/5 | NZ: 291/7",
          result: "New Zealand won by 3 wickets",
          venue: "Lord's",
          format: "ODI"
        },
        {
          match: "Mumbai Indians vs CSK - IPL",
          status: "Live",
          score: "MI: 156/6 (18.4 ov)",
          result: "Target: 182 runs",
          venue: "Wankhede Stadium",
          format: "T20"
        }
      ]);
    } finally {
      setScoresLoading(false);
    }
  };

  useEffect(() => {
    fetchSportsNews();
    fetchCricketScores();
  }, []);

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return 'Just now';
    if (diffInHours < 24) return `${diffInHours}h ago`;
    const diffInDays = Math.floor(diffInHours / 24);
    if (diffInDays < 30) return `${diffInDays}d ago`;
    return 'Over a month ago';
  };

  const isRecentNews = (dateString: string) => {
    const thirtyDaysAgo = Date.now() - (30 * 24 * 60 * 60 * 1000);
    return new Date(dateString).getTime() > thirtyDaysAgo;
  };

  const handleReadMore = (url: string) => {
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const getCategoryColor = (category?: string) => {
    return category === 'cricket' ? 'bg-orange-500' : 'bg-blue-500';
  };

  const getScoreStatusColor = (status: string) => {
    if (status.toLowerCase().includes('live')) return 'bg-green-500';
    if (status.toLowerCase().includes('finished')) return 'bg-gray-500';
    return 'bg-blue-500';
  };

  const handleRefresh = () => {
    if (activeTab === 'news') {
      fetchSportsNews();
    } else {
      fetchCricketScores();
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center">
            <Newspaper className="mr-2 h-5 w-5 text-primary" />
            Sports Updates
          </div>
          <div className="flex items-center gap-2">
            <div className="flex bg-muted rounded-lg p-1">
              <Button
                variant={activeTab === 'news' ? 'default' : 'ghost'}
                size="sm"
                className={`h-7 px-2 sm:px-3 text-xs ${isMobile ? 'flex-1' : ''}`}
                onClick={() => setActiveTab('news')}
              >
                <Newspaper className="h-3 w-3 mr-1" />
                {!isMobile && 'News'}
              </Button>
              <Button
                variant={activeTab === 'scores' ? 'default' : 'ghost'}
                size="sm"
                className={`h-7 px-2 sm:px-3 text-xs ${isMobile ? 'flex-1' : ''}`}
                onClick={() => setActiveTab('scores')}
              >
                <Target className="h-3 w-3 mr-1" />
                {!isMobile && 'Scores'}
              </Button>
            </div>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={handleRefresh}
              disabled={loading || scoresLoading}
            >
              <RefreshCw className={`h-4 w-4 ${(loading || scoresLoading) ? 'animate-spin' : ''}`} />
            </Button>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {(loading && activeTab === 'news') || (scoresLoading && activeTab === 'scores') ? (
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="animate-pulse">
                <div className="h-4 bg-muted rounded w-3/4 mb-2"></div>
                <div className="h-3 bg-muted rounded w-full"></div>
              </div>
            ))}
          </div>
        ) : error && activeTab === 'news' ? (
          <div className="text-center py-4">
            <p className="text-sm text-muted-foreground mb-2">{error}</p>
            <Button size="sm" onClick={fetchSportsNews}>
              Try Again
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            {activeTab === 'news' ? (
              <>
                {news.slice(0, 5).map((item, index) => (
                  <div key={index} className="border-b border-border pb-3 last:border-b-0 last:pb-0">
                    <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between mb-2 gap-2">
                      <h4 className="text-sm font-medium line-clamp-2 flex-1 cursor-pointer hover:text-primary" 
                          onClick={() => handleReadMore(item.url)}>
                        {item.title}
                      </h4>
                      <div className="flex items-center space-x-1">
                        {item.category && (
                          <div className={`w-2 h-2 rounded-full ${getCategoryColor(item.category)}`}></div>
                        )}
                        <Badge 
                          variant={isRecentNews(item.publishedAt) ? "default" : "secondary"} 
                          className="text-xs"
                        >
                          {formatTimeAgo(item.publishedAt)}
                        </Badge>
                      </div>
                    </div>
                    <p className="text-xs text-muted-foreground mb-2 line-clamp-2">
                      {item.description}
                    </p>
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                      <div className="flex items-center space-x-2">
                        <span className="text-xs text-muted-foreground">{item.source}</span>
                        {item.category === 'cricket' && (
                          <Badge variant="outline" className="text-xs bg-orange-50 text-orange-600">
                            Cricket
                          </Badge>
                        )}
                      </div>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="h-6 px-2 text-xs self-end sm:self-auto"
                        onClick={() => handleReadMore(item.url)}
                      >
                        <ExternalLink className="h-3 w-3 mr-1" />
                        Read more
                      </Button>
                    </div>
                  </div>
                ))}
                {news.length === 0 && (
                  <div className="text-center py-4">
                    <p className="text-sm text-muted-foreground">No recent sports news available</p>
                  </div>
                )}
              </>
            ) : (
              <>
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-3 gap-2">
                  <h4 className="text-sm font-medium flex items-center">
                    <Trophy className="h-4 w-4 mr-1 text-orange-500" />
                    Live Cricket Scores
                  </h4>
                  <Badge variant="outline" className="text-xs self-start sm:self-auto">
                    Updated now
                  </Badge>
                </div>
                {scores.map((score, index) => (
                  <div key={index} className="border-b border-border pb-3 last:border-b-0 last:pb-0">
                    <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between mb-2 gap-2">
                      <div className="flex-1">
                        <h5 className="text-sm font-medium">{score.match}</h5>
                        {score.venue && (
                          <p className="text-xs text-muted-foreground">{score.venue}</p>
                        )}
                      </div>
                      <div className="flex items-center space-x-2">
                        {score.format && (
                          <Badge variant="outline" className="text-xs">
                            {score.format}
                          </Badge>
                        )}
                        <Badge 
                          className={`text-xs text-white ${getScoreStatusColor(score.status)}`}
                        >
                          {score.status}
                        </Badge>
                      </div>
                    </div>
                    <p className="text-sm font-mono text-foreground mb-1 break-all sm:break-normal">{score.score}</p>
                    {score.result && (
                      <p className="text-xs text-muted-foreground">{score.result}</p>
                    )}
                  </div>
                ))}
                {scores.length === 0 && (
                  <div className="text-center py-4">
                    <p className="text-sm text-muted-foreground">No cricket scores available</p>
                  </div>
                )}
              </>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
};
