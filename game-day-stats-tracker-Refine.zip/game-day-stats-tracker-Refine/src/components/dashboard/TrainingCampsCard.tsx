
import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { MapPin, Calendar, Users, Zap, Plus } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

interface TrainingCamp {
  id: string;
  title: string;
  description: string;
  sport: string;
  location: string;
  event_date: string;
  organizer: {
    full_name: string;
  };
  participants_count: number;
}

export const TrainingCampsCard: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [camps, setCamps] = useState<TrainingCamp[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchTrainingCamps();
  }, []);

  const fetchTrainingCamps = async () => {
    try {
      const { data, error } = await supabase
        .from('events')
        .select(`
          id,
          title,
          description,
          sport,
          location,
          event_date,
          organizer:profiles!events_organizer_id_fkey(full_name),
          participants:event_participants(count)
        `)
        .ilike('title', '%training%')
        .or('title.ilike.%camp%,description.ilike.%training%,description.ilike.%camp%')
        .gte('event_date', new Date().toISOString())
        .order('event_date', { ascending: true })
        .limit(3);

      if (error) throw error;

      const formattedCamps = (data || []).map(camp => ({
        ...camp,
        participants_count: camp.participants?.[0]?.count || 0
      }));

      setCamps(formattedCamps);
    } catch (error) {
      console.error('Error fetching training camps:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Zap className="mr-2 h-5 w-5" />
            Training Camps
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="space-y-2">
              <Skeleton className="h-4 w-3/4" />
              <Skeleton className="h-3 w-1/2" />
            </div>
          ))}
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="hover:shadow-lg transition-shadow duration-200">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center">
            <Zap className="mr-2 h-5 w-5 text-orange-500" />
            Training Camps
          </div>
          <Button
            size="sm"
            variant="outline"
            onClick={() => navigate('/create-event')}
          >
            <Plus className="h-4 w-4" />
          </Button>
        </CardTitle>
        <CardDescription>
          Skill development sessions and training programs
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        {camps.length === 0 ? (
          <div className="text-center py-4">
            <Zap className="mx-auto h-12 w-12 text-muted-foreground mb-2" />
            <p className="text-muted-foreground text-sm">No training camps available</p>
            <Button 
              size="sm" 
              variant="outline" 
              className="mt-2"
              onClick={() => navigate('/create-event')}
            >
              Create Training Camp
            </Button>
          </div>
        ) : (
          camps.map((camp) => (
            <div
              key={camp.id}
              className="border rounded-lg p-3 hover:bg-muted/50 cursor-pointer transition-colors duration-200"
              onClick={() => navigate(`/event/${camp.id}`)}
            >
              <div className="flex justify-between items-start mb-2">
                <h4 className="font-medium text-sm line-clamp-1">{camp.title}</h4>
                <Badge variant="secondary" className="text-xs">
                  {camp.sport}
                </Badge>
              </div>
              <p className="text-xs text-muted-foreground line-clamp-2 mb-2">
                {camp.description}
              </p>
              <div className="flex items-center justify-between text-xs text-muted-foreground">
                <div className="flex items-center space-x-3">
                  <div className="flex items-center">
                    <MapPin className="mr-1 h-3 w-3" />
                    {camp.location}
                  </div>
                  <div className="flex items-center">
                    <Calendar className="mr-1 h-3 w-3" />
                    {formatDate(camp.event_date)}
                  </div>
                </div>
                <div className="flex items-center">
                  <Users className="mr-1 h-3 w-3" />
                  {camp.participants_count}
                </div>
              </div>
            </div>
          ))
        )}
        
        {camps.length > 0 && (
          <Button 
            variant="outline" 
            size="sm" 
            className="w-full mt-3"
            onClick={() => navigate('/events')}
          >
            View All Training Camps
          </Button>
        )}
      </CardContent>
    </Card>
  );
};
