
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { TrendingUp, Award, Target } from 'lucide-react';

interface PerformanceMetrics {
  speed: number;
  endurance: number;
  technique: number;
  teamwork: number;
  leadership: number;
}

export const PerformanceTracker: React.FC = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedEvent, setSelectedEvent] = useState('');
  const [selectedSport, setSelectedSport] = useState('');
  const [metrics, setMetrics] = useState<PerformanceMetrics>({
    speed: 50,
    endurance: 50,
    technique: 50,
    teamwork: 50,
    leadership: 50
  });
  const [saving, setSaving] = useState(false);

  const handleSavePerformance = async () => {
    if (!user || !selectedSport) {
      toast({
        title: "Missing information",
        description: "Please select a sport",
        variant: "destructive"
      });
      return;
    }

    setSaving(true);
    try {
      const { error } = await supabase
        .from('player_performance_stats')
        .insert({
          player_id: user.id,
          event_id: selectedEvent || null,
          sport: selectedSport,
          performance_metrics: metrics as any, // Cast to any to satisfy Json type
          individual_rating: Math.round(Object.values(metrics).reduce((a, b) => a + b, 0) / 5),
          recorded_by: user.id
        });

      if (error) {
        console.error('Error saving performance:', error);
        throw error;
      }

      toast({
        title: "Performance recorded",
        description: "Your performance stats have been saved successfully"
      });

      // Reset form
      setSelectedEvent('');
      setSelectedSport('');
      setMetrics({
        speed: 50,
        endurance: 50,
        technique: 50,
        teamwork: 50,
        leadership: 50
      });
    } catch (error: any) {
      console.error('Error saving performance:', error);
      toast({
        title: "Error",
        description: "Failed to save performance stats",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  const updateMetric = (key: keyof PerformanceMetrics, value: number[]) => {
    setMetrics(prev => ({ ...prev, [key]: value[0] }));
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <TrendingUp className="mr-2 h-5 w-5" />
          Performance Tracker
        </CardTitle>
        <CardDescription>
          Record and track your athletic performance
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label htmlFor="event">Event ID (optional)</Label>
            <Input
              placeholder="Enter event ID"
              value={selectedEvent}
              onChange={(e) => setSelectedEvent(e.target.value)}
            />
          </div>
          <div>
            <Label htmlFor="sport">Sport</Label>
            <Select value={selectedSport} onValueChange={setSelectedSport}>
              <SelectTrigger>
                <SelectValue placeholder="Select sport" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="football">Football</SelectItem>
                <SelectItem value="basketball">Basketball</SelectItem>
                <SelectItem value="tennis">Tennis</SelectItem>
                <SelectItem value="soccer">Soccer</SelectItem>
                <SelectItem value="volleyball">Volleyball</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-4">
          <div className="text-sm font-medium">Performance Metrics (0-100)</div>
          
          {Object.entries(metrics).map(([key, value]) => (
            <div key={key} className="space-y-2">
              <div className="flex justify-between">
                <Label className="capitalize">{key}</Label>
                <span className="text-sm text-muted-foreground">{value}</span>
              </div>
              <Slider
                value={[value]}
                onValueChange={(newValue) => updateMetric(key as keyof PerformanceMetrics, newValue)}
                max={100}
                step={1}
                className="w-full"
              />
            </div>
          ))}
        </div>

        <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
          <div className="flex items-center space-x-2">
            <Award className="h-5 w-5 text-primary" />
            <span className="font-medium">Overall Rating</span>
          </div>
          <span className="text-xl font-bold">
            {Math.round(Object.values(metrics).reduce((a, b) => a + b, 0) / 5)}
          </span>
        </div>

        <Button 
          onClick={handleSavePerformance}
          disabled={saving || !selectedSport}
          className="w-full"
        >
          <Target className="mr-2 h-4 w-4" />
          {saving ? 'Saving...' : 'Record Performance'}
        </Button>
      </CardContent>
    </Card>
  );
};
