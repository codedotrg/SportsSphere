
import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { useSecureRequirementOperations } from '@/hooks/useSecureRequirementOperations';

interface Event {
  id: string;
  title: string;
  sport: string;
}

const CreateRequirementForm: React.FC = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const { createRequirement, fetchUserEvents, loading, validationErrors, events } = useSecureRequirementOperations();
  const [formData, setFormData] = useState({
    event_id: '',
    role_name: '',
    description: '',
    experience_level: '',
    max_players: ''
  });

  useEffect(() => {
    if (user) {
      fetchUserEvents();
    }
  }, [user, fetchUserEvents]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name: string, value: string) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !formData.event_id || !formData.role_name) return;

    const success = await createRequirement({
      event_id: formData.event_id,
      role_name: formData.role_name,
      description: formData.description,
      experience_level: formData.experience_level,
      max_players: formData.max_players ? parseInt(formData.max_players) : undefined
    });

    if (success) {
      // Reset form
      setFormData({
        event_id: '',
        role_name: '',
        description: '',
        experience_level: '',
        max_players: ''
      });
    }
  };

  if (events.length === 0) {
    return (
      <Card>
        <CardContent className="text-center py-8">
          <h3 className="text-lg font-semibold mb-2">No Events Found</h3>
          <p className="text-muted-foreground">
            You need to create an event first before adding player requirements.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Create Player Requirement</CardTitle>
        <CardDescription>
          Define specific player roles and requirements for your events.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="event_id">Select Event *</Label>
            <Select value={formData.event_id} onValueChange={(value) => handleSelectChange('event_id', value)}>
              <SelectTrigger>
                <SelectValue placeholder="Choose an event" />
              </SelectTrigger>
              <SelectContent>
                {events.map((event) => (
                  <SelectItem key={event.id} value={event.id}>
                    {event.title} - {event.sport}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {validationErrors.event_id && (
              <p className="text-sm text-red-600">{validationErrors.event_id}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="role_name">Role Name *</Label>
            <Input
              id="role_name"
              name="role_name"
              value={formData.role_name}
              onChange={handleInputChange}
              placeholder="Point Guard, Goalkeeper, etc."
              required
              maxLength={100}
            />
            {validationErrors.role_name && (
              <p className="text-sm text-red-600">{validationErrors.role_name}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Role Description</Label>
            <Textarea
              id="description"
              name="description"
              value={formData.description}
              onChange={handleInputChange}
              placeholder="Describe the responsibilities and skills needed for this role..."
              rows={3}
              maxLength={2000}
            />
            {validationErrors.description && (
              <p className="text-sm text-red-600">{validationErrors.description}</p>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="experience_level">Experience Level</Label>
              <Select value={formData.experience_level} onValueChange={(value) => handleSelectChange('experience_level', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select experience level" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="beginner">Beginner</SelectItem>
                  <SelectItem value="intermediate">Intermediate</SelectItem>
                  <SelectItem value="advanced">Advanced</SelectItem>
                  <SelectItem value="professional">Professional</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="max_players">Max Players for this Role</Label>
              <Input
                id="max_players"
                name="max_players"
                type="number"
                value={formData.max_players}
                onChange={handleInputChange}
                placeholder="1"
                min="1"
                max="50"
              />
              {validationErrors.max_players && (
                <p className="text-sm text-red-600">{validationErrors.max_players}</p>
              )}
            </div>
          </div>

          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? 'Creating Requirement...' : 'Create Requirement'}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};

export default CreateRequirementForm;
