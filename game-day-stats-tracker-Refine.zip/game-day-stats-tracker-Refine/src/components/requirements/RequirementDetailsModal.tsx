
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Trash2, Edit, Save, X, CheckCircle, RotateCcw } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';

interface Requirement {
  id: string;
  role_name: string;
  description: string;
  experience_level: string;
  max_players: number;
  created_at: string;
  is_completed: boolean;
  event: {
    id: string;
    title: string;
    sport: string;
    event_date: string;
    location: string;
  };
}

interface RequirementDetailsModalProps {
  requirementId: string;
  onClose: () => void;
}

export const RequirementDetailsModal: React.FC<RequirementDetailsModalProps> = ({
  requirementId,
  onClose
}) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [requirement, setRequirement] = useState<Requirement | null>(null);
  const [loading, setLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState({
    role_name: '',
    description: '',
    experience_level: '',
    max_players: 1
  });

  const fetchRequirement = async () => {
    try {
      const { data, error } = await supabase
        .from('player_requirements')
        .select(`
          id,
          role_name,
          description,
          experience_level,
          max_players,
          created_at,
          is_completed,
          event:events (
            id,
            title,
            sport,
            event_date,
            location
          )
        `)
        .eq('id', requirementId)
        .single();

      if (error) throw error;
      setRequirement(data);
      setEditForm({
        role_name: data.role_name,
        description: data.description || '',
        experience_level: data.experience_level || '',
        max_players: data.max_players || 1
      });
    } catch (error) {
      console.error('Error fetching requirement:', error);
      toast({
        title: "Error",
        description: "Failed to load requirement details",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleUpdate = async () => {
    try {
      const { error } = await supabase
        .from('player_requirements')
        .update({
          role_name: editForm.role_name,
          description: editForm.description,
          experience_level: editForm.experience_level,
          max_players: editForm.max_players,
          updated_at: new Date().toISOString()
        })
        .eq('id', requirementId);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Requirement updated successfully!"
      });

      setIsEditing(false);
      fetchRequirement();
    } catch (error) {
      console.error('Error updating requirement:', error);
      toast({
        title: "Error",
        description: "Failed to update requirement",
        variant: "destructive"
      });
    }
  };

  const handleDelete = async () => {
    if (!confirm('Are you sure you want to delete this requirement?')) return;

    try {
      const { error } = await supabase
        .from('player_requirements')
        .delete()
        .eq('id', requirementId);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Requirement deleted successfully!"
      });

      onClose();
    } catch (error) {
      console.error('Error deleting requirement:', error);
      toast({
        title: "Error",
        description: "Failed to delete requirement",
        variant: "destructive"
      });
    }
  };

  const markAsCompleted = async () => {
    try {
      const { error } = await supabase
        .from('player_requirements')
        .update({ is_completed: true })
        .eq('id', requirementId);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Requirement marked as completed!"
      });

      fetchRequirement();
    } catch (error) {
      console.error('Error marking requirement as completed:', error);
      toast({
        title: "Error",
        description: "Failed to update requirement status",
        variant: "destructive"
      });
    }
  };

  const reopenRequirement = async () => {
    try {
      const { error } = await supabase
        .from('player_requirements')
        .update({ is_completed: false })
        .eq('id', requirementId);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Requirement has been reopened!"
      });

      fetchRequirement();
    } catch (error) {
      console.error('Error reopening requirement:', error);
      toast({
        title: "Error",
        description: "Failed to reopen requirement",
        variant: "destructive"
      });
    }
  };

  const isEventPast = () => {
    if (!requirement) return false;
    return new Date(requirement.event.event_date) < new Date();
  };

  useEffect(() => {
    fetchRequirement();
  }, [requirementId]);

  if (loading) {
    return <div className="text-center py-8">Loading requirement details...</div>;
  }

  if (!requirement) {
    return <div className="text-center py-8">Requirement not found</div>;
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex justify-between items-start">
            <div>
              <CardTitle className="flex items-center space-x-2">
                <span>{requirement.role_name}</span>
                {requirement.is_completed && (
                  <Badge variant="secondary" className="bg-green-100 text-green-800">
                    <CheckCircle className="w-3 h-3 mr-1" />
                    Completed
                  </Badge>
                )}
                {isEventPast() && (
                  <Badge variant="outline" className="bg-gray-100 text-gray-600">
                    Past Event
                  </Badge>
                )}
              </CardTitle>
              <p className="text-sm text-muted-foreground mt-1">
                Event: {requirement.event.title}
              </p>
            </div>
            <div className="flex space-x-2">
              {requirement.is_completed && !isEventPast() && (
                <Button
                  size="sm"
                  variant="outline"
                  onClick={reopenRequirement}
                >
                  <RotateCcw className="w-4 h-4 mr-1" />
                  Reopen
                </Button>
              )}
              {!requirement.is_completed && (
                <Button
                  size="sm"
                  variant="outline"
                  onClick={markAsCompleted}
                >
                  <CheckCircle className="w-4 h-4 mr-1" />
                  Mark Complete
                </Button>
              )}
              {!isEditing ? (
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setIsEditing(true)}
                >
                  <Edit className="w-4 h-4" />
                </Button>
              ) : (
                <div className="flex space-x-1">
                  <Button size="sm" onClick={handleUpdate}>
                    <Save className="w-4 h-4" />
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setIsEditing(false)}
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              )}
              <Button
                size="sm"
                variant="destructive"
                onClick={handleDelete}
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {isEditing ? (
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">Role Name</label>
                <Input
                  value={editForm.role_name}
                  onChange={(e) => setEditForm({ ...editForm, role_name: e.target.value })}
                />
              </div>
              <div>
                <label className="text-sm font-medium">Description</label>
                <Textarea
                  value={editForm.description}
                  onChange={(e) => setEditForm({ ...editForm, description: e.target.value })}
                />
              </div>
              <div>
                <label className="text-sm font-medium">Experience Level</label>
                <Select
                  value={editForm.experience_level}
                  onValueChange={(value) => setEditForm({ ...editForm, experience_level: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="beginner">Beginner</SelectItem>
                    <SelectItem value="intermediate">Intermediate</SelectItem>
                    <SelectItem value="advanced">Advanced</SelectItem>
                    <SelectItem value="professional">Professional</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium">Max Players</label>
                <Input
                  type="number"
                  min="1"
                  value={editForm.max_players}
                  onChange={(e) => setEditForm({ ...editForm, max_players: parseInt(e.target.value) })}
                />
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Description</p>
                <p>{requirement.description || 'No description provided'}</p>
              </div>
              <div className="flex space-x-4">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Experience Level</p>
                  <Badge variant="outline">{requirement.experience_level || 'Not specified'}</Badge>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Max Players</p>
                  <Badge variant="outline">{requirement.max_players}</Badge>
                </div>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Event Details</p>
                <div className="text-sm">
                  <p><strong>Sport:</strong> {requirement.event.sport}</p>
                  <p><strong>Date:</strong> {new Date(requirement.event.event_date).toLocaleDateString()}</p>
                  <p><strong>Location:</strong> {requirement.event.location}</p>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};
