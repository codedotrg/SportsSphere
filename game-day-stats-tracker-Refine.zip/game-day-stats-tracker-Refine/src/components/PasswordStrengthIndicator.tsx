
import React from 'react';
import { CheckCircle, XCircle } from 'lucide-react';

interface PasswordStrengthIndicatorProps {
  password: string;
  requirements: {
    length: boolean;
    uppercase: boolean;
    lowercase: boolean;
    number: boolean;
    special: boolean;
  };
  score: number;
}

export const PasswordStrengthIndicator: React.FC<PasswordStrengthIndicatorProps> = ({
  password,
  requirements,
  score
}) => {
  if (!password) return null;

  const getStrengthColor = (score: number) => {
    if (score <= 2) return 'bg-red-500';
    if (score <= 3) return 'bg-yellow-500';
    if (score <= 4) return 'bg-blue-500';
    return 'bg-green-500';
  };

  const getStrengthText = (score: number) => {
    if (score <= 2) return 'Weak';
    if (score <= 3) return 'Fair';
    if (score <= 4) return 'Good';
    return 'Strong';
  };

  return (
    <div className="mt-2 space-y-2">
      <div className="flex items-center space-x-2">
        <span className="text-sm font-medium">Password Strength:</span>
        <div className="flex-1 bg-gray-200 rounded-full h-2">
          <div
            className={`h-2 rounded-full transition-all duration-300 ${getStrengthColor(score)}`}
            style={{ width: `${(score / 5) * 100}%` }}
          />
        </div>
        <span className={`text-sm font-medium ${
          score <= 2 ? 'text-red-600' :
          score <= 3 ? 'text-yellow-600' :
          score <= 4 ? 'text-blue-600' : 'text-green-600'
        }`}>
          {getStrengthText(score)}
        </span>
      </div>
      
      <div className="space-y-1">
        <RequirementItem met={requirements.length} text="At least 8 characters" />
        <RequirementItem met={requirements.uppercase} text="One uppercase letter" />
        <RequirementItem met={requirements.lowercase} text="One lowercase letter" />
        <RequirementItem met={requirements.number} text="One number" />
        <RequirementItem met={requirements.special} text="One special character" />
      </div>
    </div>
  );
};

const RequirementItem: React.FC<{ met: boolean; text: string }> = ({ met, text }) => (
  <div className="flex items-center space-x-2 text-sm">
    {met ? (
      <CheckCircle className="h-4 w-4 text-green-500" />
    ) : (
      <XCircle className="h-4 w-4 text-red-500" />
    )}
    <span className={met ? 'text-green-700' : 'text-red-700'}>{text}</span>
  </div>
);
