
import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import { UserSettingsDropdown } from '@/components/UserSettingsDropdown';
import { ThemeToggle } from '@/components/theme/ThemeToggle';
import { NotificationDropdown } from '@/components/notifications/NotificationDropdown';
import { Trophy, Calendar, Users, MessageCircle, User } from 'lucide-react';

export const Navbar: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();

  const handleLogoClick = () => {
    if (user) {
      navigate('/dashboard');
    } else {
      navigate('/');
    }
  };

  return (
    <nav className="bg-background border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div 
            onClick={handleLogoClick}
            className="flex items-center space-x-2 cursor-pointer hover:opacity-80 transition-opacity"
          >
            <Trophy className="h-6 w-6 text-primary" />
            <span className="font-bold text-lg">SportSphere</span>
          </div>

          {user ? (
            <div className="flex items-center space-x-4">
              <nav className="hidden md:flex space-x-4">
                <Button variant="ghost" asChild>
                  <Link to="/dashboard" className="flex items-center">
                    <Trophy className="mr-2 h-4 w-4" />
                    Dashboard
                  </Link>
                </Button>
                <Button variant="ghost" asChild>
                  <Link to="/events" className="flex items-center">
                    <Calendar className="mr-2 h-4 w-4" />
                    Events
                  </Link>
                </Button>
                <Button variant="ghost" asChild>
                  <Link to="/messages" className="flex items-center">
                    <MessageCircle className="mr-2 h-4 w-4" />
                    Messages
                  </Link>
                </Button>
                <Button variant="ghost" asChild>
                  <Link to="/profile" className="flex items-center">
                    <User className="mr-2 h-4 w-4" />
                    Profile
                  </Link>
                </Button>
              </nav>
              
              <div className="flex items-center space-x-2">
                <NotificationDropdown />
                <ThemeToggle />
                <UserSettingsDropdown />
              </div>
            </div>
          ) : (
            <div className="flex items-center space-x-4">
              <ThemeToggle />
              <Button onClick={() => navigate('/auth')}>
                Sign In
              </Button>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
};
