
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Users, Trophy, Calendar } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from "@/components/ui/use-toast";

interface RoleSelectionProps {
  onRoleSelected: () => void;
}

const RoleSelection: React.FC<RoleSelectionProps> = ({ onRoleSelected }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [selectedRole, setSelectedRole] = useState<'player' | 'organizer' | null>(null);

  const handleRoleSelection = async (role: 'player' | 'organizer') => {
    setIsLoading(true);
    setSelectedRole(role);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('No user found');

      // Update user metadata with selected role
      const { error } = await supabase.auth.updateUser({
        data: { role: role }
      });

      if (error) throw error;

      toast({
        title: "Role Selected",
        description: `You've successfully chosen to be ${role === 'player' ? 'a player' : 'an organizer'}!`
      });

      onRoleSelected();
    } catch (error) {
      const supabaseError = error as { message?: string };
      toast({
        title: "Error",
        description: supabaseError.message || "Failed to update role",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
      setSelectedRole(null);
    }
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-3xl font-bold mb-4">Choose Your Role</h2>
        <p className="text-muted-foreground">Select how you'd like to participate in SportSphere. You can always change this later.</p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <Card className="cursor-pointer hover:shadow-lg transition-shadow">
          <CardHeader className="text-center">
            <Trophy className="h-16 w-16 text-primary mx-auto mb-4" />
            <CardTitle>Join as a Player</CardTitle>
            <CardDescription>
              Participate in events, track your performance, and compete with other players.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button 
              className="w-full" 
              onClick={() => handleRoleSelection('player')}
              disabled={isLoading}
              variant={selectedRole === 'player' ? "secondary" : "default"}
            >
              {isLoading && selectedRole === 'player' ? 'Selecting...' : 'Become a Player'}
            </Button>
          </CardContent>
        </Card>

        <Card className="cursor-pointer hover:shadow-lg transition-shadow">
          <CardHeader className="text-center">
            <Calendar className="h-16 w-16 text-secondary mx-auto mb-4" />
            <CardTitle>Become an Organizer</CardTitle>
            <CardDescription>
              Create and manage sports events, rate players, and build communities.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button 
              className="w-full" 
              variant="secondary"
              onClick={() => handleRoleSelection('organizer')}
              disabled={isLoading}
            >
              {isLoading && selectedRole === 'organizer' ? 'Selecting...' : 'Become an Organizer'}
            </Button>
          </CardContent>
        </Card>
      </div>

      <div className="text-center">
        <Button variant="link" onClick={onRoleSelected} disabled={isLoading}>
          Skip for now (choose later in profile)
        </Button>
      </div>
    </div>
  );
};

export default RoleSelection;
