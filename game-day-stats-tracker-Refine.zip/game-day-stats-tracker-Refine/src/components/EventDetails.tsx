import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Calendar, MapPin, Users, Clock, User, MessageSquare } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useEventParticipants } from '@/hooks/useEventParticipants';
import { useAuth } from '@/contexts/AuthContext';
import { DirectMessageForm } from '@/components/messaging/DirectMessageForm';
import { EventOrganizerActions } from '@/components/events/EventOrganizerActions';

interface Event {
  id: string;
  title: string;
  description: string;
  sport: string;
  location: string;
  event_date: string;
  organizer_id: string;
  created_at: string;
}

interface EventDetailsProps {
  event: Event;
  onClose?: () => void;
  onEventDeleted?: () => void;
}

export const EventDetails: React.FC<EventDetailsProps> = ({ event, onClose, onEventDeleted }) => {
  const { user } = useAuth();
  const { participants, loading, isParticipating, joinEvent, leaveEvent } = useEventParticipants(event.id);
  const [actionLoading, setActionLoading] = useState(false);
  const [showMessageModal, setShowMessageModal] = useState(false);

  const formatDate = (dateString: string) => {
    try {
      return new Date(dateString).toLocaleDateString('en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch {
      return 'Invalid Date';
    }
  };

  const handleJoinLeave = async () => {
    setActionLoading(true);
    if (isParticipating) {
      await leaveEvent();
    } else {
      await joinEvent();
    }
    setActionLoading(false);
  };

  const handleEventEdit = () => {
    // TODO: Implement edit functionality
    console.log('Edit event:', event.id);
  };

  const handleEventDeleted = () => {
    onEventDeleted?.();
    onClose?.();
  };

  const isOrganizer = user?.id === event.organizer_id;

  return (
    <>
      <Card className="w-full max-w-2xl mx-auto">
        <CardHeader>
          <div className="flex justify-between items-start">
            <div className="space-y-2">
              <CardTitle className="text-2xl">{event.title}</CardTitle>
              <Badge variant="secondary" className="w-fit">
                {event.sport}
              </Badge>
            </div>
            <div className="flex items-center gap-2">
              {isOrganizer && (
                <EventOrganizerActions
                  eventId={event.id}
                  onEditClick={handleEventEdit}
                  onDeleteSuccess={handleEventDeleted}
                />
              )}
              {onClose && (
                <Button variant="outline" size="sm" onClick={onClose}>
                  Close
                </Button>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Event Details */}
          <div className="space-y-4">
            {event.description && (
              <div>
                <h4 className="font-semibold mb-2">Description</h4>
                <p className="text-muted-foreground">{event.description}</p>
              </div>
            )}
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-center space-x-2">
                <Calendar className="h-4 w-4 text-primary" />
                <span className="text-sm">{formatDate(event.event_date)}</span>
              </div>
              
              {event.location && (
                <div className="flex items-center space-x-2">
                  <MapPin className="h-4 w-4 text-primary" />
                  <span className="text-sm">{event.location}</span>
                </div>
              )}
              
              <div className="flex items-center space-x-2">
                <Users className="h-4 w-4 text-primary" />
                <span className="text-sm">{participants.length} participants</span>
              </div>
              
              <div className="flex items-center space-x-2">
                <Clock className="h-4 w-4 text-primary" />
                <span className="text-sm">Created {new Date(event.created_at).toLocaleDateString()}</span>
              </div>
            </div>
          </div>

          <Separator />

          {/* Participants List */}
          <div>
            <h4 className="font-semibold mb-3 flex items-center">
              <Users className="h-4 w-4 mr-2" />
              Participants ({participants.length})
            </h4>
            {loading ? (
              <p className="text-muted-foreground">Loading participants...</p>
            ) : participants.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {participants.map((participant) => (
                  <div key={participant.id} className="flex items-center space-x-2 p-2 bg-muted rounded">
                    <User className="h-4 w-4" />
                    <span className="text-sm">{participant.profile?.full_name || 'Unknown Player'}</span>
                    {participant.position_played && (
                      <Badge variant="outline" className="text-xs">
                        {participant.position_played}
                      </Badge>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-muted-foreground">No participants yet. Be the first to join!</p>
            )}
          </div>

          <Separator />

          {/* Action Buttons */}
          <div className="flex space-x-2">
            {user && !isOrganizer && (
              <>
                <Button 
                  onClick={handleJoinLeave}
                  disabled={actionLoading}
                  variant={isParticipating ? "outline" : "default"}
                  className="flex-1"
                >
                  {actionLoading ? 'Processing...' : isParticipating ? 'Leave Event' : 'Join Event'}
                </Button>
                
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setShowMessageModal(true)}
                >
                  <MessageSquare className="h-4 w-4 mr-2" />
                  Message Organizer
                </Button>
              </>
            )}
            
            {user && isOrganizer && (
              <Button 
                onClick={handleJoinLeave}
                disabled={actionLoading}
                variant={isParticipating ? "outline" : "default"}
                className="flex-1"
              >
                {actionLoading ? 'Processing...' : isParticipating ? 'Leave Event' : 'Join Event'}
              </Button>
            )}
          </div>

          {/* Quick Stats */}
          <div className="bg-muted p-4 rounded-lg">
            <h4 className="font-semibold mb-2">Quick Stats</h4>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-muted-foreground">Sport:</span>
                <p className="font-medium">{event.sport}</p>
              </div>
              <div>
                <span className="text-muted-foreground">Participants:</span>
                <p className="font-medium">{participants.length}</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Message Organizer Modal */}
      <Dialog open={showMessageModal} onOpenChange={setShowMessageModal}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Message Event Organizer</DialogTitle>
          </DialogHeader>
          <DirectMessageForm preSelectedRecipientId={event.organizer_id} />
        </DialogContent>
      </Dialog>
    </>
  );
};
