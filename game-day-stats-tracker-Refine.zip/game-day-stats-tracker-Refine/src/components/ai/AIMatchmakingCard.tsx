
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useAIMatchmaking } from '@/hooks/useAIMatchmaking';
import { Brain, Users, Zap, MessageCircle } from 'lucide-react';

export const AIMatchmakingCard: React.FC = () => {
  const { matches, loading, findMatches } = useAIMatchmaking();
  const [showMatches, setShowMatches] = useState(false);

  const handleFindMatches = async () => {
    await findMatches();
    setShowMatches(true);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Brain className="mr-2 h-5 w-5" />
          AI Matchmaking
        </CardTitle>
        <CardDescription>
          Find compatible players using AI-powered matching
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between p-4 bg-gradient-to-r from-primary/10 to-secondary/10 rounded-lg">
          <div className="flex items-center space-x-3">
            <Zap className="h-8 w-8 text-primary" />
            <div>
              <p className="font-medium">Smart Matching</p>
              <p className="text-sm text-muted-foreground">
                AI-powered player compatibility
              </p>
            </div>
          </div>
        </div>

        <Button 
          onClick={handleFindMatches}
          disabled={loading}
          className="w-full"
        >
          <Users className="mr-2 h-4 w-4" />
          {loading ? 'Finding Matches...' : 'Find Compatible Players'}
        </Button>

        {showMatches && matches.length > 0 && (
          <div className="space-y-3">
            <div className="text-sm font-medium">Your Top Matches:</div>
            {matches.slice(0, 3).map((match) => (
              <div key={match.id} className="border rounded-lg p-3 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="font-medium">{match.full_name}</div>
                  <Badge variant="secondary">
                    {match.compatibility_score}% Match
                  </Badge>
                </div>
                <div className="text-sm text-muted-foreground">
                  {match.location}
                  {match.distance_km && ` • ${match.distance_km}km away`}
                </div>
                <div className="flex flex-wrap gap-1">
                  {match.common_interests.map((interest, index) => (
                    <Badge key={index} variant="outline" className="text-xs">
                      {interest}
                    </Badge>
                  ))}
                </div>
                <Button size="sm" variant="outline" className="w-full">
                  <MessageCircle className="mr-2 h-3 w-3" />
                  Send Message
                </Button>
              </div>
            ))}
          </div>
        )}

        {showMatches && matches.length === 0 && (
          <div className="text-center py-4 text-muted-foreground">
            No compatible matches found. Try adjusting your preferences!
          </div>
        )}
      </CardContent>
    </Card>
  );
};
