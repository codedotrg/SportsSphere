
import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Shield, AlertTriangle, CheckCircle } from 'lucide-react';
import { isSessionValid } from '@/utils/securityEnhancements';
import { useAuth } from '@/contexts/AuthContext';

interface SecurityStatus {
  sessionValid: boolean;
  authStrength: 'weak' | 'medium' | 'strong';
  lastCheck: Date;
}

export const SecurityMonitor: React.FC = () => {
  const { session } = useAuth();
  const [securityStatus, setSecurityStatus] = useState<SecurityStatus>({
    sessionValid: false,
    authStrength: 'weak',
    lastCheck: new Date()
  });

  useEffect(() => {
    const checkSecurity = async () => {
      if (!session) return;

      const sessionValid = await isSessionValid();
      
      // Assess authentication strength based on session age
      let authStrength: 'weak' | 'medium' | 'strong' = 'weak';
      
      if (session && session.expires_at) {
        const now = Date.now() / 1000; // Convert to seconds
        const expiresAt = session.expires_at;
        const timeUntilExpiry = expiresAt - now;
        const oneHour = 60 * 60; // in seconds
        const oneDay = 24 * oneHour;
        
        if (timeUntilExpiry > oneDay) {
          authStrength = 'strong';
        } else if (timeUntilExpiry > oneHour) {
          authStrength = 'medium';
        }
      }

      setSecurityStatus({
        sessionValid,
        authStrength,
        lastCheck: new Date()
      });
    };

    checkSecurity();
    
    // Check security status every 5 minutes
    const interval = setInterval(checkSecurity, 5 * 60 * 1000);
    
    return () => clearInterval(interval);
  }, [session]);

  if (!session) return null;

  const getSecurityIcon = () => {
    if (!securityStatus.sessionValid) {
      return <AlertTriangle className="h-4 w-4 text-destructive" />;
    }
    
    switch (securityStatus.authStrength) {
      case 'strong':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'medium':
        return <Shield className="h-4 w-4 text-yellow-500" />;
      default:
        return <AlertTriangle className="h-4 w-4 text-orange-500" />;
    }
  };

  const getSecurityBadge = () => {
    if (!securityStatus.sessionValid) {
      return <Badge variant="destructive">Session Invalid</Badge>;
    }
    
    switch (securityStatus.authStrength) {
      case 'strong':
        return <Badge className="bg-green-500">Strong</Badge>;
      case 'medium':
        return <Badge className="bg-yellow-500">Medium</Badge>;
      default:
        return <Badge variant="secondary">Weak</Badge>;
    }
  };

  return (
    <Card className="w-full">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center text-sm">
          {getSecurityIcon()}
          <span className="ml-2">Security Status</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <p className="text-sm text-muted-foreground">
              Session Status
            </p>
            {getSecurityBadge()}
          </div>
          <div className="text-right">
            <p className="text-xs text-muted-foreground">
              Last checked: {securityStatus.lastCheck.toLocaleTimeString()}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
