
import React, { useState, useEffect } from 'react';

const motivationalQuotes = [
  "Champions are made when nobody's watching. Keep pushing!",
  "Every champion was once a contender that refused to give up.",
  "The difference between ordinary and extraordinary is that little extra.",
  "Success is where preparation and opportunity meet.",
  "Your only limit is your mind. Push beyond it!",
  "Hard work beats talent when talent doesn't work hard.",
  "The body achieves what the mind believes.",
  "Champions keep playing until they get it right.",
  "Excellence is not a skill, it's an attitude.",
  "Play like you're in first, train like you're in second.",
  "Winners never quit and quitters never win.",
  "The harder you work, the luckier you get.",
  "Sports do not build character, they reveal it.",
  "If you believe it, the mind can achieve it.",
  "Dream big, work hard, stay focused, and surround yourself with good people."
];

export const MotivationalFooter: React.FC = () => {
  const [currentQuote, setCurrentQuote] = useState('');

  useEffect(() => {
    const randomQuote = motivationalQuotes[Math.floor(Math.random() * motivationalQuotes.length)];
    setCurrentQuote(randomQuote);
  }, []);

  return (
    <footer className="bg-gradient-to-r from-primary to-primary/80 text-white py-6 mt-8">
      <div className="container mx-auto px-4 text-center">
        <div className="mb-4">
          <p className="text-lg font-semibold italic">
            "{currentQuote}"
          </p>
        </div>
        <div className="border-t border-white/20 pt-4">
          <p className="text-sm opacity-80">
            Stay active, stay motivated, stay connected with SportSphere
          </p>
        </div>
      </div>
    </footer>
  );
};
