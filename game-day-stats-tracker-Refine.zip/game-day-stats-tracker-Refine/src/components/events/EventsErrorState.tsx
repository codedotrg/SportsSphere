
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { AlertCircle, RefreshCw } from 'lucide-react';

interface EventsErrorStateProps {
  error: string;
  onRetry: () => void;
}

export const EventsErrorState: React.FC<EventsErrorStateProps> = ({ error, onRetry }) => {
  return (
    <Card>
      <CardContent className="text-center py-8">
        <AlertCircle className="mx-auto h-12 w-12 text-destructive mb-4" />
        <h3 className="text-lg font-semibold mb-2 text-destructive">Connection Error</h3>
        <p className="text-muted-foreground mb-4">{error}</p>
        <Button onClick={onRetry}>
          <RefreshCw className="mr-2 h-4 w-4" />
          Try Again
        </Button>
      </CardContent>
    </Card>
  );
};
