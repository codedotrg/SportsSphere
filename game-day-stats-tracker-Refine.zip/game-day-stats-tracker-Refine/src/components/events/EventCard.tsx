
import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Calendar, MapPin, Users } from 'lucide-react';
import { useEventParticipants } from '@/hooks/useEventParticipants';

interface Event {
  id: string;
  title: string;
  description: string;
  sport: string;
  location: string;
  event_date: string;
  organizer_id: string;
  created_at: string;
}

interface EventCardProps {
  event: Event;
  onViewDetails: (event: Event) => void;
  currentUserId: string;
}

export const EventCard: React.FC<EventCardProps> = ({ event, onViewDetails, currentUserId }) => {
  const { participants, isParticipating, joinEvent, leaveEvent } = useEventParticipants(event.id);
  const [actionLoading, setActionLoading] = useState(false);

  const formatDate = (dateString: string) => {
    try {
      return new Date(dateString).toLocaleDateString('en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch {
      return 'Invalid Date';
    }
  };

  const handleJoinLeave = async (e: React.MouseEvent) => {
    e.stopPropagation();
    setActionLoading(true);
    try {
      if (isParticipating) {
        await leaveEvent();
      } else {
        await joinEvent();
      }
    } catch (error) {
      console.error('Error in join/leave action:', error);
    } finally {
      setActionLoading(false);
    }
  };

  const isOrganizer = currentUserId === event.organizer_id;

  return (
    <Card className="hover:shadow-lg transition-shadow cursor-pointer">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          {event.title}
          <span className="text-sm font-normal bg-primary/10 text-primary px-2 py-1 rounded">
            {event.sport}
          </span>
        </CardTitle>
        <CardDescription>{event.description}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex items-center text-sm text-muted-foreground">
          <Calendar className="mr-2 h-4 w-4" />
          {formatDate(event.event_date)}
        </div>
        {event.location && (
          <div className="flex items-center text-sm text-muted-foreground">
            <MapPin className="mr-2 h-4 w-4" />
            {event.location}
          </div>
        )}
        <div className="flex items-center text-sm text-muted-foreground">
          <Users className="mr-2 h-4 w-4" />
          {participants.length} participants
        </div>
        <div className="flex space-x-2 mt-4">
          <Button 
            className="flex-1" 
            variant="outline"
            onClick={() => onViewDetails(event)}
          >
            View Details
          </Button>
          {!isOrganizer && (
            <Button 
              className="flex-1"
              onClick={handleJoinLeave}
              disabled={actionLoading}
              variant={isParticipating ? "outline" : "default"}
            >
              {actionLoading ? 'Loading...' : isParticipating ? 'Leave' : 'Join'}
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
};
