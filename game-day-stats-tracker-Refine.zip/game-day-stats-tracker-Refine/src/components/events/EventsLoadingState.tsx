
import React from 'react';
import { RefreshCw } from 'lucide-react';

interface EventsLoadingStateProps {
  message?: string;
}

export const EventsLoadingState: React.FC<EventsLoadingStateProps> = ({ 
  message = "Loading events..." 
}) => {
  return (
    <div className="text-center py-8">
      <div className="flex items-center justify-center space-x-2">
        <RefreshCw className="h-6 w-6 animate-spin" />
        <span>{message}</span>
      </div>
    </div>
  );
};
