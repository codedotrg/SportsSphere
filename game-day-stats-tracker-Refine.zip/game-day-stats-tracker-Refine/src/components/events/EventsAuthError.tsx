
import React from 'react';
import { Button } from '@/components/ui/button';
import { AlertCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export const EventsAuthError: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="animate-fade-in-up">
      <div className="text-center py-8">
        <AlertCircle className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
        <h3 className="text-lg font-semibold mb-2">Authentication Required</h3>
        <p className="text-muted-foreground mb-4">Please log in to view events.</p>
        <Button onClick={() => navigate('/auth')}>
          Go to Login
        </Button>
      </div>
    </div>
  );
};
