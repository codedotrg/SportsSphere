
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Calendar, Plus } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export const EventsEmptyState: React.FC = () => {
  const navigate = useNavigate();

  return (
    <Card>
      <CardContent className="text-center py-8">
        <Calendar className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
        <h3 className="text-lg font-semibold mb-2">No events found</h3>
        <p className="text-muted-foreground mb-4">
          Be the first to create an event and get the community started!
        </p>
        <Button onClick={() => navigate('/create-event')}>
          <Plus className="mr-2 h-4 w-4" />
          Create Your First Event
        </Button>
      </CardContent>
    </Card>
  );
};
