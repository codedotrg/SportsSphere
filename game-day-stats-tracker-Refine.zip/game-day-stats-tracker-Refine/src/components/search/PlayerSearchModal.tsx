
import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Search, UserPlus } from 'lucide-react';
import { usePlayerSearch } from '@/hooks/usePlayerSearch';
import { UserProfileCard } from '@/components/user/UserProfileCard';

interface PlayerSearchModalProps {
  eventId: string;
  onAddPlayer: (playerId: string) => Promise<void>;
  disabled?: boolean;
}

export const PlayerSearchModal: React.FC<PlayerSearchModalProps> = ({
  eventId,
  onAddPlayer,
  disabled = false
}) => {
  const [open, setOpen] = useState(false);
  const { players, loading, searchTerm, setSearchTerm } = usePlayerSearch(eventId);

  const handleAddPlayer = async (playerId: string) => {
    await onAddPlayer(playerId);
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="sm" disabled={disabled}>
          <UserPlus className="mr-2 h-4 w-4" />
          Add Player
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Search and Add Players</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search for players by name or email..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          
          {loading && (
            <p className="text-center text-muted-foreground">Searching...</p>
          )}
          
          {!loading && searchTerm && players.length === 0 && (
            <p className="text-center text-muted-foreground">
              No available players found for "{searchTerm}"
            </p>
          )}
          
          <div className="space-y-2 max-h-96 overflow-y-auto">
            {players.map((player) => (
              <div key={player.id} className="flex items-center justify-between p-2 border rounded">
                <UserProfileCard
                  profile={player}
                  showFollowButton={false}
                  showLocation={true}
                />
                <Button
                  size="sm"
                  onClick={() => handleAddPlayer(player.id)}
                >
                  Add to Event
                </Button>
              </div>
            ))}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
