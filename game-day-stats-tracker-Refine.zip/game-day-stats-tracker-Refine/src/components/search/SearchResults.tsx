
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { 
  Calendar, 
  MapPin, 
  Users, 
  User, 
  Trophy,
  Clock,
  ExternalLink
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { UserProfileModal } from '@/components/user/UserProfileModal';
import { formatDistanceToNow } from 'date-fns';

interface SearchResultsProps {
  results: {
    events: any[];
    users: any[];
    teams: any[];
  };
  loading: boolean;
  query: string;
}

export const SearchResults: React.FC<SearchResultsProps> = ({
  results,
  loading,
  query
}) => {
  const navigate = useNavigate();
  const [showUserModal, setShowUserModal] = useState(false);
  const [selectedUserId, setSelectedUserId] = useState('');

  const handleEventClick = (eventId: string) => {
    console.log('Navigating to event:', eventId);
    navigate(`/events/${eventId}`);
  };

  const handleUserClick = (userId: string) => {
    setSelectedUserId(userId);
    setShowUserModal(true);
  };

  const handleTeamClick = (teamId: string) => {
    // Navigate to team details if we have a team page
    console.log('Team clicked:', teamId);
  };

  if (loading) {
    return (
      <div className="space-y-4">
        <div className="animate-pulse">
          <div className="h-4 bg-muted rounded w-1/4 mb-4"></div>
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-20 bg-muted rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!query) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        Start typing to search for events, users, and teams
      </div>
    );
  }

  const totalResults = results.events.length + results.users.length + results.teams.length;

  if (totalResults === 0) {
    return (
      <div className="text-center py-8">
        <div className="text-muted-foreground mb-2">
          No results found for "{query}"
        </div>
        <p className="text-sm text-muted-foreground">
          Try different keywords or check your spelling
        </p>
      </div>
    );
  }

  return (
    <>
      <div className="space-y-6">
        <div className="text-sm text-muted-foreground">
          Found {totalResults} result{totalResults !== 1 ? 's' : ''} for "{query}"
        </div>

        {/* Events Section */}
        {results.events.length > 0 && (
          <div className="space-y-3">
            <h3 className="font-semibold text-lg flex items-center">
              <Calendar className="mr-2 h-5 w-5" />
              Events ({results.events.length})
            </h3>
            <div className="space-y-3">
              {results.events.map((event) => (
                <Card 
                  key={event.id} 
                  className="hover:shadow-md transition-shadow cursor-pointer"
                  onClick={() => handleEventClick(event.id)}
                >
                  <CardContent className="pt-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <h4 className="font-medium">{event.title}</h4>
                          <Badge variant="outline">{event.sport}</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mb-2 line-clamp-2">
                          {event.description}
                        </p>
                        <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                          <div className="flex items-center">
                            <Clock className="mr-1 h-3 w-3" />
                            {new Date(event.event_date).toLocaleDateString()}
                          </div>
                          {event.location && (
                            <div className="flex items-center">
                              <MapPin className="mr-1 h-3 w-3" />
                              {event.location}
                            </div>
                          )}
                        </div>
                      </div>
                      <Button variant="ghost" size="sm">
                        <ExternalLink className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Users Section */}
        {results.users.length > 0 && (
          <div className="space-y-3">
            <h3 className="font-semibold text-lg flex items-center">
              <User className="mr-2 h-5 w-5" />
              Players ({results.users.length})
            </h3>
            <div className="space-y-3">
              {results.users.map((user) => (
                <Card 
                  key={user.id} 
                  className="hover:shadow-md transition-shadow cursor-pointer"
                  onClick={() => handleUserClick(user.id)}
                >
                  <CardContent className="pt-4">
                    <div className="flex items-center space-x-3">
                      <Avatar>
                        <AvatarFallback>
                          {user.full_name?.charAt(0) || user.email.charAt(0).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <h4 className="font-medium">
                          {user.full_name || 'Unknown User'}
                        </h4>
                        <p className="text-sm text-muted-foreground">{user.email}</p>
                        {user.location && (
                          <div className="flex items-center text-xs text-muted-foreground mt-1">
                            <MapPin className="mr-1 h-3 w-3" />
                            {user.location}
                          </div>
                        )}
                      </div>
                      <Button variant="ghost" size="sm">
                        <ExternalLink className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Teams Section */}
        {results.teams.length > 0 && (
          <div className="space-y-3">
            <h3 className="font-semibold text-lg flex items-center">
              <Users className="mr-2 h-5 w-5" />
              Teams ({results.teams.length})
            </h3>
            <div className="space-y-3">
              {results.teams.map((team) => (
                <Card 
                  key={team.id} 
                  className="hover:shadow-md transition-shadow cursor-pointer"
                  onClick={() => handleTeamClick(team.id)}
                >
                  <CardContent className="pt-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <h4 className="font-medium">{team.team_name}</h4>
                          <Badge variant="secondary">
                            <Trophy className="mr-1 h-3 w-3" />
                            Team
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mb-2 line-clamp-2">
                          {team.description}
                        </p>
                        <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                          <div className="flex items-center">
                            <Users className="mr-1 h-3 w-3" />
                            Max {team.max_members} members
                          </div>
                          <div className="flex items-center">
                            <Clock className="mr-1 h-3 w-3" />
                            {formatDistanceToNow(new Date(team.created_at), { addSuffix: true })}
                          </div>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm">
                        <ExternalLink className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>

      <UserProfileModal
        userId={selectedUserId}
        isOpen={showUserModal}
        onClose={() => setShowUserModal(false)}
      />
    </>
  );
};
