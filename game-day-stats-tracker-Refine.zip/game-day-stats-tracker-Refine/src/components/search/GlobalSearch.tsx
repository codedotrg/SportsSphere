
import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Search, Calendar, Users } from 'lucide-react';
import { useUserSearch } from '@/hooks/useUserSearch';
import { useEvents } from '@/hooks/useEvents';
import { UserProfileCard } from '@/components/user/UserProfileCard';
import { EventCard } from '@/components/events/EventCard';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useAuth } from '@/contexts/AuthContext';

export const GlobalSearch: React.FC = () => {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const { users, setSearchTerm: setUserSearchTerm } = useUserSearch();
  const { events, loading: eventsLoading } = useEvents();

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    setUserSearchTerm(query);
    if (query.length > 0) {
      setIsOpen(true);
    }
  };

  const filteredEvents = events.filter(event =>
    event.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    event.description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    event.location?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    event.sport?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <>
      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search events, players, locations..."
          value={searchQuery}
          onChange={(e) => handleSearch(e.target.value)}
          className="pl-10 pr-4"
          onFocus={() => searchQuery && setIsOpen(true)}
        />
      </div>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-hidden">
          <DialogHeader>
            <DialogTitle className="flex items-center">
              <Search className="mr-2 h-5 w-5" />
              Search Results for "{searchQuery}"
            </DialogTitle>
          </DialogHeader>
          
          {searchQuery && (
            <Tabs defaultValue="events" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="events" className="flex items-center">
                  <Calendar className="mr-2 h-4 w-4" />
                  Events ({filteredEvents.length})
                </TabsTrigger>
                <TabsTrigger value="players" className="flex items-center">
                  <Users className="mr-2 h-4 w-4" />
                  Players ({users.length})
                </TabsTrigger>
              </TabsList>

              <TabsContent value="events" className="mt-4">
                <div className="max-h-96 overflow-y-auto space-y-4">
                  {filteredEvents.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      <Calendar className="mx-auto h-12 w-12 mb-4 opacity-50" />
                      <p>No events found for "{searchQuery}"</p>
                    </div>
                  ) : (
                    <div className="grid gap-4">
                      {filteredEvents.slice(0, 10).map((event) => (
                        <EventCard 
                          key={event.id} 
                          event={event} 
                          onViewDetails={() => {}}
                          currentUserId={user?.id || ''}
                        />
                      ))}
                    </div>
                  )}
                </div>
              </TabsContent>

              <TabsContent value="players" className="mt-4">
                <div className="max-h-96 overflow-y-auto space-y-4">
                  {users.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      <Users className="mx-auto h-12 w-12 mb-4 opacity-50" />
                      <p>No players found for "{searchQuery}"</p>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {users.slice(0, 10).map((user) => (
                        <UserProfileCard
                          key={user.id}
                          profile={user}
                          showFollowButton={true}
                          showLocation={true}
                        />
                      ))}
                    </div>
                  )}
                </div>
              </TabsContent>
            </Tabs>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
};
