
import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Search } from 'lucide-react';
import { useUserSearch } from '@/hooks/useUserSearch';
import { UserProfileCard } from '@/components/user/UserProfileCard';

interface UserSearchModalProps {
  trigger?: React.ReactNode;
}

export const UserSearchModal: React.FC<UserSearchModalProps> = ({
  trigger
}) => {
  const [open, setOpen] = useState(false);
  const { users, loading, searchTerm, setSearchTerm } = useUserSearch();

  const defaultTrigger = (
    <Button variant="outline" size="sm">
      <Search className="mr-2 h-4 w-4" />
      Search Users
    </Button>
  );

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || defaultTrigger}
      </DialogTrigger>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Search Users</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search for users by name or email..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          
          {loading && (
            <p className="text-center text-muted-foreground">Searching...</p>
          )}
          
          {!loading && searchTerm && users.length === 0 && (
            <p className="text-center text-muted-foreground">
              No users found for "{searchTerm}"
            </p>
          )}
          
          <div className="space-y-2 max-h-96 overflow-y-auto">
            {users.map((user) => (
              <UserProfileCard
                key={user.id}
                profile={user}
                showFollowButton={true}
                showLocation={true}
              />
            ))}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
