
import React, { useState, useRef, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Search, X, Calendar, Users, Trophy, AlertCircle } from 'lucide-react';
import { useGlobalSearch } from '@/hooks/useGlobalSearch';
import { useNavigate } from 'react-router-dom';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { AnimatedPlaceholder } from './AnimatedPlaceholder';
import { UserProfileModal } from '@/components/user/UserProfileModal';

interface AdvancedSearchBarProps {
  placeholder?: string;
}

const searchPlaceholders = [
  "Search for basketball events...",
  "Find tennis training camps...",
  "Look for football matches...",
  "Discover swimming events...",
  "Join running groups...",
  "Find volleyball teams...",
  "Search cricket matches...",
  "Explore outdoor activities..."
];

export const AdvancedSearchBar: React.FC<AdvancedSearchBarProps> = ({
  placeholder
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [showDropdown, setShowDropdown] = useState(false);
  const [isFocused, setIsFocused] = useState(false);
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [showUserProfile, setShowUserProfile] = useState(false);
  const { results, loading, error, searchAll, clearSearch } = useGlobalSearch();
  const navigate = useNavigate();
  const searchRef = useRef<HTMLDivElement>(null);
  const timeoutRef = useRef<NodeJS.Timeout>();

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setShowDropdown(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }

    if (searchQuery.length >= 2) {
      timeoutRef.current = setTimeout(() => {
        searchAll(searchQuery);
        setShowDropdown(true);
      }, 300);
    } else {
      clearSearch();
      setShowDropdown(false);
    }

    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, [searchQuery, searchAll, clearSearch]);

  const handleEventClick = (eventId: string) => {
    navigate(`/event/${eventId}`);
    handleClearSearch();
  };

  const handleUserClick = (userId: string) => {
    console.log('Opening profile for user:', userId);
    setSelectedUserId(userId);
    setShowUserProfile(true);
    handleClearSearch();
  };

  const handleClearSearch = () => {
    setSearchQuery('');
    setShowDropdown(false);
    clearSearch();
  };

  const handleCloseUserProfile = () => {
    setShowUserProfile(false);
    setSelectedUserId(null);
  };

  const totalResults = results.events.length + results.users.length + results.teams.length;

  const renderLoadingState = () => (
    <div className="p-4 space-y-3">
      <div className="flex items-center space-x-2">
        <Skeleton className="h-4 w-4 rounded-full" />
        <Skeleton className="h-4 w-24" />
      </div>
      {[1, 2, 3].map((i) => (
        <div key={i} className="flex items-center space-x-3">
          <Skeleton className="h-8 w-8 rounded-full" />
          <div className="space-y-1 flex-1">
            <Skeleton className="h-4 w-3/4" />
            <Skeleton className="h-3 w-1/2" />
          </div>
        </div>
      ))}
    </div>
  );

  const renderErrorState = () => (
    <div className="p-4 text-center">
      <AlertCircle className="mx-auto h-8 w-8 text-destructive mb-2" />
      <p className="text-sm text-destructive font-medium">Search Error</p>
      <p className="text-xs text-muted-foreground mt-1">{error}</p>
      <Button
        variant="outline"
        size="sm"
        className="mt-2"
        onClick={() => searchAll(searchQuery)}
      >
        Try Again
      </Button>
    </div>
  );

  return (
    <>
      <div className="relative max-w-md" ref={searchRef}>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder=""
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 pr-10"
            onFocus={() => {
              setIsFocused(true);
              if (searchQuery.length >= 2) setShowDropdown(true);
            }}
            onBlur={() => setIsFocused(false)}
          />
          {!isFocused && !searchQuery && (
            <div className="absolute left-10 top-1/2 transform -translate-y-1/2 pointer-events-none text-muted-foreground">
              <AnimatedPlaceholder 
                placeholders={searchPlaceholders}
                speed={2500}
              />
            </div>
          )}
          {searchQuery && (
            <Button
              variant="ghost"
              size="sm"
              className="absolute right-1 top-1/2 transform -translate-y-1/2 h-8 w-8 p-0"
              onClick={handleClearSearch}
            >
              <X className="h-4 w-4" />
            </Button>
          )}
        </div>

        {showDropdown && (
          <Card className="absolute top-full left-0 right-0 mt-2 z-50 max-h-96 overflow-hidden">
            <CardContent className="p-0">
              {loading ? (
                renderLoadingState()
              ) : error ? (
                renderErrorState()
              ) : totalResults === 0 ? (
                <div className="p-4 text-center text-sm text-muted-foreground">
                  No results found for "{searchQuery}"
                </div>
              ) : (
                <div className="max-h-80 overflow-y-auto">
                  {/* Events Section */}
                  {results.events.length > 0 && (
                    <div className="border-b">
                      <div className="px-3 py-2 text-xs font-medium text-muted-foreground bg-muted/50 flex items-center">
                        <Calendar className="mr-2 h-3 w-3" />
                        Events ({results.events.length})
                      </div>
                      {results.events.slice(0, 3).map((event) => (
                        <div
                          key={event.id}
                          className="px-3 py-2 hover:bg-muted cursor-pointer border-b border-border/50 last:border-b-0 transition-colors"
                          onClick={() => handleEventClick(event.id)}
                        >
                          <div className="font-medium text-sm">{event.title}</div>
                          <div className="text-xs text-muted-foreground">
                            {event.sport} • {event.location}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Users Section */}
                  {results.users.length > 0 && (
                    <div className="border-b">
                      <div className="px-3 py-2 text-xs font-medium text-muted-foreground bg-muted/50 flex items-center">
                        <Users className="mr-2 h-3 w-3" />
                        Players ({results.users.length})
                      </div>
                      {results.users.slice(0, 3).map((user) => (
                        <div
                          key={user.id}
                          className="px-3 py-2 hover:bg-muted cursor-pointer border-b border-border/50 last:border-b-0 flex items-center space-x-3 transition-colors"
                          onClick={() => handleUserClick(user.id)}
                        >
                          <Avatar className="h-8 w-8">
                            <AvatarImage src={user.profile_picture || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.email}`} />
                            <AvatarFallback className="text-xs">
                              {user.full_name?.charAt(0) || user.email.charAt(0).toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <div className="font-medium text-sm">{user.full_name || 'Unknown User'}</div>
                            <div className="text-xs text-muted-foreground">{user.location || 'No location'}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Teams Section */}
                  {results.teams.length > 0 && (
                    <div>
                      <div className="px-3 py-2 text-xs font-medium text-muted-foreground bg-muted/50 flex items-center">
                        <Trophy className="mr-2 h-3 w-3" />
                        Teams ({results.teams.length})
                      </div>
                      {results.teams.slice(0, 3).map((team) => (
                        <div
                          key={team.id}
                          className="px-3 py-2 hover:bg-muted cursor-pointer border-b border-border/50 last:border-b-0 transition-colors"
                        >
                          <div className="font-medium text-sm">{team.team_name}</div>
                          <div className="text-xs text-muted-foreground">
                            Max {team.max_members || 5} members
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>

      {/* User Profile Modal */}
      {selectedUserId && (
        <UserProfileModal
          userId={selectedUserId}
          isOpen={showUserProfile}
          onClose={handleCloseUserProfile}
        />
      )}
    </>
  );
};
