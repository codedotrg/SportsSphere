
import React, { useState, useEffect } from 'react';

interface AnimatedPlaceholderProps {
  placeholders: string[];
  speed?: number;
  className?: string;
}

export const AnimatedPlaceholder: React.FC<AnimatedPlaceholderProps> = ({
  placeholders,
  speed = 3000,
  className = ""
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    const interval = setInterval(() => {
      setIsVisible(false);
      
      setTimeout(() => {
        setCurrentIndex((prev) => (prev + 1) % placeholders.length);
        setIsVisible(true);
      }, 200);
    }, speed);

    return () => clearInterval(interval);
  }, [placeholders.length, speed]);

  return (
    <span 
      className={`transition-opacity duration-200 ${isVisible ? 'opacity-100' : 'opacity-0'} ${className}`}
    >
      {placeholders[currentIndex]}
    </span>
  );
};
