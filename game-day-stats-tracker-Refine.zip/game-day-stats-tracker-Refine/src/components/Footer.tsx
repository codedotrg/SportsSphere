
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

const motivationalQuotes = [
  "Champions are made when nobody's watching. Keep pushing!",
  "Every champion was once a contender that refused to give up.",
  "The difference between ordinary and extraordinary is that little extra.",
  "Success is where preparation and opportunity meet.",
  "Your only limit is your mind. Push beyond it!",
  "Hard work beats talent when talent doesn't work hard.",
  "The body achieves what the mind believes.",
  "Champions keep playing until they get it right.",
  "Excellence is not a skill, it's an attitude.",
  "Play like you're in first, train like you're in second.",
  "Winners never quit and quitters never win.",
  "The harder you work, the luckier you get.",
  "Sports do not build character, they reveal it.",
  "If you believe it, the mind can achieve it.",
  "Dream big, work hard, stay focused, and surround yourself with good people."
];

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();
  const [currentQuote, setCurrentQuote] = useState('');

  useEffect(() => {
    const randomQuote = motivationalQuotes[Math.floor(Math.random() * motivationalQuotes.length)];
    setCurrentQuote(randomQuote);
  }, []);

  return (
    <footer className="bg-card border-t border-border">
      {/* Motivational Quote Section */}
      <div className="bg-gradient-to-r from-primary to-primary/80 text-white py-6">
        <div className="container mx-auto px-4 text-center">
          <p className="text-lg font-semibold italic">
            "{currentQuote}"
          </p>
          <p className="text-sm opacity-80 mt-2">
            Stay active, stay motivated, stay connected with SportSphere
          </p>
        </div>
      </div>

      {/* Main Footer Content */}
      <div className="py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            {/* Left side - Copyright */}
            <div>
              <p className="text-sm text-muted-foreground">
                &copy; {currentYear} SportSphere. All rights reserved.
              </p>
              <p className="text-xs text-muted-foreground/70 mt-1">
                Built with <a href="https://lovable.dev" target="_blank" rel="noopener noreferrer" className="hover:text-primary transition-colors">Lovable</a> &hearts;
              </p>
            </div>

            {/* Right side - Links */}
            <div className="flex flex-wrap justify-center gap-6 text-sm">
              <Link to="/contact" className="text-muted-foreground hover:text-primary transition-colors">
                Contact Us
              </Link>
              <Link to="/privacy" className="text-muted-foreground hover:text-primary transition-colors">
                Privacy Policy
              </Link>
              <Link to="/terms" className="text-muted-foreground hover:text-primary transition-colors">
                Terms & Conditions
              </Link>
              <Link to="/about" className="text-muted-foreground hover:text-primary transition-colors">
                About Us
              </Link>
              <Link to="/help" className="text-muted-foreground hover:text-primary transition-colors">
                Help & Support
              </Link>
            </div>
          </div>

          {/* Optional - Social links or additional info */}
          <div className="mt-6 pt-6 border-t border-border/50">
            <p className="text-xs text-muted-foreground text-center">
              Connect, Compete, Conquer - Your ultimate sports community platform
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
