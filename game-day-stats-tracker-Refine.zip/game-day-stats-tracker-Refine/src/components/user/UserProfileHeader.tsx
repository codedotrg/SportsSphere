
import React from 'react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { MessageCircle } from 'lucide-react';
import { FollowButton } from '@/components/follow/FollowButton';
import { useIsMobile } from '@/hooks/use-mobile';

interface UserProfile {
  id: string;
  full_name: string;
  email: string;
}

interface UserProfileHeaderProps {
  profile: UserProfile;
  isCurrentUser: boolean;
  onMessageClick: () => void;
}

export const UserProfileHeader: React.FC<UserProfileHeaderProps> = ({
  profile,
  isCurrentUser,
  onMessageClick
}) => {
  const isMobile = useIsMobile();
  
  return (
    <div className="flex flex-col sm:flex-row sm:items-center space-y-4 sm:space-y-0 sm:space-x-4">
      <Avatar className={`${isMobile ? 'h-20 w-20 mx-auto' : 'h-16 w-16'}`}>
        <AvatarImage src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${profile.email}`} />
        <AvatarFallback>
          {profile.full_name?.charAt(0) || profile.email.charAt(0).toUpperCase()}
        </AvatarFallback>
      </Avatar>
      <div className={`flex-1 ${isMobile ? 'text-center' : ''}`}>
        <h2 className={`${isMobile ? 'text-xl' : 'text-2xl'} font-bold`}>
          {profile.full_name || 'Unknown User'}
        </h2>
        <p className="text-muted-foreground text-sm sm:text-base">{profile.email}</p>
        {!isCurrentUser && (
          <div className={`flex ${isMobile ? 'flex-col' : 'flex-row'} ${isMobile ? 'items-center space-y-2' : 'space-x-2'} mt-3`}>
            <FollowButton userId={profile.id} />
            <Button onClick={onMessageClick} size="sm" className={isMobile ? 'w-full' : ''}>
              <MessageCircle className="mr-2 h-4 w-4" />
              Message
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};
