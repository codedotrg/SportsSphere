
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Send } from 'lucide-react';

interface UserMessageFormProps {
  recipientName: string;
  onSendMessage: (content: string) => Promise<boolean>;
  onCancel: () => void;
}

export const UserMessageForm: React.FC<UserMessageFormProps> = ({
  recipientName,
  onSendMessage,
  onCancel
}) => {
  const [messageContent, setMessageContent] = useState('');
  const [sending, setSending] = useState(false);

  const handleSendMessage = async () => {
    if (!messageContent.trim()) return;

    setSending(true);
    const success = await onSendMessage(messageContent);
    if (success) {
      setMessageContent('');
      onCancel();
    }
    setSending(false);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Send Message</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label htmlFor="message">Message</Label>
          <Textarea
            id="message"
            placeholder="Type your message..."
            value={messageContent}
            onChange={(e) => setMessageContent(e.target.value)}
            rows={4}
          />
        </div>
        <div className="flex space-x-2">
          <Button
            onClick={handleSendMessage}
            disabled={!messageContent.trim() || sending}
          >
            <Send className="mr-2 h-4 w-4" />
            {sending ? 'Sending...' : 'Send Message'}
          </Button>
          <Button variant="outline" onClick={onCancel}>
            Cancel
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};
