
import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { FollowButton } from '@/components/follow/FollowButton';
import { UserProfileModal } from '@/components/user/UserProfileModal';
import { useAuth } from '@/contexts/AuthContext';
import { useIsMobile } from '@/hooks/use-mobile';

interface UserProfile {
  id: string;
  full_name: string;
  email: string;
  location?: string;
}

interface UserProfileCardProps {
  profile: UserProfile;
  showFollowButton?: boolean;
  showLocation?: boolean;
}

export const UserProfileCard: React.FC<UserProfileCardProps> = ({
  profile,
  showFollowButton = true,
  showLocation = true
}) => {
  const { user } = useAuth();
  const isMobile = useIsMobile();
  const [showProfileModal, setShowProfileModal] = useState(false);
  const isCurrentUser = user?.id === profile.id;

  const handleCardClick = () => {
    setShowProfileModal(true);
  };

  return (
    <>
      <Card className="cursor-pointer hover:bg-muted/50 transition-colors" onClick={handleCardClick}>
        <CardContent className={`${isMobile ? 'pt-4' : 'pt-6'}`}>
          <div className={`flex ${isMobile ? 'flex-col items-center text-center space-y-3' : 'items-center space-x-4'}`}>
            <Avatar className={`${isMobile ? 'h-16 w-16' : 'h-12 w-12'}`}>
              <AvatarImage src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${profile.email}`} />
              <AvatarFallback>
                {profile.full_name?.charAt(0) || profile.email.charAt(0).toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <h3 className={`font-semibold ${isMobile ? 'text-base' : 'text-sm'}`}>
                {profile.full_name || 'Unknown User'}
              </h3>
              <p className={`text-muted-foreground ${isMobile ? 'text-sm' : 'text-xs'}`}>
                {profile.email}
              </p>
              {showLocation && profile.location && (
                <Badge variant="outline" className="mt-1 text-xs">
                  {profile.location}
                </Badge>
              )}
            </div>
            {showFollowButton && !isCurrentUser && (
              <div onClick={(e) => e.stopPropagation()} className={isMobile ? 'w-full' : ''}>
                <FollowButton userId={profile.id} />
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <UserProfileModal
        userId={profile.id}
        isOpen={showProfileModal}
        onClose={() => setShowProfileModal(false)}
      />
    </>
  );
};
