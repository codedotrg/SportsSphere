
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { MapPin, Calendar } from 'lucide-react';

interface UserProfile {
  id: string;
  full_name: string;
  email: string;
  location?: string;
  date_of_birth?: string;
  gender?: string;
  created_at?: string;
}

interface UserDetailsProps {
  profile: UserProfile;
}

export const UserDetails: React.FC<UserDetailsProps> = ({ profile }) => {
  const calculateAge = (dateOfBirth: string) => {
    if (!dateOfBirth) return null;
    const today = new Date();
    const birthDate = new Date(dateOfBirth);
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    
    return age;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Profile Information</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {profile.location && (
          <div className="flex items-center space-x-2">
            <MapPin className="h-4 w-4 text-muted-foreground" />
            <span>{profile.location}</span>
          </div>
        )}
        
        {profile.date_of_birth && (
          <div className="flex items-center space-x-2">
            <Calendar className="h-4 w-4 text-muted-foreground" />
            <span>Age: {calculateAge(profile.date_of_birth)} years old</span>
          </div>
        )}
        
        {profile.gender && (
          <div className="flex items-center space-x-2">
            <Badge variant="outline">{profile.gender}</Badge>
          </div>
        )}
        
        {profile.created_at && (
          <div className="flex items-center space-x-2">
            <span className="text-sm text-muted-foreground">
              Member since {new Date(profile.created_at).toLocaleDateString()}
            </span>
          </div>
        )}
      </CardContent>
    </Card>
  );
};
