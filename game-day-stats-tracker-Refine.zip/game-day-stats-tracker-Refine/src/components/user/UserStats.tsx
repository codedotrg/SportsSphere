
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Trophy, Target, Users } from 'lucide-react';

interface UserStatsProps {
  eventsCreated: number;
  eventsJoined: number;
  followersCount: number;
  followingCount: number;
}

export const UserStats: React.FC<UserStatsProps> = ({
  eventsCreated,
  eventsJoined,
  followersCount,
  followingCount
}) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Statistics</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center">
            <div className="flex items-center justify-center mb-2">
              <Trophy className="h-5 w-5 text-primary" />
            </div>
            <p className="text-2xl font-bold">{eventsCreated}</p>
            <p className="text-sm text-muted-foreground">Events Created</p>
          </div>
          <div className="text-center">
            <div className="flex items-center justify-center mb-2">
              <Target className="h-5 w-5 text-primary" />
            </div>
            <p className="text-2xl font-bold">{eventsJoined}</p>
            <p className="text-sm text-muted-foreground">Events Joined</p>
          </div>
          <div className="text-center">
            <div className="flex items-center justify-center mb-2">
              <Users className="h-5 w-5 text-primary" />
            </div>
            <p className="text-2xl font-bold">{followersCount}</p>
            <p className="text-sm text-muted-foreground">Followers</p>
          </div>
          <div className="text-center">
            <div className="flex items-center justify-center mb-2">
              <Users className="h-5 w-5 text-primary" />
            </div>
            <p className="text-2xl font-bold">{followingCount}</p>
            <p className="text-sm text-muted-foreground">Following</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
