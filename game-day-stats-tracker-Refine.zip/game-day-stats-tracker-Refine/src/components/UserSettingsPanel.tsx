
import React, { useState } from 'react';
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { useToast } from "@/hooks/use-toast";
import { 
  Settings, 
  User, 
  Bell, 
  Sun, 
  HelpCircle, 
  CreditCard,
  LogOut,
  ChevronDown,
  Eye,
  Shield,
  Palette,
  Globe
} from 'lucide-react';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';

export const UserSettingsPanel: React.FC = () => {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  // Settings state
  const [notifications, setNotifications] = useState(true);
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [darkMode, setDarkMode] = useState(true);
  const [publicProfile, setPublicProfile] = useState(false);
  const [dataSharing, setDataSharing] = useState(false);

  const handleLogout = async () => {
    try {
      await signOut();
      toast({ title: "Logged Out", description: "You have been successfully logged out." });
      navigate('/');
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "An unknown error occurred";
      toast({ title: "Logout Failed", description: errorMessage, variant: "destructive" });
    }
  };

  const getUserInitials = () => {
    if (user?.user_metadata?.full_name) {
      return user.user_metadata.full_name
        .split(' ')
        .map((name: string) => name[0])
        .join('')
        .toUpperCase()
        .slice(0, 2);
    }
    return user?.email?.charAt(0).toUpperCase() || 'U';
  };

  const handleHelpCenter = () => {
    toast({ title: "Help Center", description: "Coming soon!" });
  };

  const handleAccountSettings = () => {
    navigate('/profile');
  };

  return (
    <Sheet>
      <SheetTrigger asChild>
        <Button variant="ghost" className="relative h-10 w-auto px-2">
          <div className="flex items-center space-x-2">
            <Avatar className="h-8 w-8">
              <AvatarFallback className="text-sm">
                {getUserInitials()}
              </AvatarFallback>
            </Avatar>
            <ChevronDown className="h-4 w-4" />
          </div>
        </Button>
      </SheetTrigger>
      <SheetContent className="w-80 sm:w-96">
        <SheetHeader>
          <SheetTitle className="flex items-center">
            <Settings className="mr-2 h-5 w-5" />
            Settings
          </SheetTitle>
          <SheetDescription>
            Manage your account settings and preferences
          </SheetDescription>
        </SheetHeader>
        
        <div className="py-6 space-y-6">
          {/* User Profile Section */}
          <div className="space-y-3">
            <h3 className="text-sm font-medium">Account</h3>
            <div className="flex items-center space-x-3 p-3 rounded-lg border">
              <Avatar className="h-10 w-10">
                <AvatarFallback>{getUserInitials()}</AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">
                  {user?.user_metadata?.full_name || 'User'}
                </p>
                <p className="text-xs text-muted-foreground truncate">
                  {user?.email}
                </p>
              </div>
            </div>
            
            <div className="space-y-2">
              <Button 
                variant="outline" 
                className="w-full justify-start" 
                onClick={handleAccountSettings}
              >
                <User className="mr-2 h-4 w-4" />
                My Profile
              </Button>
              <Button 
                variant="outline" 
                className="w-full justify-start" 
                onClick={handleAccountSettings}
              >
                <CreditCard className="mr-2 h-4 w-4" />
                My Account
              </Button>
            </div>
          </div>

          <Separator />

          {/* Appearance Settings */}
          <div className="space-y-3">
            <h3 className="text-sm font-medium flex items-center">
              <Palette className="mr-2 h-4 w-4" />
              Appearance
            </h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-sm">Dark Mode</Label>
                  <p className="text-xs text-muted-foreground">
                    Toggle between light and dark themes
                  </p>
                </div>
                <Switch 
                  checked={darkMode} 
                  onCheckedChange={setDarkMode}
                />
              </div>
            </div>
          </div>

          <Separator />

          {/* Notification Settings */}
          <div className="space-y-3">
            <h3 className="text-sm font-medium flex items-center">
              <Bell className="mr-2 h-4 w-4" />
              Notifications
            </h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-sm">Push Notifications</Label>
                  <p className="text-xs text-muted-foreground">
                    Receive notifications about events and updates
                  </p>
                </div>
                <Switch 
                  checked={notifications} 
                  onCheckedChange={setNotifications}
                />
              </div>
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-sm">Email Notifications</Label>
                  <p className="text-xs text-muted-foreground">
                    Get updates via email
                  </p>
                </div>
                <Switch 
                  checked={emailNotifications} 
                  onCheckedChange={setEmailNotifications}
                />
              </div>
            </div>
          </div>

          <Separator />

          {/* Privacy Settings */}
          <div className="space-y-3">
            <h3 className="text-sm font-medium flex items-center">
              <Shield className="mr-2 h-4 w-4" />
              Privacy & Security
            </h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-sm">Public Profile</Label>
                  <p className="text-xs text-muted-foreground">
                    Make your profile visible to other users
                  </p>
                </div>
                <Switch 
                  checked={publicProfile} 
                  onCheckedChange={setPublicProfile}
                />
              </div>
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-sm">Data Sharing</Label>
                  <p className="text-xs text-muted-foreground">
                    Share anonymous usage data to improve the app
                  </p>
                </div>
                <Switch 
                  checked={dataSharing} 
                  onCheckedChange={setDataSharing}
                />
              </div>
            </div>
          </div>

          <Separator />

          {/* Accessibility Settings */}
          <div className="space-y-3">
            <h3 className="text-sm font-medium flex items-center">
              <Eye className="mr-2 h-4 w-4" />
              Accessibility
            </h3>
            <div className="space-y-2">
              <Button variant="outline" className="w-full justify-start">
                <Globe className="mr-2 h-4 w-4" />
                Language Settings
                <Badge variant="secondary" className="ml-auto">
                  English
                </Badge>
              </Button>
            </div>
          </div>

          <Separator />

          {/* Support & Help */}
          <div className="space-y-3">
            <h3 className="text-sm font-medium">Support</h3>
            <div className="space-y-2">
              <Button 
                variant="outline" 
                className="w-full justify-start" 
                onClick={handleHelpCenter}
              >
                <HelpCircle className="mr-2 h-4 w-4" />
                Help Center
              </Button>
            </div>
          </div>

          <Separator />

          {/* Logout */}
          <Button 
            variant="destructive" 
            className="w-full" 
            onClick={handleLogout}
          >
            <LogOut className="mr-2 h-4 w-4" />
            Logout
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  );
};
