
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { RecipientSelector } from './RecipientSelector';
import { MessageComposer } from './MessageComposer';
import { supabase } from '@/integrations/supabase/client';

interface User {
  id: string;
  full_name: string;
  email: string;
  location?: string;
}

interface DirectMessageFormProps {
  preSelectedRecipientId?: string;
  onMessageSent?: () => void;
}

export const DirectMessageForm: React.FC<DirectMessageFormProps> = ({ 
  preSelectedRecipientId, 
  onMessageSent 
}) => {
  const [selectedRecipient, setSelectedRecipient] = useState<User | null>(null);

  // Fetch pre-selected recipient details
  useEffect(() => {
    const fetchRecipient = async () => {
      if (preSelectedRecipientId) {
        try {
          const { data, error } = await supabase
            .from('profiles')
            .select('id, full_name, email, location')
            .eq('id', preSelectedRecipientId)
            .single();

          if (error) throw error;
          
          if (data) {
            setSelectedRecipient(data);
          }
        } catch (error) {
          console.error('Error fetching recipient:', error);
        }
      }
    };

    fetchRecipient();
  }, [preSelectedRecipientId]);

  const handleRecipientSelect = (user: User) => {
    setSelectedRecipient(user);
  };

  const handleRecipientClear = () => {
    setSelectedRecipient(null);
  };

  const handleMessageSent = () => {
    if (!preSelectedRecipientId) {
      setSelectedRecipient(null);
    }
    onMessageSent?.();
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Send Direct Message</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <RecipientSelector
          selectedRecipient={selectedRecipient}
          onRecipientSelect={handleRecipientSelect}
          onRecipientClear={handleRecipientClear}
          preSelectedRecipientId={preSelectedRecipientId}
        />

        {selectedRecipient && (
          <MessageComposer
            recipient={selectedRecipient}
            onMessageSent={handleMessageSent}
          />
        )}
      </CardContent>
    </Card>
  );
};
