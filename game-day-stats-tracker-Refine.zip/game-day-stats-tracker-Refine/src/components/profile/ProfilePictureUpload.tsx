
import React, { useState } from 'react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Camera } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/AuthContext';

interface ProfilePictureUploadProps {
  profilePicture?: string;
  userName: string;
  userEmail: string;
  onPictureUpdate: (url: string) => void;
}

export const ProfilePictureUpload: React.FC<ProfilePictureUploadProps> = ({
  profilePicture,
  userName,
  userEmail,
  onPictureUpdate
}) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [uploading, setUploading] = useState(false);

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    try {
      setUploading(true);
      
      if (!event.target.files || event.target.files.length === 0) {
        throw new Error('You must select an image to upload.');
      }

      if (!user?.id) {
        throw new Error('You must be logged in to upload a profile picture.');
      }

      const file = event.target.files[0];
      const fileExt = file.name.split('.').pop();
      const fileName = `${Math.random()}.${fileExt}`;
      // Create the correct folder structure: userId/filename
      const filePath = `${user.id}/${fileName}`;

      console.log('Uploading file to path:', filePath);

      const { error: uploadError } = await supabase.storage
        .from('avatars')
        .upload(filePath, file);

      if (uploadError) {
        console.error('Upload error:', uploadError);
        throw uploadError;
      }

      const { data } = supabase.storage
        .from('avatars')
        .getPublicUrl(filePath);

      console.log('File uploaded successfully, public URL:', data.publicUrl);

      // Update the profile picture in the database
      const { error: dbError } = await supabase
        .from('profiles')
        .update({ profile_picture: data.publicUrl })
        .eq('id', user.id);

      if (dbError) {
        console.error('Database update error:', dbError);
        throw dbError;
      }

      onPictureUpdate(data.publicUrl);

      toast({
        title: "Success",
        description: "Profile picture uploaded successfully"
      });
      
      // Clear the input so the same file can be uploaded again if needed
      event.target.value = '';
    } catch (error: any) {
      console.error('Profile picture upload error:', error);
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setUploading(false);
    }
  };

  const triggerFileInput = () => {
    document.getElementById('profile-picture-upload')?.click();
  };

  return (
    <div className="flex flex-col items-center space-y-4">
      <div className="relative">
        <Avatar className="h-24 w-24">
          <AvatarImage src={profilePicture} />
          <AvatarFallback className="text-lg">
            {userName?.charAt(0) || userEmail.charAt(0).toUpperCase()}
          </AvatarFallback>
        </Avatar>
        <Button
          size="sm"
          variant="outline"
          className="absolute -bottom-2 -right-2 rounded-full h-8 w-8 p-0"
          disabled={uploading}
          onClick={triggerFileInput}
        >
          <Camera className="h-4 w-4" />
        </Button>
      </div>
      
      <Input
        type="file"
        accept="image/*"
        onChange={handleFileUpload}
        disabled={uploading}
        className="hidden"
        id="profile-picture-upload"
      />
      
      {uploading && (
        <p className="text-sm text-muted-foreground">Uploading...</p>
      )}
    </div>
  );
};
