
import React from 'react';
import { Button } from '@/components/ui/button';
import { Edit, Save, X } from 'lucide-react';

interface ProfileActionsProps {
  isEditing: boolean;
  loading: boolean;
  onEdit: () => void;
  onSave: () => void;
  onCancel: () => void;
}

export const ProfileActions: React.FC<ProfileActionsProps> = ({
  isEditing,
  loading,
  onEdit,
  onSave,
  onCancel
}) => {
  if (!isEditing) {
    return (
      <Button variant="outline" size="sm" onClick={onEdit}>
        <Edit className="h-4 w-4" />
      </Button>
    );
  }

  return (
    <div className="space-x-2">
      <Button variant="outline" size="sm" onClick={onCancel}>
        <X className="h-4 w-4" />
      </Button>
      <Button size="sm" onClick={onSave} disabled={loading}>
        <Save className="h-4 w-4" />
      </Button>
    </div>
  );
};
