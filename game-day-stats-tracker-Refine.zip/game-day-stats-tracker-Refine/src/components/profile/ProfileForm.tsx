
import React from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface Profile {
  full_name: string;
  email: string;
  date_of_birth: string;
  location: string;
  zip_code: string;
  gender: string;
  profile_picture?: string;
}

interface ProfileFormProps {
  profile: Profile;
  isEditing: boolean;
  calculateAge: (dateOfBirth: string) => string;
  onProfileChange: (profile: Profile) => void;
  validationErrors?: Record<string, string>;
}

export const ProfileForm: React.FC<ProfileFormProps> = ({
  profile,
  isEditing,
  calculateAge,
  onProfileChange,
  validationErrors = {}
}) => {
  const handleInputChange = (field: keyof Profile, value: string) => {
    onProfileChange({ ...profile, [field]: value });
  };

  const formatDisplayDate = (dateString: string) => {
    if (!dateString) return 'Not provided';
    try {
      return new Date(dateString).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      });
    } catch {
      return 'Invalid date';
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div>
        <Label htmlFor="full_name">Full Name</Label>
        {isEditing ? (
          <div className="space-y-1">
            <Input
              id="full_name"
              value={profile.full_name}
              onChange={(e) => handleInputChange('full_name', e.target.value)}
              placeholder="Enter your full name"
              maxLength={100}
            />
            {validationErrors.full_name && (
              <p className="text-sm text-red-600">{validationErrors.full_name}</p>
            )}
          </div>
        ) : (
          <div className="p-2 border rounded-md bg-muted">
            {profile.full_name || 'Not provided'}
          </div>
        )}
      </div>

      <div>
        <Label htmlFor="email">Email</Label>
        {isEditing ? (
          <div className="space-y-1">
            <Input
              id="email"
              type="email"
              value={profile.email}
              onChange={(e) => handleInputChange('email', e.target.value)}
              placeholder="Enter your email"
              maxLength={100}
            />
            {validationErrors.email && (
              <p className="text-sm text-red-600">{validationErrors.email}</p>
            )}
          </div>
        ) : (
          <div className="p-2 border rounded-md bg-muted">
            {profile.email || 'Not provided'}
          </div>
        )}
      </div>

      <div>
        <Label htmlFor="gender">Gender</Label>
        {isEditing ? (
          <div className="space-y-1">
            <Select value={profile.gender} onValueChange={(value) => handleInputChange('gender', value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select gender" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="male">Male</SelectItem>
                <SelectItem value="female">Female</SelectItem>
                <SelectItem value="non-binary">Non-binary</SelectItem>
                <SelectItem value="other">Other</SelectItem>
                <SelectItem value="prefer-not-to-say">Prefer not to say</SelectItem>
              </SelectContent>
            </Select>
            {validationErrors.gender && (
              <p className="text-sm text-red-600">{validationErrors.gender}</p>
            )}
          </div>
        ) : (
          <div className="p-2 border rounded-md bg-muted">
            {profile.gender ? profile.gender.charAt(0).toUpperCase() + profile.gender.slice(1).replace('-', ' ') : 'Not provided'}
          </div>
        )}
      </div>

      <div>
        <Label htmlFor="date_of_birth">Date of Birth</Label>
        {isEditing ? (
          <div className="space-y-1">
            <Input
              id="date_of_birth"
              type="date"
              value={profile.date_of_birth}
              onChange={(e) => handleInputChange('date_of_birth', e.target.value)}
              max={new Date().toISOString().split('T')[0]}
              className="w-full"
            />
            {validationErrors.date_of_birth && (
              <p className="text-sm text-red-600">{validationErrors.date_of_birth}</p>
            )}
          </div>
        ) : (
          <div className="p-2 border rounded-md bg-muted">
            {formatDisplayDate(profile.date_of_birth)}
          </div>
        )}
      </div>

      <div>
        <Label htmlFor="age">Age</Label>
        <div className="p-2 border rounded-md bg-muted">
          {profile.date_of_birth ? `${calculateAge(profile.date_of_birth)} years old` : 'Not calculated'}
        </div>
      </div>

      <div>
        <Label htmlFor="location">Location</Label>
        {isEditing ? (
          <div className="space-y-1">
            <Input
              id="location"
              value={profile.location}
              onChange={(e) => handleInputChange('location', e.target.value)}
              placeholder="Enter your location (e.g., San Francisco, CA)"
              className="w-full"
              maxLength={200}
            />
            {validationErrors.location && (
              <p className="text-sm text-red-600">{validationErrors.location}</p>
            )}
          </div>
        ) : (
          <div className="p-2 border rounded-md bg-muted">
            {profile.location || 'Not provided'}
          </div>
        )}
      </div>

      <div className="md:col-span-2">
        <Label htmlFor="zip_code">Zip Code</Label>
        {isEditing ? (
          <div className="space-y-1">
            <Input
              id="zip_code"
              value={profile.zip_code}
              onChange={(e) => handleInputChange('zip_code', e.target.value)}
              placeholder="Enter your zip code"
              maxLength={20}
              className="md:w-1/2"
            />
            {validationErrors.zip_code && (
              <p className="text-sm text-red-600">{validationErrors.zip_code}</p>
            )}
          </div>
        ) : (
          <div className="p-2 border rounded-md bg-muted md:w-1/2">
            {profile.zip_code || 'Not provided'}
          </div>
        )}
      </div>
    </div>
  );
};
