
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { UserCircle, RefreshCw } from 'lucide-react';

interface ProfileErrorDisplayProps {
  error: string;
  onRetry: () => void;
}

export const ProfileErrorDisplay: React.FC<ProfileErrorDisplayProps> = ({
  error,
  onRetry
}) => {
  return (
    <Card>
      <CardContent className="text-center py-8">
        <UserCircle className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
        <h3 className="text-lg font-semibold mb-2 text-destructive">Connection Error</h3>
        <p className="text-muted-foreground mb-4">{error}</p>
        <Button onClick={onRetry}>
          <RefreshCw className="mr-2 h-4 w-4" />
          Try Again
        </Button>
      </CardContent>
    </Card>
  );
};
