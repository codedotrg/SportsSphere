
import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Star, User } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/components/ui/use-toast';

interface Player {
  id: string;
  full_name: string;
  email: string;
}

interface PlayerRatingProps {
  player: Player;
  eventId: string;
  onRatingSubmitted?: () => void;
}

export const PlayerRating: React.FC<PlayerRatingProps> = ({ 
  player, 
  eventId, 
  onRatingSubmitted 
}) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [rating, setRating] = useState(0);
  const [skillsRating, setSkillsRating] = useState(0);
  const [teamworkRating, setTeamworkRating] = useState(0);
  const [sportsmanshipRating, setSportsmanshipRating] = useState(0);
  const [review, setReview] = useState('');
  const [loading, setLoading] = useState(false);

  const StarRating = ({ 
    value, 
    onChange, 
    label 
  }: { 
    value: number; 
    onChange: (rating: number) => void; 
    label: string;
  }) => (
    <div className="space-y-2">
      <label className="text-sm font-medium">{label}</label>
      <div className="flex space-x-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`h-5 w-5 cursor-pointer transition-colors ${
              star <= value ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'
            }`}
            onClick={() => onChange(star)}
          />
        ))}
      </div>
    </div>
  );

  const handleSubmit = async () => {
    if (!user || rating === 0) {
      toast({
        title: "Error",
        description: "Please provide at least an overall rating",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);
    try {
      const { error } = await supabase
        .from('player_ratings')
        .upsert({
          rater_id: user.id,
          rated_player_id: player.id,
          event_id: eventId,
          rating,
          skills_rating: skillsRating || null,
          teamwork_rating: teamworkRating || null,
          sportsmanship_rating: sportsmanshipRating || null,
          review: review.trim() || null
        });

      if (error) throw error;

      toast({
        title: "Success",
        description: "Rating submitted successfully!"
      });

      // Reset form
      setRating(0);
      setSkillsRating(0);
      setTeamworkRating(0);
      setSportsmanshipRating(0);
      setReview('');

      onRatingSubmitted?.();
    } catch (error: any) {
      console.error('Error submitting rating:', error);
      toast({
        title: "Error",
        description: "Failed to submit rating",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  if (!user || user.id === player.id) {
    return null; // Can't rate yourself
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <User className="h-5 w-5" />
          <span>Rate {player.full_name}</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <StarRating
          value={rating}
          onChange={setRating}
          label="Overall Rating *"
        />
        
        <StarRating
          value={skillsRating}
          onChange={setSkillsRating}
          label="Skills"
        />
        
        <StarRating
          value={teamworkRating}
          onChange={setTeamworkRating}
          label="Teamwork"
        />
        
        <StarRating
          value={sportsmanshipRating}
          onChange={setSportsmanshipRating}
          label="Sportsmanship"
        />

        <div className="space-y-2">
          <label className="text-sm font-medium">Review (Optional)</label>
          <Textarea
            value={review}
            onChange={(e) => setReview(e.target.value)}
            placeholder="Share your thoughts about playing with this player..."
            rows={3}
          />
        </div>

        <Button 
          onClick={handleSubmit}
          disabled={loading || rating === 0}
          className="w-full"
        >
          {loading ? 'Submitting...' : 'Submit Rating'}
        </Button>
      </CardContent>
    </Card>
  );
};
