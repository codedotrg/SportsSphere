
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';

interface TeamCreationFormProps {
  newTeam: {
    team_name: string;
    description: string;
    max_members: number;
  };
  onTeamChange: (team: { team_name: string; description: string; max_members: number }) => void;
  onCreateTeam: () => void;
  onCancel: () => void;
}

export const TeamCreationForm: React.FC<TeamCreationFormProps> = ({
  newTeam,
  onTeamChange,
  onCreateTeam,
  onCancel
}) => {
  return (
    <Card>
      <CardContent className="pt-6">
        <h3 className="text-lg font-semibold mb-4">Create New Team</h3>
        <div className="space-y-4">
          <Input
            placeholder="Team name"
            value={newTeam.team_name}
            onChange={(e) => onTeamChange({ ...newTeam, team_name: e.target.value })}
          />
          <Textarea
            placeholder="Team description (optional)"
            value={newTeam.description}
            onChange={(e) => onTeamChange({ ...newTeam, description: e.target.value })}
            rows={3}
          />
          <div>
            <label className="block text-sm font-medium mb-2">Max Members</label>
            <Input
              type="number"
              min="2"
              max="20"
              value={newTeam.max_members}
              onChange={(e) => onTeamChange({ ...newTeam, max_members: parseInt(e.target.value) || 5 })}
            />
          </div>
          <div className="flex space-x-2">
            <Button onClick={onCreateTeam}>Create Team</Button>
            <Button variant="outline" onClick={onCancel}>
              Cancel
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
