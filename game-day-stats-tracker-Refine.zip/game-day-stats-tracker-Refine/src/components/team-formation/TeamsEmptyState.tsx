
import React from 'react';
import { Users } from 'lucide-react';

export const TeamsEmptyState: React.FC = () => {
  return (
    <div className="text-center py-8">
      <Users className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
      <h3 className="text-lg font-semibold mb-2">No Teams Yet</h3>
      <p className="text-muted-foreground mb-4">
        Be the first to create a team for this event!
      </p>
    </div>
  );
};
