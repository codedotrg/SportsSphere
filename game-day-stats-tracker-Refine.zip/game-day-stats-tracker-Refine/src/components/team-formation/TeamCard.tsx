
import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { 
  Users, 
  User, 
  Crown, 
  MessageSquare
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useTeamJoinActions } from '@/hooks/useTeamJoinActions';
import { TeamJoinRequestForm } from './TeamJoinRequestForm';
import { PendingJoinRequests } from './PendingJoinRequests';
import { TeamInvitationSystem } from './TeamInvitationSystem';

interface Team {
  id: string;
  team_name: string;
  description: string | null;
  max_members: number;
  created_by: string;
  members: {
    id: string;
    player_id: string;
    is_captain: boolean;
    profile?: {
      full_name: string;
      email: string;
    };
  }[];
}

interface TeamCardProps {
  team: Team;
  eventId: string;
  canManageTeam: (team: Team) => boolean;
  isUserInAnyTeam: boolean;
  onAddPlayerToTeam: (teamId: string, playerId: string) => Promise<void>;
  isOrganizer?: boolean;
}

export const TeamCard: React.FC<TeamCardProps> = ({
  team,
  eventId,
  canManageTeam,
  isUserInAnyTeam,
  onAddPlayerToTeam,
  isOrganizer = false
}) => {
  const { user } = useAuth();
  
  const {
    pendingRequests,
    joinRequestMessage,
    setJoinRequestMessage,
    showJoinRequestForm,
    setShowJoinRequestForm,
    handleSendJoinRequest,
    handleCancelJoinRequest,
    respondToRequest
  } = useTeamJoinActions(team.id);

  const userIsInThisTeam = team.members.some(m => m.player_id === user?.id);
  const userCanManage = canManageTeam(team);

  const handlePlayerInvited = () => {
    // Refresh team data or show success message
    console.log('Player invited to team');
  };

  return (
    <Card className="relative">
      <CardContent className="pt-6">
        <div className="space-y-4">
          {/* Team Header */}
          <div className="flex justify-between items-start">
            <div>
              <h4 className="font-semibold">{team.team_name}</h4>
              {team.description && (
                <p className="text-sm text-muted-foreground mt-1">
                  {team.description}
                </p>
              )}
            </div>
            <Badge variant="outline">
              {team.members.length}/{team.max_members}
            </Badge>
          </div>

          <Separator />

          {/* Team Members */}
          <div>
            <h5 className="font-medium mb-2">Members</h5>
            {team.members.length === 0 ? (
              <p className="text-sm text-muted-foreground">No members yet</p>
            ) : (
              <div className="space-y-2">
                {team.members.map((member) => (
                  <div key={member.id} className="flex items-center space-x-2">
                    <User className="h-4 w-4" />
                    <span className="text-sm">
                      {member.profile?.full_name || 'Unknown Player'}
                    </span>
                    {member.is_captain && (
                      <Crown className="h-3 w-3 text-yellow-500" />
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Pending Join Requests */}
          {userCanManage && (
            <PendingJoinRequests
              requests={pendingRequests}
              onApprove={(requestId) => respondToRequest(requestId, 'approved')}
              onReject={(requestId) => respondToRequest(requestId, 'rejected')}
            />
          )}

          {/* Action Buttons */}
          <div className="flex space-x-2">
            {/* Only organizers can invite players */}
            {isOrganizer && userCanManage && team.members.length < team.max_members && (
              <TeamInvitationSystem
                teamId={team.id}
                eventId={eventId}
                onPlayerInvited={handlePlayerInvited}
              />
            )}

            {/* Only show join request to non-organizers who are not in any team */}
            {!isOrganizer && !userIsInThisTeam && !isUserInAnyTeam && user && (
              <Button
                size="sm"
                onClick={() => setShowJoinRequestForm(!showJoinRequestForm)}
              >
                <MessageSquare className="mr-2 h-4 w-4" />
                Request to Join
              </Button>
            )}
          </div>

          {/* Join Request Form */}
          {showJoinRequestForm && (
            <TeamJoinRequestForm
              message={joinRequestMessage}
              onMessageChange={setJoinRequestMessage}
              onSendRequest={handleSendJoinRequest}
              onCancel={handleCancelJoinRequest}
            />
          )}
        </div>
      </CardContent>
    </Card>
  );
};
