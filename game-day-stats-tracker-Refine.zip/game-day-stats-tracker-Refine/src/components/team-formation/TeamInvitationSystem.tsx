
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Search, UserPlus } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/components/ui/use-toast';

interface Player {
  id: string;
  full_name: string;
  email: string;
}

interface TeamInvitationSystemProps {
  teamId: string;
  eventId: string;
  onPlayerInvited: () => void;
}

export const TeamInvitationSystem: React.FC<TeamInvitationSystemProps> = ({
  teamId,
  eventId,
  onPlayerInvited
}) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [showInviteDialog, setShowInviteDialog] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [players, setPlayers] = useState<Player[]>([]);
  const [loading, setLoading] = useState(false);

  const searchPlayers = async () => {
    if (!searchTerm.trim()) return;

    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('id, full_name, email')
        .or(`full_name.ilike.%${searchTerm}%,email.ilike.%${searchTerm}%`)
        .neq('id', user?.id)
        .limit(10);

      if (error) throw error;
      setPlayers(data || []);
    } catch (error) {
      console.error('Error searching players:', error);
      toast({
        title: "Error",
        description: "Failed to search players",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const sendTeamInvitation = async (playerId: string) => {
    try {
      // Create notification for the invited player
      const { error: notificationError } = await supabase
        .from('notifications')
        .insert({
          user_id: playerId,
          type: 'team_invitation',
          title: 'Team Invitation',
          content: `You have been invited to join a team for an event`,
          related_id: teamId
        });

      if (notificationError) throw notificationError;

      toast({
        title: "Success",
        description: "Team invitation sent successfully!"
      });

      setShowInviteDialog(false);
      setSearchTerm('');
      setPlayers([]);
      onPlayerInvited();
    } catch (error) {
      console.error('Error sending team invitation:', error);
      toast({
        title: "Error",
        description: "Failed to send team invitation",
        variant: "destructive"
      });
    }
  };

  return (
    <>
      <Button
        size="sm"
        variant="outline"
        onClick={() => setShowInviteDialog(true)}
      >
        <UserPlus className="mr-2 h-4 w-4" />
        Invite Player
      </Button>

      <Dialog open={showInviteDialog} onOpenChange={setShowInviteDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Invite Player to Team</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="flex space-x-2">
              <Input
                placeholder="Search by name or email..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && searchPlayers()}
              />
              <Button onClick={searchPlayers} disabled={loading}>
                <Search className="h-4 w-4" />
              </Button>
            </div>

            {loading && (
              <p className="text-sm text-muted-foreground">Searching...</p>
            )}

            {players.length > 0 && (
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {players.map((player) => (
                  <div key={player.id} className="flex items-center justify-between p-3 border rounded">
                    <div>
                      <p className="font-medium">{player.full_name}</p>
                      <p className="text-sm text-muted-foreground">{player.email}</p>
                    </div>
                    <Button
                      size="sm"
                      onClick={() => sendTeamInvitation(player.id)}
                    >
                      Invite
                    </Button>
                  </div>
                ))}
              </div>
            )}

            {searchTerm && !loading && players.length === 0 && (
              <p className="text-sm text-muted-foreground text-center py-4">
                No players found matching your search.
              </p>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};
