
import React from 'react';
import { Button } from '@/components/ui/button';
import { Check, X } from 'lucide-react';

interface JoinRequest {
  id: string;
  message: string | null;
  profile?: {
    full_name: string;
    email: string;
  } | null;
}

interface PendingJoinRequestsProps {
  requests: JoinRequest[];
  onApprove: (requestId: string) => void;
  onReject: (requestId: string) => void;
}

export const PendingJoinRequests: React.FC<PendingJoinRequestsProps> = ({
  requests,
  onApprove,
  onReject
}) => {
  if (requests.length === 0) return null;

  return (
    <div className="border rounded-lg p-3 bg-muted">
      <h4 className="font-medium mb-3">Pending Join Requests</h4>
      <div className="space-y-2">
        {requests.map((request) => (
          <div key={request.id} className="flex items-center justify-between p-2 bg-background rounded">
            <div>
              <p className="text-sm font-medium">{request.profile?.full_name}</p>
              {request.message && (
                <p className="text-xs text-muted-foreground">"{request.message}"</p>
              )}
            </div>
            <div className="flex space-x-2">
              <Button
                size="sm"
                onClick={() => onApprove(request.id)}
              >
                <Check className="h-3 w-3" />
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => onReject(request.id)}
              >
                <X className="h-3 w-3" />
              </Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
