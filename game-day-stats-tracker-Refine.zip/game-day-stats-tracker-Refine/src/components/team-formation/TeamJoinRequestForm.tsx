
import React from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';

interface TeamJoinRequestFormProps {
  message: string;
  onMessageChange: (message: string) => void;
  onSendRequest: () => void;
  onCancel: () => void;
}

export const TeamJoinRequestForm: React.FC<TeamJoinRequestFormProps> = ({
  message,
  onMessageChange,
  onSendRequest,
  onCancel
}) => {
  return (
    <div className="border-t pt-4 space-y-3">
      <Textarea
        placeholder="Optional message to team (why you want to join, your skills, etc.)"
        value={message}
        onChange={(e) => onMessageChange(e.target.value)}
        rows={3}
      />
      <div className="flex space-x-2">
        <Button size="sm" onClick={onSendRequest}>
          Send Request
        </Button>
        <Button size="sm" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
      </div>
    </div>
  );
};
