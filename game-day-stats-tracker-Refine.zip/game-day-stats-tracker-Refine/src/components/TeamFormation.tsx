
import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Plus, Users } from 'lucide-react';
import { TeamCard } from '@/components/team-formation/TeamCard';
import { TeamCreationForm } from '@/components/team-formation/TeamCreationForm';
import { TeamsEmptyState } from '@/components/team-formation/TeamsEmptyState';
import { useTeamFormation } from '@/hooks/useTeamFormation';

interface Participant {
  id: string;
  player_id: string;
  profile?: {
    full_name: string;
    email: string;
  };
}

interface TeamFormationProps {
  eventId: string;
  isOrganizer: boolean;
  participants: Participant[];
}

export const TeamFormation: React.FC<TeamFormationProps> = ({
  eventId,
  isOrganizer,
  participants
}) => {
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [newTeam, setNewTeam] = useState({
    team_name: '',
    description: '',
    max_members: 5
  });

  const {
    teams,
    loading,
    fetchTeams,
    createTeam,
    addPlayerToTeam,
    isUserInAnyTeam,
    canManageTeam
  } = useTeamFormation(eventId);

  const handleCreateTeam = async () => {
    const success = await createTeam(newTeam);
    if (success) {
      setNewTeam({ team_name: '', description: '', max_members: 5 });
      setShowCreateForm(false);
    }
  };

  useEffect(() => {
    fetchTeams();
  }, [eventId]);

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle className="flex items-center">
            <Users className="mr-2 h-5 w-5" />
            Team Formation
          </CardTitle>
          {(isOrganizer || !isUserInAnyTeam()) && (
            <Button onClick={() => setShowCreateForm(true)}>
              <Plus className="mr-2 h-4 w-4" />
              Create Team
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {showCreateForm && (
          <TeamCreationForm
            newTeam={newTeam}
            onTeamChange={setNewTeam}
            onCreateTeam={handleCreateTeam}
            onCancel={() => setShowCreateForm(false)}
          />
        )}

        {loading ? (
          <div className="text-center py-4">
            <p className="text-muted-foreground">Loading teams...</p>
          </div>
        ) : teams.length === 0 ? (
          <TeamsEmptyState />
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {teams.map((team) => (
              <TeamCard
                key={team.id}
                team={team}
                eventId={eventId}
                canManageTeam={(t) => canManageTeam(t, isOrganizer)}
                isUserInAnyTeam={isUserInAnyTeam()}
                onAddPlayerToTeam={addPlayerToTeam}
                isOrganizer={isOrganizer}
              />
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};
