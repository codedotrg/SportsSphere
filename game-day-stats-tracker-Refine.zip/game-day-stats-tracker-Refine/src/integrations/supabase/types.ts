export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  public: {
    Tables: {
      achievements: {
        Row: {
          category: string
          created_at: string
          criteria: Json | null
          description: string
          icon: string | null
          id: string
          name: string
          points: number | null
        }
        Insert: {
          category: string
          created_at?: string
          criteria?: Json | null
          description: string
          icon?: string | null
          id?: string
          name: string
          points?: number | null
        }
        Update: {
          category?: string
          created_at?: string
          criteria?: Json | null
          description?: string
          icon?: string | null
          id?: string
          name?: string
          points?: number | null
        }
        Relationships: []
      }
      ai_matchmaking_preferences: {
        Row: {
          ai_personality_match: boolean | null
          avoid_users: string[] | null
          created_at: string | null
          id: string
          max_distance_km: number | null
          preferred_age_range: unknown | null
          preferred_play_times: Json | null
          preferred_skill_level: string | null
          preferred_sports: string[] | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          ai_personality_match?: boolean | null
          avoid_users?: string[] | null
          created_at?: string | null
          id?: string
          max_distance_km?: number | null
          preferred_age_range?: unknown | null
          preferred_play_times?: Json | null
          preferred_skill_level?: string | null
          preferred_sports?: string[] | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          ai_personality_match?: boolean | null
          avoid_users?: string[] | null
          created_at?: string | null
          id?: string
          max_distance_km?: number | null
          preferred_age_range?: unknown | null
          preferred_play_times?: Json | null
          preferred_skill_level?: string | null
          preferred_sports?: string[] | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      challenge_participants: {
        Row: {
          challenge_id: string
          completed_at: string | null
          final_score: number | null
          id: string
          joined_at: string
          participant_id: string
          progress: Json | null
          status: string
          team_formation_id: string | null
        }
        Insert: {
          challenge_id: string
          completed_at?: string | null
          final_score?: number | null
          id?: string
          joined_at?: string
          participant_id: string
          progress?: Json | null
          status?: string
          team_formation_id?: string | null
        }
        Update: {
          challenge_id?: string
          completed_at?: string | null
          final_score?: number | null
          id?: string
          joined_at?: string
          participant_id?: string
          progress?: Json | null
          status?: string
          team_formation_id?: string | null
        }
        Relationships: []
      }
      event_announcements: {
        Row: {
          author_id: string
          content: string
          created_at: string
          event_id: string
          id: string
          is_important: boolean | null
          title: string
          updated_at: string
        }
        Insert: {
          author_id: string
          content: string
          created_at?: string
          event_id: string
          id?: string
          is_important?: boolean | null
          title: string
          updated_at?: string
        }
        Update: {
          author_id?: string
          content?: string
          created_at?: string
          event_id?: string
          id?: string
          is_important?: boolean | null
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "event_announcements_author_id_fkey"
            columns: ["author_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "event_announcements_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
        ]
      }
      event_join_requests: {
        Row: {
          event_id: string
          id: string
          message: string | null
          notification_sent: boolean | null
          player_id: string
          requested_at: string
          responded_at: string | null
          responded_by: string | null
          status: string
        }
        Insert: {
          event_id: string
          id?: string
          message?: string | null
          notification_sent?: boolean | null
          player_id: string
          requested_at?: string
          responded_at?: string | null
          responded_by?: string | null
          status?: string
        }
        Update: {
          event_id?: string
          id?: string
          message?: string | null
          notification_sent?: boolean | null
          player_id?: string
          requested_at?: string
          responded_at?: string | null
          responded_by?: string | null
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "event_join_requests_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "event_join_requests_player_id_fkey"
            columns: ["player_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "event_join_requests_responded_by_fkey"
            columns: ["responded_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      event_participants: {
        Row: {
          event_id: string
          id: string
          joined_at: string
          player_id: string
          position_played: string | null
          status: string | null
        }
        Insert: {
          event_id: string
          id?: string
          joined_at?: string
          player_id: string
          position_played?: string | null
          status?: string | null
        }
        Update: {
          event_id?: string
          id?: string
          joined_at?: string
          player_id?: string
          position_played?: string | null
          status?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "event_participants_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "event_participants_player_id_fkey"
            columns: ["player_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      events: {
        Row: {
          created_at: string
          description: string | null
          event_date: string
          id: string
          location: string | null
          organizer_id: string
          roles_needed: string[] | null
          sport: string | null
          title: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          event_date: string
          id?: string
          location?: string | null
          organizer_id: string
          roles_needed?: string[] | null
          sport?: string | null
          title: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          event_date?: string
          id?: string
          location?: string | null
          organizer_id?: string
          roles_needed?: string[] | null
          sport?: string | null
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "events_organizer_id_fkey"
            columns: ["organizer_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      mentorship_relationships: {
        Row: {
          completed_at: string | null
          created_at: string
          feedback: string | null
          goals: string[] | null
          id: string
          mentee_id: string
          mentee_rating: number | null
          mentor_id: string
          mentor_rating: number | null
          progress: Json | null
          sport: string | null
          started_at: string | null
          status: string
          updated_at: string
        }
        Insert: {
          completed_at?: string | null
          created_at?: string
          feedback?: string | null
          goals?: string[] | null
          id?: string
          mentee_id: string
          mentee_rating?: number | null
          mentor_id: string
          mentor_rating?: number | null
          progress?: Json | null
          sport?: string | null
          started_at?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          completed_at?: string | null
          created_at?: string
          feedback?: string | null
          goals?: string[] | null
          id?: string
          mentee_id?: string
          mentee_rating?: number | null
          mentor_id?: string
          mentor_rating?: number | null
          progress?: Json | null
          sport?: string | null
          started_at?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      message_attachments: {
        Row: {
          created_at: string
          file_name: string
          file_size: number | null
          file_type: string
          id: string
          message_id: string
          storage_path: string
        }
        Insert: {
          created_at?: string
          file_name: string
          file_size?: number | null
          file_type: string
          id?: string
          message_id: string
          storage_path: string
        }
        Update: {
          created_at?: string
          file_name?: string
          file_size?: number | null
          file_type?: string
          id?: string
          message_id?: string
          storage_path?: string
        }
        Relationships: []
      }
      messages: {
        Row: {
          content: string
          created_at: string
          event_id: string | null
          id: string
          is_read: boolean
          message_type: string
          recipient_id: string | null
          sender_id: string
          team_formation_id: string | null
          updated_at: string
        }
        Insert: {
          content: string
          created_at?: string
          event_id?: string | null
          id?: string
          is_read?: boolean
          message_type?: string
          recipient_id?: string | null
          sender_id: string
          team_formation_id?: string | null
          updated_at?: string
        }
        Update: {
          content?: string
          created_at?: string
          event_id?: string | null
          id?: string
          is_read?: boolean
          message_type?: string
          recipient_id?: string | null
          sender_id?: string
          team_formation_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "messages_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "messages_recipient_id_fkey"
            columns: ["recipient_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "messages_sender_id_fkey"
            columns: ["sender_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "messages_team_formation_id_fkey"
            columns: ["team_formation_id"]
            isOneToOne: false
            referencedRelation: "team_formations"
            referencedColumns: ["id"]
          },
        ]
      }
      notifications: {
        Row: {
          content: string
          created_at: string
          id: string
          invitation_type: string | null
          is_read: boolean
          related_id: string | null
          team_formation_id: string | null
          title: string
          type: string
          updated_at: string
          user_id: string
        }
        Insert: {
          content: string
          created_at?: string
          id?: string
          invitation_type?: string | null
          is_read?: boolean
          related_id?: string | null
          team_formation_id?: string | null
          title: string
          type: string
          updated_at?: string
          user_id: string
        }
        Update: {
          content?: string
          created_at?: string
          id?: string
          invitation_type?: string | null
          is_read?: boolean
          related_id?: string | null
          team_formation_id?: string | null
          title?: string
          type?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "notifications_team_formation_id_fkey"
            columns: ["team_formation_id"]
            isOneToOne: false
            referencedRelation: "team_formations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "notifications_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      player_availability: {
        Row: {
          created_at: string
          day_of_week: number
          end_time: string
          id: string
          is_active: boolean | null
          player_id: string
          start_time: string
          timezone: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          day_of_week: number
          end_time: string
          id?: string
          is_active?: boolean | null
          player_id: string
          start_time: string
          timezone?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          day_of_week?: number
          end_time?: string
          id?: string
          is_active?: boolean | null
          player_id?: string
          start_time?: string
          timezone?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      player_connections: {
        Row: {
          common_sports: string[] | null
          connection_notes: string | null
          connection_strength: number | null
          created_at: string
          events_together: number | null
          id: string
          last_interaction_at: string | null
          messages_exchanged: number | null
          player1_id: string
          player2_id: string
          updated_at: string
        }
        Insert: {
          common_sports?: string[] | null
          connection_notes?: string | null
          connection_strength?: number | null
          created_at?: string
          events_together?: number | null
          id?: string
          last_interaction_at?: string | null
          messages_exchanged?: number | null
          player1_id: string
          player2_id: string
          updated_at?: string
        }
        Update: {
          common_sports?: string[] | null
          connection_notes?: string | null
          connection_strength?: number | null
          created_at?: string
          events_together?: number | null
          id?: string
          last_interaction_at?: string | null
          messages_exchanged?: number | null
          player1_id?: string
          player2_id?: string
          updated_at?: string
        }
        Relationships: []
      }
      player_endorsements: {
        Row: {
          comment: string | null
          created_at: string
          endorsed_id: string
          endorsement_type: string
          endorser_id: string
          id: string
          skill_name: string | null
          strength_rating: number | null
        }
        Insert: {
          comment?: string | null
          created_at?: string
          endorsed_id: string
          endorsement_type: string
          endorser_id: string
          id?: string
          skill_name?: string | null
          strength_rating?: number | null
        }
        Update: {
          comment?: string | null
          created_at?: string
          endorsed_id?: string
          endorsement_type?: string
          endorser_id?: string
          id?: string
          skill_name?: string | null
          strength_rating?: number | null
        }
        Relationships: []
      }
      player_performance_stats: {
        Row: {
          created_at: string | null
          event_id: string | null
          id: string
          individual_rating: number | null
          performance_metrics: Json | null
          player_id: string
          recorded_by: string
          sport: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          event_id?: string | null
          id?: string
          individual_rating?: number | null
          performance_metrics?: Json | null
          player_id: string
          recorded_by: string
          sport: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          event_id?: string | null
          id?: string
          individual_rating?: number | null
          performance_metrics?: Json | null
          player_id?: string
          recorded_by?: string
          sport?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "player_performance_stats_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
        ]
      }
      player_ratings: {
        Row: {
          created_at: string
          event_id: string
          id: string
          rated_player_id: string
          rater_id: string
          rating: number
          review: string | null
          skills_rating: number | null
          sportsmanship_rating: number | null
          teamwork_rating: number | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          event_id: string
          id?: string
          rated_player_id: string
          rater_id: string
          rating: number
          review?: string | null
          skills_rating?: number | null
          sportsmanship_rating?: number | null
          teamwork_rating?: number | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          event_id?: string
          id?: string
          rated_player_id?: string
          rater_id?: string
          rating?: number
          review?: string | null
          skills_rating?: number | null
          sportsmanship_rating?: number | null
          teamwork_rating?: number | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "player_ratings_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "player_ratings_rated_player_id_fkey"
            columns: ["rated_player_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "player_ratings_rater_id_fkey"
            columns: ["rater_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      player_requirements: {
        Row: {
          created_at: string
          created_by: string
          description: string | null
          event_id: string
          experience_level: string | null
          id: string
          is_completed: boolean | null
          max_players: number | null
          role_name: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by: string
          description?: string | null
          event_id: string
          experience_level?: string | null
          id?: string
          is_completed?: boolean | null
          max_players?: number | null
          role_name: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string
          description?: string | null
          event_id?: string
          experience_level?: string | null
          id?: string
          is_completed?: boolean | null
          max_players?: number | null
          role_name?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "player_requirements_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "player_requirements_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
        ]
      }
      player_skills: {
        Row: {
          created_at: string
          id: string
          player_id: string
          skill_level: number
          skill_name: string
          skill_type: string
          sport: string
          updated_at: string
          verified_at: string | null
          verified_by: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          player_id: string
          skill_level: number
          skill_name: string
          skill_type: string
          sport: string
          updated_at?: string
          verified_at?: string | null
          verified_by?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          player_id?: string
          skill_level?: number
          skill_name?: string
          skill_type?: string
          sport?: string
          updated_at?: string
          verified_at?: string | null
          verified_by?: string | null
        }
        Relationships: []
      }
      profiles: {
        Row: {
          created_at: string
          date_of_birth: string | null
          email: string
          full_name: string | null
          gender: string | null
          id: string
          location: string | null
          profile_picture: string | null
          updated_at: string
          zip_code: string | null
        }
        Insert: {
          created_at?: string
          date_of_birth?: string | null
          email: string
          full_name?: string | null
          gender?: string | null
          id: string
          location?: string | null
          profile_picture?: string | null
          updated_at?: string
          zip_code?: string | null
        }
        Update: {
          created_at?: string
          date_of_birth?: string | null
          email?: string
          full_name?: string | null
          gender?: string | null
          id?: string
          location?: string | null
          profile_picture?: string | null
          updated_at?: string
          zip_code?: string | null
        }
        Relationships: []
      }
      ratings: {
        Row: {
          comment: string | null
          created_at: string
          event_id: string
          id: string
          position_rated_for: string | null
          ratee_id: string
          rater_id: string
          rating: number
          updated_at: string
        }
        Insert: {
          comment?: string | null
          created_at?: string
          event_id: string
          id?: string
          position_rated_for?: string | null
          ratee_id: string
          rater_id: string
          rating: number
          updated_at?: string
        }
        Update: {
          comment?: string | null
          created_at?: string
          event_id?: string
          id?: string
          position_rated_for?: string | null
          ratee_id?: string
          rater_id?: string
          rating?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "ratings_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ratings_ratee_id_fkey"
            columns: ["ratee_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ratings_rater_id_fkey"
            columns: ["rater_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      smart_schedules: {
        Row: {
          created_at: string | null
          id: string
          preferences: Json | null
          schedule_data: Json | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          preferences?: Json | null
          schedule_data?: Json | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          preferences?: Json | null
          schedule_data?: Json | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      social_challenges: {
        Row: {
          challenge_type: string
          created_at: string
          created_by: string
          description: string
          difficulty_level: string
          end_date: string
          id: string
          is_active: boolean | null
          max_participants: number | null
          points_reward: number | null
          requirements: Json | null
          sport: string | null
          start_date: string
          title: string
        }
        Insert: {
          challenge_type: string
          created_at?: string
          created_by: string
          description: string
          difficulty_level: string
          end_date: string
          id?: string
          is_active?: boolean | null
          max_participants?: number | null
          points_reward?: number | null
          requirements?: Json | null
          sport?: string | null
          start_date: string
          title: string
        }
        Update: {
          challenge_type?: string
          created_at?: string
          created_by?: string
          description?: string
          difficulty_level?: string
          end_date?: string
          id?: string
          is_active?: boolean | null
          max_participants?: number | null
          points_reward?: number | null
          requirements?: Json | null
          sport?: string | null
          start_date?: string
          title?: string
        }
        Relationships: []
      }
      team_chemistry: {
        Row: {
          chemistry_score: number | null
          created_at: string
          games_played_together: number | null
          id: string
          last_interaction_at: string | null
          negative_interactions: number | null
          player1_id: string
          player2_id: string
          positive_interactions: number | null
          team_formation_id: string
          updated_at: string
        }
        Insert: {
          chemistry_score?: number | null
          created_at?: string
          games_played_together?: number | null
          id?: string
          last_interaction_at?: string | null
          negative_interactions?: number | null
          player1_id: string
          player2_id: string
          positive_interactions?: number | null
          team_formation_id: string
          updated_at?: string
        }
        Update: {
          chemistry_score?: number | null
          created_at?: string
          games_played_together?: number | null
          id?: string
          last_interaction_at?: string | null
          negative_interactions?: number | null
          player1_id?: string
          player2_id?: string
          positive_interactions?: number | null
          team_formation_id?: string
          updated_at?: string
        }
        Relationships: []
      }
      team_formations: {
        Row: {
          created_at: string
          created_by: string
          description: string | null
          event_id: string
          formation_type: string | null
          id: string
          max_members: number | null
          team_name: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by: string
          description?: string | null
          event_id: string
          formation_type?: string | null
          id?: string
          max_members?: number | null
          team_name: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string
          description?: string | null
          event_id?: string
          formation_type?: string | null
          id?: string
          max_members?: number | null
          team_name?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "team_formations_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "team_formations_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
        ]
      }
      team_join_requests: {
        Row: {
          id: string
          message: string | null
          player_id: string
          requested_at: string
          responded_at: string | null
          responded_by: string | null
          status: string
          team_formation_id: string
        }
        Insert: {
          id?: string
          message?: string | null
          player_id: string
          requested_at?: string
          responded_at?: string | null
          responded_by?: string | null
          status?: string
          team_formation_id: string
        }
        Update: {
          id?: string
          message?: string | null
          player_id?: string
          requested_at?: string
          responded_at?: string | null
          responded_by?: string | null
          status?: string
          team_formation_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "team_join_requests_player_id_fkey"
            columns: ["player_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "team_join_requests_responded_by_fkey"
            columns: ["responded_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "team_join_requests_team_formation_id_fkey"
            columns: ["team_formation_id"]
            isOneToOne: false
            referencedRelation: "team_formations"
            referencedColumns: ["id"]
          },
        ]
      }
      team_members: {
        Row: {
          created_at: string
          id: string
          is_captain: boolean | null
          player_id: string
          position: string | null
          team_formation_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_captain?: boolean | null
          player_id: string
          position?: string | null
          team_formation_id: string
        }
        Update: {
          created_at?: string
          id?: string
          is_captain?: boolean | null
          player_id?: string
          position?: string | null
          team_formation_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "team_members_player_id_fkey"
            columns: ["player_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "team_members_team_formation_id_fkey"
            columns: ["team_formation_id"]
            isOneToOne: false
            referencedRelation: "team_formations"
            referencedColumns: ["id"]
          },
        ]
      }
      user_achievements: {
        Row: {
          achievement_id: string
          earned_at: string
          id: string
          user_id: string
        }
        Insert: {
          achievement_id: string
          earned_at?: string
          id?: string
          user_id: string
        }
        Update: {
          achievement_id?: string
          earned_at?: string
          id?: string
          user_id?: string
        }
        Relationships: []
      }
      user_activities: {
        Row: {
          activity_type: string
          created_at: string
          description: string
          id: string
          metadata: Json | null
          related_id: string | null
          user_id: string
        }
        Insert: {
          activity_type: string
          created_at?: string
          description: string
          id?: string
          metadata?: Json | null
          related_id?: string | null
          user_id: string
        }
        Update: {
          activity_type?: string
          created_at?: string
          description?: string
          id?: string
          metadata?: Json | null
          related_id?: string | null
          user_id?: string
        }
        Relationships: []
      }
      user_follows: {
        Row: {
          created_at: string
          follower_id: string
          following_id: string
          id: string
        }
        Insert: {
          created_at?: string
          follower_id: string
          following_id: string
          id?: string
        }
        Update: {
          created_at?: string
          follower_id?: string
          following_id?: string
          id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_follows_follower_id_fkey"
            columns: ["follower_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "user_follows_following_id_fkey"
            columns: ["following_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      user_preferences: {
        Row: {
          calendar_sync_enabled: boolean | null
          created_at: string
          id: string
          max_distance: number | null
          notification_settings: Json | null
          preferred_sports: string[] | null
          skill_level: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          calendar_sync_enabled?: boolean | null
          created_at?: string
          id?: string
          max_distance?: number | null
          notification_settings?: Json | null
          preferred_sports?: string[] | null
          skill_level?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          calendar_sync_enabled?: boolean | null
          created_at?: string
          id?: string
          max_distance?: number | null
          notification_settings?: Json | null
          preferred_sports?: string[] | null
          skill_level?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      calculate_team_chemistry: {
        Args: {
          _team_formation_id: string
          _player1_id: string
          _player2_id: string
        }
        Returns: number
      }
      get_user_preferences: {
        Args: { p_user_id: string }
        Returns: {
          id: string
          user_id: string
          preferred_skill_level: string
          preferred_age_range: unknown
          max_distance_km: number
          preferred_play_times: Json
          ai_personality_match: boolean
          preferred_sports: string[]
          avoid_users: string[]
        }[]
      }
      is_event_organizer: {
        Args: { _event_id: string; _user_id: string }
        Returns: boolean
      }
      save_performance_stats: {
        Args: {
          p_player_id: string
          p_event_id: string
          p_sport: string
          p_metrics: Json
          p_individual_rating: number
          p_recorded_by: string
        }
        Returns: undefined
      }
      update_connection_strength: {
        Args: { _player1_id: string; _player2_id: string }
        Returns: undefined
      }
      upsert_ai_preferences: {
        Args: { p_user_id: string; p_preferences: Json }
        Returns: undefined
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DefaultSchema = Database[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof Database },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof Database },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends { schema: keyof Database }
  ? Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
