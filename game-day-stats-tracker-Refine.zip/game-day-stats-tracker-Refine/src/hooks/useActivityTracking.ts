
import { useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

interface ActivityData {
  activity_type: string;
  description: string;
  related_id?: string;
  metadata?: any;
}

export const useActivityTracking = () => {
  const { user } = useAuth();

  const trackActivity = useCallback(async (activityData: ActivityData) => {
    if (!user) return;

    try {
      const { error } = await supabase
        .from('user_activities')
        .insert({
          user_id: user.id,
          ...activityData
        });

      if (error) {
        console.error('Error tracking activity:', error);
      }
    } catch (error) {
      console.error('Error tracking activity:', error);
    }
  }, [user]);

  const trackEventJoin = useCallback((eventId: string, eventTitle: string) => {
    trackActivity({
      activity_type: 'event_joined',
      description: `Joined event: ${eventTitle}`,
      related_id: eventId
    });
  }, [trackActivity]);

  const trackEventCreate = useCallback((eventId: string, eventTitle: string) => {
    trackActivity({
      activity_type: 'event_created',
      description: `Created event: ${eventTitle}`,
      related_id: eventId
    });
  }, [trackActivity]);

  const trackMessageSent = useCallback((recipientName: string) => {
    trackActivity({
      activity_type: 'message_sent',
      description: `Sent message to ${recipientName}`
    });
  }, [trackActivity]);

  const trackProfileUpdate = useCallback(() => {
    trackActivity({
      activity_type: 'profile_updated',
      description: 'Updated profile information'
    });
  }, [trackActivity]);

  return {
    trackActivity,
    trackEventJoin,
    trackEventCreate,
    trackMessageSent,
    trackProfileUpdate
  };
};
