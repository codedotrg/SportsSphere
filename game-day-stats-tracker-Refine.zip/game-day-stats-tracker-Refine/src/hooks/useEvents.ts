
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/AuthContext';

interface Event {
  id: string;
  title: string;
  description: string;
  sport: string;
  location: string;
  event_date: string;
  organizer_id: string;
  created_at: string;
}

export const useEvents = () => {
  const { user, loading: authLoading } = useAuth();
  const { toast } = useToast();
  const [events, setEvents] = useState<Event[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchEvents = async () => {
    console.log('Starting to fetch events...');
    setLoading(true);
    setError(null);
    
    try {
      console.log('User authenticated, fetching events from database...');
      
      const { data, error } = await supabase
        .from('events')
        .select('*')
        .order('event_date', { ascending: true });

      if (error) {
        console.error('Supabase error fetching events:', error);
        throw error;
      }

      console.log('Successfully fetched events:', data?.length || 0, 'events');
      setEvents(data || []);
      
      if (data && data.length === 0) {
        console.log('No events found in database');
      }
    } catch (error: any) {
      console.error('Error fetching events:', error);
      
      let errorMessage = 'Failed to load events. Please try again.';
      
      if (error.message?.includes('JWT')) {
        errorMessage = 'Authentication expired. Please refresh the page and try again.';
      } else if (error.message?.includes('Failed to fetch') || error.code === 'NETWORK_ERROR') {
        errorMessage = 'Connection error. Please check your internet connection and try again.';
      } else if (error.message?.includes('RLS') || error.code === 'PGRST116') {
        errorMessage = 'Access denied. Please ensure you are logged in properly.';
      }
      
      setError(errorMessage);
      
      // Only show toast for critical errors, not network issues
      if (!error.message?.includes('Failed to fetch')) {
        toast({
          title: "Error",
          description: errorMessage,
          variant: "destructive"
        });
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    // Only fetch if user is authenticated and auth is not loading
    if (!authLoading) {
      if (user) {
        console.log('User is authenticated, proceeding to fetch events');
        fetchEvents();
      } else {
        console.log('User not authenticated, cannot fetch events');
        setLoading(false);
        setError('Please log in to view events');
      }
    }
  }, [authLoading, user?.id]);

  return {
    events,
    loading,
    error,
    authLoading,
    user,
    refetch: fetchEvents
  };
};
