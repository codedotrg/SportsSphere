
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/AuthContext';

interface TeamJoinRequest {
  id: string;
  team_formation_id: string;
  player_id: string;
  message: string | null;
  status: 'pending' | 'approved' | 'rejected';
  requested_at: string;
  responded_at: string | null;
  responded_by: string | null;
  profile: {
    full_name: string;
    email: string;
  } | null;
  team_formation: {
    team_name: string;
  } | null;
}

export const useTeamJoinRequests = (teamId?: string) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [requests, setRequests] = useState<TeamJoinRequest[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchRequests = async () => {
    if (!user || !teamId) return;

    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('team_join_requests')
        .select(`
          *,
          profile:profiles!team_join_requests_player_id_fkey(full_name, email),
          team_formation:team_formations(team_name)
        `)
        .eq('team_formation_id', teamId)
        .order('requested_at', { ascending: false });

      if (error) throw error;
      
      const typedRequests = (data || []).map(req => ({
        ...req,
        status: req.status as 'pending' | 'approved' | 'rejected',
        profile: req.profile && Array.isArray(req.profile) 
          ? req.profile[0] || null
          : req.profile || null,
        team_formation: req.team_formation && Array.isArray(req.team_formation)
          ? req.team_formation[0] || null
          : req.team_formation || null
      }));
      
      setRequests(typedRequests);
    } catch (error: any) {
      console.error('Error fetching team join requests:', error);
      toast({
        title: "Error",
        description: "Failed to load team join requests",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const sendJoinRequest = async (teamId: string, message?: string) => {
    if (!user) return false;

    try {
      const { error } = await supabase
        .from('team_join_requests')
        .insert({
          team_formation_id: teamId,
          player_id: user.id,
          message: message || null
        });

      if (error) throw error;

      toast({
        title: "Success",
        description: "Join request sent successfully!"
      });

      fetchRequests();
      return true;
    } catch (error: any) {
      console.error('Error sending join request:', error);
      toast({
        title: "Error",
        description: error.message.includes('duplicate') 
          ? "You have already requested to join this team"
          : "Failed to send join request",
        variant: "destructive"
      });
      return false;
    }
  };

  const respondToRequest = async (requestId: string, status: 'approved' | 'rejected') => {
    if (!user) return false;

    try {
      const { error } = await supabase
        .from('team_join_requests')
        .update({
          status,
          responded_at: new Date().toISOString(),
          responded_by: user.id
        })
        .eq('id', requestId);

      if (error) throw error;

      if (status === 'approved') {
        const request = requests.find(r => r.id === requestId);
        if (request) {
          const { error: memberError } = await supabase
            .from('team_members')
            .insert({
              team_formation_id: request.team_formation_id,
              player_id: request.player_id,
              is_captain: false
            });

          if (memberError) throw memberError;
        }
      }

      toast({
        title: "Success",
        description: `Join request ${status} successfully!`
      });

      fetchRequests();
      return true;
    } catch (error: any) {
      console.error('Error responding to join request:', error);
      toast({
        title: "Error",
        description: "Failed to respond to join request",
        variant: "destructive"
      });
      return false;
    }
  };

  useEffect(() => {
    fetchRequests();
  }, [teamId, user?.id]);

  return {
    requests,
    loading,
    sendJoinRequest,
    respondToRequest,
    refetch: fetchRequests
  };
};
