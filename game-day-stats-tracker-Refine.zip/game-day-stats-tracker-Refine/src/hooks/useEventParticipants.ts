
import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/components/ui/use-toast';

interface EventParticipant {
  id: string;
  event_id: string;
  player_id: string;
  joined_at: string;
  position_played: string | null;
  status: 'joined' | 'pending' | 'declined' | 'waitlist';
  profile?: {
    full_name: string;
    email: string;
  };
}

export const useEventParticipants = (eventId: string) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [participants, setParticipants] = useState<EventParticipant[]>([]);
  const [loading, setLoading] = useState(false);
  const [isParticipating, setIsParticipating] = useState(false);

  const fetchParticipants = async () => {
    if (!eventId) {
      console.log('No eventId provided, skipping fetch');
      return;
    }

    console.log('Fetching participants for event:', eventId);
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('event_participants')
        .select(`
          *,
          profile:profiles(full_name, email)
        `)
        .eq('event_id', eventId)
        .eq('status', 'joined');

      if (error) {
        console.error('Supabase error:', error);
        throw error;
      }

      console.log('Successfully fetched participants:', data);

      // Type assertion to ensure status is properly typed
      const typedData = (data || []).map(participant => ({
        ...participant,
        status: participant.status as 'joined' | 'pending' | 'declined' | 'waitlist'
      }));

      setParticipants(typedData);
      
      if (user) {
        const userParticipation = typedData.find(p => p.player_id === user.id);
        setIsParticipating(!!userParticipation);
        console.log('User participation status:', !!userParticipation);
      }
    } catch (error: any) {
      console.error('Error fetching participants:', error);
      
      // Don't show toast for network errors during initial load
      if (error.message !== 'TypeError: Failed to fetch') {
        toast({
          title: "Error",
          description: "Failed to load participants",
          variant: "destructive"
        });
      }
      
      // Set empty array on error to prevent UI issues
      setParticipants([]);
      setIsParticipating(false);
    } finally {
      setLoading(false);
    }
  };

  const joinEvent = async () => {
    if (!user || !eventId) {
      console.log('Cannot join event: missing user or eventId');
      return false;
    }

    console.log('Joining event:', eventId);
    try {
      const { error } = await supabase
        .from('event_participants')
        .insert({
          event_id: eventId,
          player_id: user.id,
          status: 'joined'
        });

      if (error) throw error;

      toast({
        title: "Success",
        description: "You've joined the event!"
      });

      await fetchParticipants();
      return true;
    } catch (error: any) {
      console.error('Error joining event:', error);
      toast({
        title: "Error",
        description: "Failed to join event",
        variant: "destructive"
      });
      return false;
    }
  };

  const leaveEvent = async () => {
    if (!user || !eventId) {
      console.log('Cannot leave event: missing user or eventId');
      return false;
    }

    console.log('Leaving event:', eventId);
    try {
      const { error } = await supabase
        .from('event_participants')
        .delete()
        .eq('event_id', eventId)
        .eq('player_id', user.id);

      if (error) throw error;

      toast({
        title: "Success",
        description: "You've left the event"
      });

      await fetchParticipants();
      return true;
    } catch (error: any) {
      console.error('Error leaving event:', error);
      toast({
        title: "Error",
        description: "Failed to leave event",
        variant: "destructive"
      });
      return false;
    }
  };

  useEffect(() => {
    if (eventId && user) {
      fetchParticipants();
    }
  }, [eventId, user?.id]);

  return {
    participants,
    loading,
    isParticipating,
    joinEvent,
    leaveEvent,
    refetch: fetchParticipants
  };
};
