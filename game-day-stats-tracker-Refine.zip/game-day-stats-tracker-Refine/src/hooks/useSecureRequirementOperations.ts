
import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { validateAndSanitizeInput } from '@/utils/securityEnhancements';
import { enhancedRateLimit, logSecurityEvent } from '@/utils/securityEnhancements';

interface RequirementData {
  event_id: string;
  role_name: string;
  description?: string;
  experience_level?: string;
  max_players?: number;
}

interface Event {
  id: string;
  title: string;
  sport: string;
}

export const useSecureRequirementOperations = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({});
  const [events, setEvents] = useState<Event[]>([]);

  const validateRequirementData = (data: RequirementData): boolean => {
    const errors: Record<string, string> = {};

    // Role name validation
    const roleValidation = validateAndSanitizeInput(data.role_name, 100);
    if (!roleValidation.isValid) {
      errors.role_name = roleValidation.errors[0];
    }

    // Description validation
    if (data.description) {
      const descValidation = validateAndSanitizeInput(data.description, 2000);
      if (!descValidation.isValid) {
        errors.description = descValidation.errors[0];
      }
    }

    // Experience level validation
    if (data.experience_level) {
      const allowedLevels = ['beginner', 'intermediate', 'advanced', 'professional'];
      if (!allowedLevels.includes(data.experience_level)) {
        errors.experience_level = 'Invalid experience level';
      }
    }

    // Max players validation
    if (data.max_players && (data.max_players < 1 || data.max_players > 50)) {
      errors.max_players = 'Max players must be between 1 and 50';
    }

    // Event ID validation
    if (!data.event_id) {
      errors.event_id = 'Event selection is required';
    }

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const fetchUserEvents = useCallback(async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('events')
        .select('id, title, sport')
        .eq('organizer_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setEvents(data || []);
    } catch (error) {
      console.error('Error fetching events:', error);
      logSecurityEvent('Failed to fetch user events', { error }, 'medium');
      toast({
        title: "Error",
        description: "Failed to load your events",
        variant: "destructive"
      });
    }
  }, [user, toast]);

  const createRequirement = async (requirementData: RequirementData) => {
    if (!user) {
      logSecurityEvent('Unauthorized requirement creation attempt', {}, 'medium');
      toast({
        title: "Error",
        description: "You must be logged in to create requirements",
        variant: "destructive"
      });
      return false;
    }

    // Enhanced rate limiting
    if (!enhancedRateLimit(`requirement_create_${user.id}`, 10, 60 * 60 * 1000)) {
      logSecurityEvent('Rate limit exceeded for requirement creation', { userId: user.id }, 'medium');
      toast({
        title: "Rate Limit Exceeded",
        description: "Too many requirements created recently. Please wait before creating another.",
        variant: "destructive"
      });
      return false;
    }

    // Validation
    if (!validateRequirementData(requirementData)) {
      return false;
    }

    setLoading(true);
    try {
      // Verify user owns the event
      const { data: eventCheck, error: eventError } = await supabase
        .from('events')
        .select('id')
        .eq('id', requirementData.event_id)
        .eq('organizer_id', user.id)
        .single();

      if (eventError || !eventCheck) {
        logSecurityEvent('Unauthorized event access attempt', { eventId: requirementData.event_id }, 'high');
        toast({
          title: "Error",
          description: "You can only create requirements for your own events",
          variant: "destructive"
        });
        return false;
      }

      // Sanitize data
      const sanitizedData = {
        event_id: requirementData.event_id,
        role_name: validateAndSanitizeInput(requirementData.role_name, 100).sanitized,
        description: requirementData.description ? validateAndSanitizeInput(requirementData.description, 2000).sanitized : null,
        experience_level: requirementData.experience_level || null,
        max_players: requirementData.max_players || null,
        created_by: user.id
      };

      const { error } = await supabase
        .from('player_requirements')
        .insert(sanitizedData);

      if (error) throw error;

      logSecurityEvent('Requirement created successfully', { eventId: requirementData.event_id }, 'low');
      toast({
        title: "Success",
        description: "Player requirement created successfully!",
      });

      return true;
    } catch (error: any) {
      console.error('Error creating requirement:', error);
      logSecurityEvent('Requirement creation failed', { error: error.message }, 'medium');
      toast({
        title: "Error",
        description: "Failed to create player requirement",
        variant: "destructive"
      });
      return false;
    } finally {
      setLoading(false);
    }
  };

  return {
    createRequirement,
    fetchUserEvents,
    loading,
    validationErrors,
    events
  };
};
