import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';

interface MentorshipRelationship {
  id: string;
  mentor_id: string;
  mentee_id: string;
  sport: string | null;
  status: 'pending' | 'active' | 'completed' | 'cancelled';
  started_at: string | null;
  completed_at: string | null;
  mentor_rating: number | null;
  mentee_rating: number | null;
  feedback: string | null;
  goals: string[] | null;
  progress: any;
  created_at: string;
  mentor?: {
    full_name: string;
    email: string;
  };
  mentee?: {
    full_name: string;
    email: string;
  };
}

export const useMentorship = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [mentorships, setMentorships] = useState<MentorshipRelationship[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchMentorships = async () => {
    if (!user) return;

    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('mentorship_relationships')
        .select(`
          *,
          mentor:profiles!mentorship_relationships_mentor_id_fkey(full_name, email),
          mentee:profiles!mentorship_relationships_mentee_id_fkey(full_name, email)
        `)
        .or(`mentor_id.eq.${user.id},mentee_id.eq.${user.id}`)
        .order('created_at', { ascending: false });

      if (error) throw error;
      
      const formattedData = (data || []).map(item => ({
        ...item,
        mentor: Array.isArray(item.mentor) ? item.mentor[0] : item.mentor,
        mentee: Array.isArray(item.mentee) ? item.mentee[0] : item.mentee
      })) as MentorshipRelationship[];
      
      setMentorships(formattedData);
    } catch (error: any) {
      console.error('Error fetching mentorships:', error);
      toast({
        title: "Error",
        description: "Failed to load mentorship data",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const createMentorshipRequest = async (menteeId: string, sport?: string, goals?: string[]) => {
    if (!user) return false;

    try {
      const { error } = await supabase
        .from('mentorship_relationships')
        .insert({
          mentor_id: user.id,
          mentee_id: menteeId,
          sport,
          goals,
          status: 'pending'
        });

      if (error) throw error;

      toast({
        title: "Success",
        description: "Mentorship request sent successfully!"
      });

      fetchMentorships();
      return true;
    } catch (error: any) {
      console.error('Error creating mentorship request:', error);
      toast({
        title: "Error",
        description: "Failed to send mentorship request",
        variant: "destructive"
      });
      return false;
    }
  };

  const updateMentorshipStatus = async (id: string, status: 'active' | 'completed' | 'cancelled') => {
    try {
      const updateData: any = { status };
      
      if (status === 'active') {
        updateData.started_at = new Date().toISOString();
      } else if (status === 'completed') {
        updateData.completed_at = new Date().toISOString();
      }

      const { error } = await supabase
        .from('mentorship_relationships')
        .update(updateData)
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "Success",
        description: `Mentorship ${status} successfully!`
      });

      fetchMentorships();
    } catch (error: any) {
      console.error('Error updating mentorship status:', error);
      toast({
        title: "Error",
        description: "Failed to update mentorship status",
        variant: "destructive"
      });
    }
  };

  const updateProgress = async (id: string, progress: any) => {
    try {
      const { error } = await supabase
        .from('mentorship_relationships')
        .update({ progress })
        .eq('id', id);

      if (error) throw error;
      fetchMentorships();
    } catch (error: any) {
      console.error('Error updating progress:', error);
    }
  };

  useEffect(() => {
    fetchMentorships();
  }, [user?.id]);

  return {
    mentorships,
    loading,
    createMentorshipRequest: async (menteeId: string, sport?: string, goals?: string[]) => {
      if (!user) return false;
      try {
        const { error } = await supabase
          .from('mentorship_relationships')
          .insert({
            mentor_id: user.id,
            mentee_id: menteeId,
            sport,
            goals,
            status: 'pending'
          });
        if (error) throw error;
        toast({ title: "Success", description: "Mentorship request sent successfully!" });
        fetchMentorships();
        return true;
      } catch (error: any) {
        console.error('Error creating mentorship request:', error);
        toast({ title: "Error", description: "Failed to send mentorship request", variant: "destructive" });
        return false;
      }
    },
    updateMentorshipStatus: async (id: string, status: 'active' | 'completed' | 'cancelled') => {
      try {
        const updateData: any = { status };
        if (status === 'active') updateData.started_at = new Date().toISOString();
        else if (status === 'completed') updateData.completed_at = new Date().toISOString();
        
        const { error } = await supabase
          .from('mentorship_relationships')
          .update(updateData)
          .eq('id', id);
        if (error) throw error;
        toast({ title: "Success", description: `Mentorship ${status} successfully!` });
        fetchMentorships();
      } catch (error: any) {
        console.error('Error updating mentorship status:', error);
        toast({ title: "Error", description: "Failed to update mentorship status", variant: "destructive" });
      }
    },
    updateProgress: async (id: string, progress: any) => {
      try {
        const { error } = await supabase
          .from('mentorship_relationships')
          .update({ progress })
          .eq('id', id);
        if (error) throw error;
        fetchMentorships();
      } catch (error: any) {
        console.error('Error updating progress:', error);
      }
    },
    refetch: fetchMentorships
  };
};
