
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/AuthContext';

interface EventJoinRequest {
  id: string;
  event_id: string;
  player_id: string;
  message: string | null;
  status: 'pending' | 'approved' | 'rejected';
  requested_at: string;
  responded_at: string | null;
  responded_by: string | null;
  profile: {
    full_name: string;
    email: string;
  } | null;
}

export const useEventJoinRequests = (eventId?: string) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [requests, setRequests] = useState<EventJoinRequest[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchRequests = async () => {
    if (!user || !eventId) return;

    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('event_join_requests')
        .select(`
          *,
          profile:profiles!event_join_requests_player_id_fkey(full_name, email)
        `)
        .eq('event_id', eventId)
        .order('requested_at', { ascending: false });

      if (error) throw error;
      
      const typedRequests = (data || []).map(req => ({
        ...req,
        status: req.status as 'pending' | 'approved' | 'rejected',
        profile: req.profile && Array.isArray(req.profile) 
          ? req.profile[0] || null
          : req.profile || null
      }));
      
      setRequests(typedRequests);
    } catch (error: any) {
      console.error('Error fetching event join requests:', error);
      toast({
        title: "Error",
        description: "Failed to load event join requests",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const sendJoinRequest = async (eventId: string, message?: string) => {
    if (!user) return false;

    try {
      const { error } = await supabase
        .from('event_join_requests')
        .insert({
          event_id: eventId,
          player_id: user.id,
          message: message || null
        });

      if (error) throw error;

      toast({
        title: "Success",
        description: "Join request sent to event organizer!"
      });

      return true;
    } catch (error: any) {
      console.error('Error sending event join request:', error);
      toast({
        title: "Error",
        description: error.message.includes('duplicate') 
          ? "You have already requested to join this event"
          : "Failed to send join request",
        variant: "destructive"
      });
      return false;
    }
  };

  const respondToRequest = async (requestId: string, status: 'approved' | 'rejected') => {
    if (!user) return false;

    try {
      const { error } = await supabase
        .from('event_join_requests')
        .update({
          status,
          responded_at: new Date().toISOString(),
          responded_by: user.id
        })
        .eq('id', requestId);

      if (error) throw error;

      if (status === 'approved') {
        const request = requests.find(r => r.id === requestId);
        if (request) {
          const { error: participantError } = await supabase
            .from('event_participants')
            .insert({
              event_id: request.event_id,
              player_id: request.player_id
            });

          if (participantError) throw participantError;
        }
      }

      toast({
        title: "Success",
        description: `Join request ${status} successfully!`
      });

      fetchRequests();
      return true;
    } catch (error: any) {
      console.error('Error responding to join request:', error);
      toast({
        title: "Error",
        description: "Failed to respond to join request",
        variant: "destructive"
      });
      return false;
    }
  };

  useEffect(() => {
    fetchRequests();
  }, [eventId, user?.id]);

  return {
    requests,
    loading,
    sendJoinRequest,
    respondToRequest,
    refetch: fetchRequests
  };
};
