
import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/components/ui/use-toast';
import { validateEmail, validatePassword, validateProfileInput } from '@/utils/inputValidation';
import { sanitizeTextContent } from '@/utils/inputValidation';
import { logAuthenticationEvent, logSecurityEvent } from '@/utils/securityUtils';
import { enhancedRateLimit } from '@/utils/securityEnhancements';

export const useAuthSignUp = () => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);

  const signUp = async (email: string, password: string, confirmPassword: string, fullName: string) => {
    setLoading(true);
    
    try {
      // Enhanced rate limiting with IP tracking
      if (!enhancedRateLimit('signup', 3, 60 * 60 * 1000, true)) {
        logSecurityEvent('Rate limit exceeded for signup', { email: email.substring(0, 3) + '***' }, 'high');
        toast({
          title: "Too Many Attempts",
          description: "Please wait before trying to create another account.",
          variant: "destructive"
        });
        return { error: { message: 'Rate limit exceeded' } };
      }

      logAuthenticationEvent('signup_attempt', email);

      // Enhanced validation
      const emailValidation = validateEmail(email);
      if (!emailValidation.isValid) {
        toast({
          title: "Validation Error",
          description: emailValidation.errors[0],
          variant: "destructive"
        });
        return { error: { message: emailValidation.errors[0] } };
      }

      const passwordValidation = validatePassword(password);
      if (!passwordValidation.isValid) {
        toast({
          title: "Password Requirements",
          description: passwordValidation.errors[0],
          variant: "destructive"
        });
        return { error: { message: passwordValidation.errors[0] } };
      }

      // Password confirmation check
      if (password !== confirmPassword) {
        toast({
          title: "Validation Error",
          description: "Passwords do not match",
          variant: "destructive"
        });
        return { error: { message: 'Passwords do not match' } };
      }

      // Full name validation
      const profileValidation = validateProfileInput(fullName, '', '');
      if (!profileValidation.isValid) {
        toast({
          title: "Validation Error",
          description: profileValidation.errors[0],
          variant: "destructive"
        });
        return { error: { message: profileValidation.errors[0] } };
      }

      // Enhanced sanitization
      const sanitizedEmail = sanitizeTextContent(email.trim().toLowerCase());
      const sanitizedFullName = sanitizeTextContent(fullName.trim());
      
      // Additional security checks
      if (sanitizedEmail !== email.trim().toLowerCase()) {
        logSecurityEvent('Email sanitization triggered', { original: email.substring(0, 3) + '***' }, 'medium');
      }
      
      // Use consistent redirect URL - always point to auth page for verification
      const redirectUrl = `${window.location.origin}/auth`;
      
      console.log('Attempting signup with validated and sanitized data');
      
      const { data, error } = await supabase.auth.signUp({
        email: sanitizedEmail,
        password,
        options: {
          emailRedirectTo: redirectUrl,
          data: {
            full_name: sanitizedFullName
          }
        }
      });

      if (error) {
        console.error('Signup error:', error);
        logAuthenticationEvent('signup_failure', email);
        
        let errorMessage = 'Failed to create account. Please try again.';
        
        if (error.message.includes('User already registered')) {
          errorMessage = 'An account with this email already exists. Please sign in instead.';
          logSecurityEvent('Attempted signup with existing email', { email: email.substring(0, 3) + '***' }, 'low');
        } else if (error.message.includes('Invalid email')) {
          errorMessage = 'Please enter a valid email address.';
        } else if (error.message.includes('Password')) {
          errorMessage = 'Password does not meet security requirements.';
        } else if (error.message.includes('Signup is disabled')) {
          errorMessage = 'Account creation is temporarily disabled. Please try again later.';
          logSecurityEvent('Signup disabled when user attempted signup', {}, 'medium');
        }
        
        toast({
          title: "Signup Error",
          description: errorMessage,
          variant: "destructive"
        });
        return { error };
      }

      logAuthenticationEvent('signup_success', email);
      logSecurityEvent('New user account created', { email: email.substring(0, 3) + '***' }, 'low');

      toast({
        title: "Account Created",
        description: "Please check your email to verify your account before signing in.",
      });

      return { data, error: null };
    } catch (error: any) {
      console.error('Signup exception:', error);
      logAuthenticationEvent('signup_failure', email);
      logSecurityEvent('Signup exception occurred', { error: error.message }, 'high');
      
      toast({
        title: "Error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive"
      });
      return { error };
    } finally {
      setLoading(false);
    }
  };

  return { signUp, loading };
};
