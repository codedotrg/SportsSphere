
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface TeamChemistry {
  id: string;
  team_formation_id: string;
  player1_id: string;
  player2_id: string;
  chemistry_score: number;
  games_played_together: number;
  positive_interactions: number;
  negative_interactions: number;
  last_interaction_at: string | null;
}

export const useTeamChemistry = (teamId?: string) => {
  const { toast } = useToast();
  const [chemistryData, setChemistryData] = useState<TeamChemistry[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchTeamChemistry = async () => {
    if (!teamId) return;

    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('team_chemistry')
        .select('*')
        .eq('team_formation_id', teamId)
        .order('chemistry_score', { ascending: false });

      if (error) throw error;
      setChemistryData(data || []);
    } catch (error: any) {
      console.error('Error fetching team chemistry:', error);
      toast({
        title: "Error",
        description: "Failed to load team chemistry data",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const updateChemistry = async (player1Id: string, player2Id: string, type: 'positive' | 'negative') => {
    if (!teamId) return;

    try {
      const { data: existing } = await supabase
        .from('team_chemistry')
        .select('*')
        .eq('team_formation_id', teamId)
        .or(`and(player1_id.eq.${player1Id},player2_id.eq.${player2Id}),and(player1_id.eq.${player2Id},player2_id.eq.${player1Id})`)
        .single();

      if (existing) {
        const updateData = type === 'positive' 
          ? { positive_interactions: existing.positive_interactions + 1 }
          : { negative_interactions: existing.negative_interactions + 1 };

        await supabase
          .from('team_chemistry')
          .update({ 
            ...updateData,
            last_interaction_at: new Date().toISOString()
          })
          .eq('id', existing.id);
      } else {
        const insertData = {
          team_formation_id: teamId,
          player1_id: player1Id,
          player2_id: player2Id,
          positive_interactions: type === 'positive' ? 1 : 0,
          negative_interactions: type === 'negative' ? 1 : 0,
          last_interaction_at: new Date().toISOString()
        };

        await supabase
          .from('team_chemistry')
          .insert(insertData);
      }

      fetchTeamChemistry();
    } catch (error: any) {
      console.error('Error updating chemistry:', error);
    }
  };

  useEffect(() => {
    fetchTeamChemistry();
  }, [teamId]);

  return {
    chemistryData,
    loading,
    updateChemistry,
    refetch: fetchTeamChemistry
  };
};
