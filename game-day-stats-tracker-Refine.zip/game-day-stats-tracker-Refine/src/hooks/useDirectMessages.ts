
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';

interface DirectMessage {
  id: string;
  sender_id: string;
  recipient_id: string;
  content: string;
  is_read: boolean;
  created_at: string;
  sender?: {
    full_name: string;
    email: string;
  };
  recipient?: {
    full_name: string;
    email: string;
  };
}

interface Conversation {
  id: string;
  sender_id: string;
  recipient_id: string;
  content: string;
  is_read: boolean;
  created_at: string;
  otherUser?: {
    full_name: string;
    email: string;
  };
}

export const useDirectMessages = (folder: 'inbox' | 'sent') => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [messages, setMessages] = useState<DirectMessage[]>([]);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchMessages = async () => {
    if (!user) return;

    setLoading(true);
    try {
      let query = supabase
        .from('messages')
        .select(`
          id,
          sender_id,
          recipient_id,
          content,
          is_read,
          created_at,
          sender:profiles!messages_sender_id_fkey(full_name, email),
          recipient:profiles!messages_recipient_id_fkey(full_name, email)
        `)
        .eq('message_type', 'direct')
        .is('event_id', null)
        .order('created_at', { ascending: false });

      if (folder === 'inbox') {
        query = query.eq('recipient_id', user.id);
      } else {
        query = query.eq('sender_id', user.id);
      }

      const { data, error } = await query;

      if (error) throw error;
      
      const formattedMessages = (data || []).map(msg => ({
        ...msg,
        sender: Array.isArray(msg.sender) ? msg.sender[0] : msg.sender,
        recipient: Array.isArray(msg.recipient) ? msg.recipient[0] : msg.recipient
      }));

      // Create conversations with other user info
      const formattedConversations = formattedMessages.map(msg => ({
        ...msg,
        otherUser: folder === 'inbox' ? msg.sender : msg.recipient
      }));

      setMessages(formattedMessages);
      setConversations(formattedConversations);
    } catch (error: any) {
      console.error('Error fetching messages:', error);
      toast({
        title: "Error",
        description: "Failed to load messages",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const sendDirectMessage = async (recipientId: string, content: string) => {
    if (!user) return false;

    try {
      console.log('Sending direct message:', { 
        sender_id: user.id, 
        recipient_id: recipientId, 
        content,
        message_type: 'direct',
        event_id: null
      });

      const { error } = await supabase
        .from('messages')
        .insert({
          sender_id: user.id,
          recipient_id: recipientId,
          content,
          message_type: 'direct',
          event_id: null
        });

      if (error) throw error;

      toast({
        title: "Success",
        description: "Message sent successfully!"
      });

      fetchMessages();
      return true;
    } catch (error: any) {
      console.error('Error sending message:', error);
      toast({
        title: "Error",
        description: "Failed to send message",
        variant: "destructive"
      });
      return false;
    }
  };

  const markAsRead = async (messageId: string) => {
    if (!user) return;

    try {
      const { error } = await supabase
        .from('messages')
        .update({ is_read: true })
        .eq('id', messageId)
        .eq('recipient_id', user.id);

      if (error) throw error;
      fetchMessages();
    } catch (error: any) {
      console.error('Error marking message as read:', error);
    }
  };

  useEffect(() => {
    fetchMessages();
  }, [folder, user?.id]);

  return {
    messages,
    conversations,
    loading,
    sendDirectMessage,
    markAsRead,
    refetch: fetchMessages
  };
};
