import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';

interface PlayerSkill {
  id: string;
  player_id: string;
  sport: string;
  skill_type: 'technical' | 'tactical' | 'physical' | 'mental';
  skill_name: string;
  skill_level: number;
  verified_by: string | null;
  verified_at: string | null;
  created_at: string;
  verifier?: {
    full_name: string;
    email: string;
  };
}

interface PlayerEndorsement {
  id: string;
  endorser_id: string;
  endorsed_id: string;
  endorsement_type: 'skill' | 'teamwork' | 'leadership' | 'sportsmanship';
  skill_name: string | null;
  comment: string | null;
  strength_rating: number;
  created_at: string;
  endorser?: {
    full_name: string;
    email: string;
  };
}

export const usePlayerSkills = (playerId?: string) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [skills, setSkills] = useState<PlayerSkill[]>([]);
  const [endorsements, setEndorsements] = useState<PlayerEndorsement[]>([]);
  const [loading, setLoading] = useState(false);

  const targetPlayerId = playerId || user?.id;

  const fetchSkills = async () => {
    if (!targetPlayerId) return;

    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('player_skills')
        .select(`
          *,
          verifier:profiles!player_skills_verified_by_fkey(full_name, email)
        `)
        .eq('player_id', targetPlayerId)
        .order('skill_level', { ascending: false });

      if (error) throw error;
      
      const formattedData = (data || []).map(item => ({
        ...item,
        verifier: Array.isArray(item.verifier) ? item.verifier[0] : item.verifier
      })) as PlayerSkill[];
      
      setSkills(formattedData);
    } catch (error: any) {
      console.error('Error fetching skills:', error);
      toast({
        title: "Error",
        description: "Failed to load skills",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchEndorsements = async () => {
    if (!targetPlayerId) return;

    try {
      const { data, error } = await supabase
        .from('player_endorsements')
        .select(`
          *,
          endorser:profiles!player_endorsements_endorser_id_fkey(full_name, email)
        `)
        .eq('endorsed_id', targetPlayerId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      
      const formattedData = (data || []).map(item => ({
        ...item,
        endorser: Array.isArray(item.endorser) ? item.endorser[0] : item.endorser
      })) as PlayerEndorsement[];
      
      setEndorsements(formattedData);
    } catch (error: any) {
      console.error('Error fetching endorsements:', error);
    }
  };

  const addSkill = async (skillData: Omit<PlayerSkill, 'id' | 'player_id' | 'created_at' | 'verified_by' | 'verified_at'>) => {
    if (!user) return false;

    try {
      const { error } = await supabase
        .from('player_skills')
        .insert({
          ...skillData,
          player_id: user.id
        });

      if (error) throw error;

      toast({
        title: "Success",
        description: "Skill added successfully!"
      });

      fetchSkills();
      return true;
    } catch (error: any) {
      console.error('Error adding skill:', error);
      toast({
        title: "Error",
        description: "Failed to add skill",
        variant: "destructive"
      });
      return false;
    }
  };

  const verifySkill = async (skillId: string) => {
    if (!user) return false;

    try {
      const { error } = await supabase
        .from('player_skills')
        .update({
          verified_by: user.id,
          verified_at: new Date().toISOString()
        })
        .eq('id', skillId);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Skill verified successfully!"
      });

      fetchSkills();
      return true;
    } catch (error: any) {
      console.error('Error verifying skill:', error);
      toast({
        title: "Error",
        description: "Failed to verify skill",
        variant: "destructive"
      });
      return false;
    }
  };

  const createEndorsement = async (endorsementData: Omit<PlayerEndorsement, 'id' | 'endorser_id' | 'created_at'>) => {
    if (!user) return false;

    try {
      const { error } = await supabase
        .from('player_endorsements')
        .insert({
          ...endorsementData,
          endorser_id: user.id
        });

      if (error) throw error;

      toast({
        title: "Success",
        description: "Endorsement created successfully!"
      });

      fetchEndorsements();
      return true;
    } catch (error: any) {
      console.error('Error creating endorsement:', error);
      toast({
        title: "Error",
        description: "Failed to create endorsement",
        variant: "destructive"
      });
      return false;
    }
  };

  useEffect(() => {
    fetchSkills();
    fetchEndorsements();
  }, [targetPlayerId]);

  return {
    skills,
    endorsements,
    loading,
    addSkill,
    verifySkill,
    createEndorsement,
    refetch: () => {
      fetchSkills();
      fetchEndorsements();
    }
  };
};
