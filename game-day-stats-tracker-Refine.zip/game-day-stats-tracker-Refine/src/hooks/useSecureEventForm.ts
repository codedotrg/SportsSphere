
import { useState } from 'react';
import { useSecureEventOperations } from './useSecureEventOperations';
import { validateEventInput, sanitizeTextContent } from '@/utils/inputValidation';
import { useToast } from '@/components/ui/use-toast';

interface EventFormData {
  title: string;
  description: string;
  sport: string;
  location: string;
  event_date: string;
}

export const useSecureEventForm = () => {
  const { createEvent, loading } = useSecureEventOperations();
  const { toast } = useToast();
  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({});

  const validateForm = (data: EventFormData): boolean => {
    const errors: Record<string, string> = {};

    // Title validation
    if (!data.title.trim()) {
      errors.title = 'Title is required';
    } else if (data.title.length < 3) {
      errors.title = 'Title must be at least 3 characters long';
    } else if (data.title.length > 200) {
      errors.title = 'Title must be less than 200 characters';
    }

    // Description validation
    if (data.description && data.description.length > 2000) {
      errors.description = 'Description must be less than 2000 characters';
    }

    // Location validation
    if (data.location && data.location.length > 500) {
      errors.location = 'Location must be less than 500 characters';
    }

    // Sport validation
    if (data.sport && data.sport.length > 100) {
      errors.sport = 'Sport must be less than 100 characters';
    }

    // Date validation
    if (!data.event_date) {
      errors.event_date = 'Event date is required';
    } else {
      const eventDate = new Date(data.event_date);
      const now = new Date();
      if (eventDate <= now) {
        errors.event_date = 'Event date must be in the future';
      }
    }

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const sanitizeFormData = (data: EventFormData): EventFormData => {
    return {
      title: sanitizeTextContent(data.title.trim()),
      description: data.description ? sanitizeTextContent(data.description.trim()) : '',
      sport: data.sport ? sanitizeTextContent(data.sport.trim()) : '',
      location: data.location ? sanitizeTextContent(data.location.trim()) : '',
      event_date: data.event_date
    };
  };

  const submitForm = async (data: EventFormData) => {
    console.log('Validating event form data:', data);

    if (!validateForm(data)) {
      toast({
        title: "Validation Error",
        description: "Please fix the errors in the form before submitting",
        variant: "destructive"
      });
      return false;
    }

    const sanitizedData = sanitizeFormData(data);
    console.log('Submitting sanitized event data:', sanitizedData);

    const result = await createEvent({
      title: sanitizedData.title,
      description: sanitizedData.description || undefined,
      sport: sanitizedData.sport || undefined,
      location: sanitizedData.location || undefined,
      event_date: sanitizedData.event_date
    });

    if (result) {
      setValidationErrors({});
    }

    return result;
  };

  return {
    submitForm,
    validationErrors,
    loading
  };
};
