
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/components/ui/use-toast';

interface Player {
  id: string;
  full_name: string;
  email: string;
  location: string | null;
}

export const usePlayerSearch = (eventId?: string) => {
  const { toast } = useToast();
  const [players, setPlayers] = useState<Player[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const searchPlayers = async (term: string) => {
    if (!eventId || term.length < 2) {
      setPlayers([]);
      return;
    }

    setLoading(true);
    try {
      // First get event participants
      const { data: participantIds } = await supabase
        .from('event_participants')
        .select('player_id')
        .eq('event_id', eventId);

      if (!participantIds || participantIds.length === 0) {
        setPlayers([]);
        setLoading(false);
        return;
      }

      // Then get team members to exclude them
      const { data: teamMemberIds } = await supabase
        .from('team_members')
        .select('player_id, team_formation_id')
        .in('team_formation_id', 
          await supabase
            .from('team_formations')
            .select('id')
            .eq('event_id', eventId)
            .then(res => res.data?.map(t => t.id) || [])
        );

      const excludeIds = teamMemberIds?.map(tm => tm.player_id) || [];

      // Search for players who are participants but not in teams
      const availableParticipantIds = participantIds
        .map(p => p.player_id)
        .filter(id => !excludeIds.includes(id));

      if (availableParticipantIds.length === 0) {
        setPlayers([]);
        setLoading(false);
        return;
      }

      const { data, error } = await supabase
        .from('profiles')
        .select('id, full_name, email, location')
        .or(`full_name.ilike.%${term}%,email.ilike.%${term}%`)
        .in('id', availableParticipantIds)
        .limit(10);

      if (error) throw error;
      setPlayers(data || []);
    } catch (error: any) {
      console.error('Error searching players:', error);
      toast({
        title: "Error",
        description: "Failed to search players",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const timeoutId = setTimeout(() => {
      searchPlayers(searchTerm);
    }, 300);

    return () => clearTimeout(timeoutId);
  }, [searchTerm, eventId]);

  return {
    players,
    loading,
    searchTerm,
    setSearchTerm
  };
};
