
import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';

interface SearchResults {
  events: any[];
  users: any[];
  teams: any[];
}

export const useGlobalSearch = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [results, setResults] = useState<SearchResults>({
    events: [],
    users: [],
    teams: []
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const searchAll = useCallback(async (query: string) => {
    if (query.length < 2) {
      setResults({ events: [], users: [], teams: [] });
      setError(null);
      return;
    }

    setLoading(true);
    setError(null);
    
    try {
      console.log('Starting search for:', query);

      // Search events with better error handling
      const { data: events, error: eventsError } = await supabase
        .from('events')
        .select('id, title, description, location, sport, event_date, organizer_id')
        .or(`title.ilike.%${query}%,description.ilike.%${query}%,location.ilike.%${query}%,sport.ilike.%${query}%`)
        .limit(10)
        .order('created_at', { ascending: false });

      if (eventsError) {
        console.error('Events search error:', eventsError);
        throw new Error('Failed to search events');
      }

      // Search users with better error handling
      const { data: users, error: usersError } = await supabase
        .from('profiles')
        .select('id, full_name, email, location, profile_picture')
        .or(`full_name.ilike.%${query}%,email.ilike.%${query}%,location.ilike.%${query}%`)
        .neq('id', user?.id || '')
        .limit(10)
        .order('created_at', { ascending: false });

      if (usersError) {
        console.error('Users search error:', usersError);
        throw new Error('Failed to search users');
      }

      // Search teams with better error handling
      const { data: teams, error: teamsError } = await supabase
        .from('team_formations')
        .select('id, team_name, description, max_members, created_at')
        .or(`team_name.ilike.%${query}%,description.ilike.%${query}%`)
        .limit(10)
        .order('created_at', { ascending: false });

      if (teamsError) {
        console.error('Teams search error:', teamsError);
        throw new Error('Failed to search teams');
      }

      console.log('Search results:', { events: events?.length, users: users?.length, teams: teams?.length });

      setResults({
        events: events || [],
        users: users || [],
        teams: teams || []
      });
    } catch (error: any) {
      console.error('Search error:', error);
      const errorMessage = error.message || 'Search failed. Please try again.';
      setError(errorMessage);
      
      toast({
        title: "Search Error",
        description: errorMessage,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  }, [user?.id, toast]);

  const clearSearch = useCallback(() => {
    setResults({ events: [], users: [], teams: [] });
    setError(null);
  }, []);

  return {
    results,
    loading,
    error,
    searchAll,
    clearSearch
  };
};
