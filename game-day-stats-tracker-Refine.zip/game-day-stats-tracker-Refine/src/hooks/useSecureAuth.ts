
import { useAuthSignUp } from './useAuthSignUp';
import { useAuthSignIn } from './useAuthSignIn';
import { enhancedRateLimit, logSecurityEvent } from '@/utils/securityEnhancements';

export const useSecureAuth = () => {
  const { signUp, loading: signUpLoading } = useAuthSignUp();
  const { signIn, loading: signInLoading } = useAuthSignIn();

  // Enhanced signup with additional security checks
  const secureSignUp = async (
    email: string, 
    password: string, 
    confirmPassword: string, 
    fullName: string
  ) => {
    // Enhanced rate limiting with IP tracking
    if (!enhancedRateLimit('signup', 3, 60 * 60 * 1000, true)) {
      logSecurityEvent('Rate limit exceeded for signup', { email: email.substring(0, 3) + '***' }, 'high');
      throw new Error('Too many signup attempts. Please try again later.');
    }

    return signUp(email, password, confirmPassword, fullName);
  };

  // Enhanced signin with additional security checks
  const secureSignIn = async (email: string, password: string) => {
    // Enhanced rate limiting with IP tracking
    if (!enhancedRateLimit('signin', 5, 15 * 60 * 1000, true)) {
      logSecurityEvent('Rate limit exceeded for signin', { email: email.substring(0, 3) + '***' }, 'high');
      throw new Error('Too many signin attempts. Please try again later.');
    }

    return signIn(email, password);
  };

  return {
    signUp: secureSignUp,
    signIn: secureSignIn,
    loading: signUpLoading || signInLoading
  };
};
