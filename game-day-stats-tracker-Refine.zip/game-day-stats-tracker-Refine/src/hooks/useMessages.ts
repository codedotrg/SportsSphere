
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';

interface Message {
  id: string;
  event_id: string;
  sender_id: string;
  recipient_id: string | null;
  message_type: 'general' | 'team_request' | 'join_request';
  content: string;
  team_formation_id: string | null;
  is_read: boolean;
  created_at: string;
  updated_at: string;
  sender?: {
    full_name: string;
    email: string;
  };
  recipient?: {
    full_name: string;
    email: string;
  };
}

export const useMessages = (eventId?: string) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchMessages = async () => {
    if (!user || !eventId) return;

    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('messages')
        .select(`
          *,
          sender:profiles!messages_sender_id_fkey(full_name, email),
          recipient:profiles!messages_recipient_id_fkey(full_name, email)
        `)
        .eq('event_id', eventId)
        .order('created_at', { ascending: true });

      if (error) throw error;
      
      // Type cast the data to ensure proper typing
      const typedMessages = (data || []).map(msg => ({
        ...msg,
        message_type: msg.message_type as 'general' | 'team_request' | 'join_request'
      }));
      
      setMessages(typedMessages);
    } catch (error: any) {
      console.error('Error fetching messages:', error);
      toast({
        title: "Error",
        description: "Failed to load messages",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const sendMessage = async (
    content: string,
    recipientId?: string,
    messageType: 'general' | 'team_request' | 'join_request' = 'general',
    teamFormationId?: string
  ) => {
    if (!user || !eventId) return false;

    try {
      const { error } = await supabase
        .from('messages')
        .insert({
          event_id: eventId,
          sender_id: user.id,
          recipient_id: recipientId || null,
          message_type: messageType,
          content,
          team_formation_id: teamFormationId || null
        });

      if (error) throw error;

      toast({
        title: "Success",
        description: "Message sent successfully!"
      });

      fetchMessages();
      return true;
    } catch (error: any) {
      console.error('Error sending message:', error);
      toast({
        title: "Error",
        description: "Failed to send message",
        variant: "destructive"
      });
      return false;
    }
  };

  const markAsRead = async (messageId: string) => {
    if (!user) return;

    try {
      const { error } = await supabase
        .from('messages')
        .update({ is_read: true })
        .eq('id', messageId)
        .eq('recipient_id', user.id);

      if (error) throw error;
      fetchMessages();
    } catch (error: any) {
      console.error('Error marking message as read:', error);
    }
  };

  useEffect(() => {
    fetchMessages();
  }, [eventId, user?.id]);

  return {
    messages,
    loading,
    sendMessage,
    markAsRead,
    refetch: fetchMessages
  };
};
