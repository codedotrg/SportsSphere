
import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { validateEventData } from '@/utils/enhancedInputValidation';
import { enhancedRateLimit, logSecurityEvent } from '@/utils/securityEnhancements';

interface EventData {
  title: string;
  description?: string;
  sport?: string;
  location?: string;
  event_date: string;
}

export const useSecureEventOperations = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);

  const createEvent = async (eventData: EventData) => {
    if (!user) {
      logSecurityEvent('Unauthorized event creation attempt', {}, 'medium');
      toast({
        title: "Error",
        description: "You must be logged in to create events",
        variant: "destructive"
      });
      return false;
    }

    // Enhanced rate limiting
    if (!enhancedRateLimit(`event_create_${user.id}`, 5, 60 * 60 * 1000)) {
      logSecurityEvent('Rate limit exceeded for event creation', { userId: user.id }, 'medium');
      toast({
        title: "Rate Limit Exceeded",
        description: "Too many events created recently. Please wait before creating another.",
        variant: "destructive"
      });
      return false;
    }

    // Enhanced validation
    const validation = validateEventData(eventData);
    if (!validation.isValid) {
      logSecurityEvent('Invalid event data submitted', { errors: validation.errors }, 'low');
      toast({
        title: "Validation Error",
        description: validation.errors[0],
        variant: "destructive"
      });
      return false;
    }

    setLoading(true);
    try {
      const sanitizedData = {
        ...validation.sanitizedData,
        organizer_id: user.id
      };

      console.log('Creating event with validated and sanitized data:', sanitizedData);

      const { data, error } = await supabase
        .from('events')
        .insert(sanitizedData)
        .select()
        .single();

      if (error) {
        console.error('Error creating event:', error);
        logSecurityEvent('Event creation failed', { error: error.message }, 'medium');
        throw error;
      }

      logSecurityEvent('Event created successfully', { eventId: data.id }, 'low');
      toast({
        title: "Success",
        description: "Event created successfully"
      });

      return data;
    } catch (error: any) {
      console.error('Error creating event:', error);
      logSecurityEvent('Event creation exception', { error: error.message }, 'high');
      toast({
        title: "Error",
        description: "Failed to create event. Please try again.",
        variant: "destructive"
      });
      return false;
    } finally {
      setLoading(false);
    }
  };

  const updateEvent = async (eventId: string, eventData: Partial<EventData>) => {
    if (!user) {
      logSecurityEvent('Unauthorized event update attempt', { eventId }, 'medium');
      toast({
        title: "Error",
        description: "You must be logged in to update events",
        variant: "destructive"
      });
      return false;
    }

    // Validate partial event data
    if (Object.keys(eventData).length > 0) {
      const fullData = {
        title: eventData.title || 'Valid Title',
        description: eventData.description,
        sport: eventData.sport,
        location: eventData.location,
        event_date: eventData.event_date || new Date().toISOString()
      };

      const validation = validateEventData(fullData);
      
      // Only validate fields that were provided
      const relevantErrors = validation.errors.filter(error => {
        if (eventData.title && error.includes('title')) return true;
        if (eventData.description && error.includes('Description')) return true;
        if (eventData.location && error.includes('Location')) return true;
        if (eventData.sport && error.includes('Sport')) return true;
        if (eventData.event_date && error.includes('date')) return true;
        return false;
      });

      if (relevantErrors.length > 0) {
        logSecurityEvent('Invalid event update data', { errors: relevantErrors }, 'low');
        toast({
          title: "Validation Error",
          description: relevantErrors[0],
          variant: "destructive"
        });
        return false;
      }
    }

    setLoading(true);
    try {
      // Build sanitized update data
      const sanitizedData: any = {};
      if (eventData.title) {
        const validation = validateEventData({ ...eventData, title: eventData.title, event_date: new Date().toISOString() });
        sanitizedData.title = validation.sanitizedData.title;
      }
      if (eventData.description) sanitizedData.description = eventData.description;
      if (eventData.sport) sanitizedData.sport = eventData.sport;
      if (eventData.location) sanitizedData.location = eventData.location;
      if (eventData.event_date) sanitizedData.event_date = eventData.event_date;

      console.log('Updating event with validated and sanitized data:', sanitizedData);

      const { data, error } = await supabase
        .from('events')
        .update(sanitizedData)
        .eq('id', eventId)
        .eq('organizer_id', user.id)
        .select()
        .single();

      if (error) {
        console.error('Error updating event:', error);
        logSecurityEvent('Event update failed', { error: error.message, eventId }, 'medium');
        throw error;
      }

      logSecurityEvent('Event updated successfully', { eventId }, 'low');
      toast({
        title: "Success",
        description: "Event updated successfully"
      });

      return data;
    } catch (error: any) {
      console.error('Error updating event:', error);
      logSecurityEvent('Event update exception', { error: error.message, eventId }, 'high');
      toast({
        title: "Error",
        description: "Failed to update event. Please try again.",
        variant: "destructive"
      });
      return false;
    } finally {
      setLoading(false);
    }
  };

  const deleteEvent = async (eventId: string) => {
    if (!user) {
      logSecurityEvent('Unauthorized event deletion attempt', { eventId }, 'high');
      toast({
        title: "Error",
        description: "You must be logged in to delete events",
        variant: "destructive"
      });
      return false;
    }

    setLoading(true);
    try {
      console.log('Deleting event:', eventId);

      const { error } = await supabase
        .from('events')
        .delete()
        .eq('id', eventId)
        .eq('organizer_id', user.id);

      if (error) {
        console.error('Error deleting event:', error);
        logSecurityEvent('Event deletion failed', { error: error.message, eventId }, 'medium');
        throw error;
      }

      logSecurityEvent('Event deleted successfully', { eventId }, 'low');
      toast({
        title: "Success",
        description: "Event deleted successfully"
      });

      return true;
    } catch (error: any) {
      console.error('Error deleting event:', error);
      logSecurityEvent('Event deletion exception', { error: error.message, eventId }, 'high');
      toast({
        title: "Error",
        description: "Failed to delete event. Please try again.",
        variant: "destructive"
      });
      return false;
    } finally {
      setLoading(false);
    }
  };

  return {
    createEvent,
    updateEvent,
    deleteEvent,
    loading
  };
};
