
import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/components/ui/use-toast';
import { validateEmail, validatePassword, checkRateLimit } from '@/utils/inputValidation';
import { sanitizeTextContent } from '@/utils/inputValidation';
import { logAuthenticationEvent, logSecurityEvent } from '@/utils/securityUtils';

export const useAuthSignIn = () => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);

  const signIn = async (email: string, password: string) => {
    setLoading(true);
    
    try {
      // Rate limiting check
      if (!checkRateLimit('signin', 5, 15 * 60 * 1000)) { // 5 attempts per 15 minutes
        logSecurityEvent('Rate limit exceeded for signin', { email: email.substring(0, 3) + '***' }, 'high');
        toast({
          title: "Too Many Attempts",
          description: "Please wait before trying again.",
          variant: "destructive"
        });
        return { error: { message: 'Rate limit exceeded' } };
      }

      logAuthenticationEvent('login_attempt', email);

      // Enhanced validation
      const emailValidation = validateEmail(email);
      if (!emailValidation.isValid) {
        toast({
          title: "Validation Error",
          description: emailValidation.errors[0],
          variant: "destructive"
        });
        return { error: { message: emailValidation.errors[0] } };
      }

      const passwordValidation = validatePassword(password);
      if (!passwordValidation.isValid) {
        toast({
          title: "Validation Error", 
          description: "Please check your password and try again.",
          variant: "destructive"
        });
        return { error: { message: 'Invalid password format' } };
      }

      // Sanitize input data
      const sanitizedEmail = sanitizeTextContent(email.trim().toLowerCase());
      
      console.log('Attempting signin with validated credentials');
      
      const { data, error } = await supabase.auth.signInWithPassword({
        email: sanitizedEmail,
        password
      });

      if (error) {
        console.error('Signin error:', error);
        logAuthenticationEvent('login_failure', email);
        
        let errorMessage = 'Invalid email or password. Please try again.';
        
        if (error.message.includes('Email not confirmed')) {
          errorMessage = 'Please check your email and click the verification link before signing in.';
        } else if (error.message.includes('Invalid login credentials')) {
          errorMessage = 'Invalid email or password. Please check your credentials and try again.';
        } else if (error.message.includes('Too many requests')) {
          errorMessage = 'Too many sign in attempts. Please wait before trying again.';
          logSecurityEvent('Multiple failed login attempts', { email: email.substring(0, 3) + '***' }, 'high');
        }
        
        toast({
          title: "Sign In Error",
          description: errorMessage,
          variant: "destructive"
        });
        return { error };
      }

      logAuthenticationEvent('login_success', email);
      
      toast({
        title: "Welcome back!",
        description: "You have successfully signed in.",
      });

      return { data, error: null };
    } catch (error: any) {
      console.error('Signin exception:', error);
      logAuthenticationEvent('login_failure', email);
      logSecurityEvent('Signin exception occurred', { error: error.message }, 'high');
      
      toast({
        title: "Error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive"
      });
      return { error };
    } finally {
      setLoading(false);
    }
  };

  return { signIn, loading };
};
