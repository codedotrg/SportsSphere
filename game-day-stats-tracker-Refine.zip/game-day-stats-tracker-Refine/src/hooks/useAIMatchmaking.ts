
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';

interface AIMatchmakingPreferences {
  id?: string;
  user_id: string;
  preferred_skill_level?: string;
  preferred_age_range?: string;
  max_distance_km: number;
  preferred_play_times: string[];
  ai_personality_match: boolean;
  preferred_sports: string[];
  avoid_users: string[];
}

interface MatchedPlayer {
  id: string;
  full_name: string;
  email: string;
  location?: string;
  compatibility_score: number;
  common_interests: string[];
  distance_km?: number;
}

export const useAIMatchmaking = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [preferences, setPreferences] = useState<AIMatchmakingPreferences | null>(null);
  const [matches, setMatches] = useState<MatchedPlayer[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchPreferences = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('ai_matchmaking_preferences')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (error && error.code !== 'PGRST116') {
        console.error('Error fetching AI preferences:', error);
        return;
      }

      if (data) {
        setPreferences(data as AIMatchmakingPreferences);
      }
    } catch (error: any) {
      console.error('Error fetching AI preferences:', error);
    }
  };

  const savePreferences = async (prefs: Partial<AIMatchmakingPreferences>) => {
    if (!user) return false;

    try {
      const { error } = await supabase
        .from('ai_matchmaking_preferences')
        .upsert({
          user_id: user.id,
          ...prefs
        }, {
          onConflict: 'user_id'
        });

      if (error) throw error;

      toast({
        title: "Preferences saved",
        description: "Your AI matchmaking preferences have been updated"
      });

      fetchPreferences();
      return true;
    } catch (error: any) {
      console.error('Error saving preferences:', error);
      toast({
        title: "Error",
        description: "Failed to save preferences",
        variant: "destructive"
      });
      return false;
    }
  };

  const findMatches = async () => {
    if (!user) return;

    setLoading(true);
    try {
      // Get all users except current user
      const { data: users, error } = await supabase
        .from('profiles')
        .select('id, full_name, email, location')
        .neq('id', user.id)
        .limit(20);

      if (error) throw error;

      // Simple AI-like scoring algorithm
      const scoredMatches = users?.map(matchUser => {
        let score = 50; // Base score

        // Location proximity boost
        if (matchUser.location && user.user_metadata?.location) {
          score += 20;
        }

        // Random personality compatibility (in real app, this would use ML)
        score += Math.random() * 30;

        // Common interests simulation
        const commonInterests = ['Football', 'Basketball'];

        return {
          ...matchUser,
          compatibility_score: Math.min(100, Math.max(0, Math.round(score))),
          common_interests: commonInterests,
          distance_km: Math.round(Math.random() * 50) + 1
        };
      }) || [];

      // Sort by compatibility score
      const sortedMatches = scoredMatches
        .filter(match => match.compatibility_score >= 60)
        .sort((a, b) => b.compatibility_score - a.compatibility_score)
        .slice(0, 10);

      setMatches(sortedMatches);
    } catch (error: any) {
      console.error('Error finding matches:', error);
      toast({
        title: "Error",
        description: "Failed to find matches",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user) {
      // Set default preferences if none exist
      setPreferences({
        user_id: user.id,
        max_distance_km: 50,
        preferred_play_times: [],
        ai_personality_match: true,
        preferred_sports: [],
        avoid_users: []
      });
    }
  }, [user?.id]);

  return {
    preferences,
    matches,
    loading,
    savePreferences,
    findMatches,
    refetch: fetchPreferences
  };
};
