
import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/components/ui/use-toast';

interface Team {
  id: string;
  team_name: string;
  description: string | null;
  max_members: number;
  created_by: string;
  members: {
    id: string;
    player_id: string;
    is_captain: boolean;
    profile?: {
      full_name: string;
      email: string;
    };
  }[];
}

interface NewTeam {
  team_name: string;
  description: string;
  max_members: number;
}

export const useTeamFormation = (eventId: string) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [teams, setTeams] = useState<Team[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchTeams = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('team_formations')
        .select(`
          *,
          members:team_members(
            id,
            player_id,
            is_captain,
            profile:profiles(full_name, email)
          )
        `)
        .eq('event_id', eventId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      
      const typedTeams = (data || []).map(team => ({
        ...team,
        description: team.description || null,
        max_members: team.max_members || 5
      })) as Team[];
      
      setTeams(typedTeams);
    } catch (error: any) {
      console.error('Error fetching teams:', error);
      toast({
        title: "Error",
        description: "Failed to load teams",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const createTeam = async (newTeam: NewTeam) => {
    if (!user || !newTeam.team_name.trim()) return false;

    try {
      const { data: teamData, error: teamError } = await supabase
        .from('team_formations')
        .insert({
          event_id: eventId,
          team_name: newTeam.team_name,
          description: newTeam.description || null,
          max_members: newTeam.max_members,
          created_by: user.id
        })
        .select()
        .single();

      if (teamError) throw teamError;

      const { error: memberError } = await supabase
        .from('team_members')
        .insert({
          team_formation_id: teamData.id,
          player_id: user.id,
          is_captain: true
        });

      if (memberError) throw memberError;

      toast({
        title: "Success",
        description: "Team created successfully!"
      });

      fetchTeams();
      return true;
    } catch (error: any) {
      console.error('Error creating team:', error);
      toast({
        title: "Error",
        description: "Failed to create team",
        variant: "destructive"
      });
      return false;
    }
  };

  const addPlayerToTeam = async (teamId: string, playerId: string) => {
    try {
      // Check if player is already in any team for this event
      const { data: existingMember, error: checkError } = await supabase
        .from('team_members')
        .select('id, team_formation_id')
        .eq('player_id', playerId)
        .in('team_formation_id', teams.map(t => t.id))
        .maybeSingle();

      if (checkError) throw checkError;

      if (existingMember) {
        toast({
          title: "Error",
          description: "Player is already in a team for this event",
          variant: "destructive"
        });
        return;
      }

      // Check if team has reached max capacity
      const team = teams.find(t => t.id === teamId);
      if (team && team.members.length >= team.max_members) {
        toast({
          title: "Error",
          description: "Team has reached maximum capacity",
          variant: "destructive"
        });
        return;
      }

      const { error } = await supabase
        .from('team_members')
        .insert({
          team_formation_id: teamId,
          player_id: playerId,
          is_captain: false
        });

      if (error) throw error;

      toast({
        title: "Success",
        description: "Player added to team successfully!"
      });

      fetchTeams();
    } catch (error: any) {
      console.error('Error adding player to team:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to add player to team",
        variant: "destructive"
      });
    }
  };

  const isUserInAnyTeam = () => {
    return teams.some(team => 
      team.members.some(member => member.player_id === user?.id)
    );
  };

  const isTeamCreator = (team: Team) => {
    return user?.id === team.created_by;
  };

  const canManageTeam = (team: Team, isOrganizer: boolean) => {
    return isOrganizer || isTeamCreator(team) || 
           team.members.some(m => m.player_id === user?.id && m.is_captain);
  };

  return {
    teams,
    loading,
    fetchTeams,
    createTeam,
    addPlayerToTeam,
    isUserInAnyTeam,
    isTeamCreator,
    canManageTeam
  };
};
