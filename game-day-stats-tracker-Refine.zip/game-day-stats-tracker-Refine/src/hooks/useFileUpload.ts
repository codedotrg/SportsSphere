
import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';

interface UploadResult {
  success: boolean;
  filePaths: string[];
  error?: string;
}

export const useFileUpload = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [uploading, setUploading] = useState(false);

  const uploadFiles = async (files: File[], folder: string = 'message-attachments'): Promise<UploadResult> => {
    if (!user) {
      return { success: false, filePaths: [], error: 'User not authenticated' };
    }

    setUploading(true);
    const filePaths: string[] = [];

    try {
      for (const file of files) {
        const fileExt = file.name.split('.').pop();
        const fileName = `${user.id}/${Date.now()}-${Math.random().toString(36).substring(2)}.${fileExt}`;
        
        const { data, error } = await supabase.storage
          .from(folder)
          .upload(fileName, file);

        if (error) {
          console.error('Upload error:', error);
          throw new Error(`Failed to upload ${file.name}: ${error.message}`);
        }

        if (data) {
          filePaths.push(data.path);
        }
      }

      return { success: true, filePaths };
    } catch (error: any) {
      console.error('File upload error:', error);
      toast({
        title: "Upload failed",
        description: error.message || "Failed to upload files",
        variant: "destructive"
      });
      return { success: false, filePaths: [], error: error.message };
    } finally {
      setUploading(false);
    }
  };

  const getFileUrl = async (path: string, folder: string = 'message-attachments'): Promise<string | null> => {
    try {
      const { data } = await supabase.storage
        .from(folder)
        .createSignedUrl(path, 3600); // 1 hour expiry

      return data?.signedUrl || null;
    } catch (error) {
      console.error('Error getting file URL:', error);
      return null;
    }
  };

  return {
    uploadFiles,
    getFileUrl,
    uploading
  };
};
