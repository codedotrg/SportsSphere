
import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/components/ui/use-toast';

interface Profile {
  full_name: string;
  email: string;
  date_of_birth: string;
  location: string;
  zip_code: string;
  gender: string;
  profile_picture?: string;
}

export const useProfile = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [fetchError, setFetchError] = useState<string | null>(null);
  const [profile, setProfile] = useState<Profile>({
    full_name: '',
    email: '',
    date_of_birth: '',
    location: '',
    zip_code: '',
    gender: '',
    profile_picture: ''
  });

  const fetchProfile = async () => {
    if (!user?.id) {
      console.log('No user ID available for profile fetch');
      return;
    }

    setLoading(true);
    setFetchError(null);
    
    try {
      console.log('Fetching profile for user:', user.id);
      
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .maybeSingle();

      if (error) {
        console.error('Supabase error:', error);
        throw error;
      }

      console.log('Fetched profile data:', data);

      if (data) {
        setProfile({
          full_name: data.full_name || '',
          email: data.email || user.email || '',
          date_of_birth: data.date_of_birth || '',
          location: data.location || '',
          zip_code: data.zip_code || '',
          gender: data.gender || '',
          profile_picture: data.profile_picture || ''
        });
      } else {
        console.log('No profile found, using default values');
        setProfile({
          full_name: user.user_metadata?.full_name || '',
          email: user.email || '',
          date_of_birth: '',
          location: '',
          zip_code: '',
          gender: '',
          profile_picture: ''
        });
      }
    } catch (error: any) {
      console.error('Error fetching profile:', error);
      setFetchError('Failed to load profile data. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user?.id) {
      fetchProfile();
    }
  }, [user?.id]);

  const saveProfile = async (profileData: Profile) => {
    if (!user?.id) return false;

    setLoading(true);
    try {
      console.log('Saving profile:', profileData);
      
      const { error } = await supabase
        .from('profiles')
        .upsert({
          id: user.id,
          full_name: profileData.full_name,
          email: profileData.email,
          date_of_birth: profileData.date_of_birth || null,
          location: profileData.location,
          zip_code: profileData.zip_code,
          gender: profileData.gender,
          profile_picture: profileData.profile_picture,
          updated_at: new Date().toISOString()
        });

      if (error) {
        console.error('Error saving profile:', error);
        throw error;
      }

      toast({
        title: "Success",
        description: "Profile updated successfully"
      });
      return true;
    } catch (error: any) {
      console.error('Error updating profile:', error);
      toast({
        title: "Error",
        description: "Failed to update profile",
        variant: "destructive"
      });
      return false;
    } finally {
      setLoading(false);
    }
  };

  const calculateAge = (dateOfBirth: string) => {
    if (!dateOfBirth) return '';
    const today = new Date();
    const birthDate = new Date(dateOfBirth);
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    
    return age.toString();
  };

  const getMemberSince = () => {
    if (!user?.created_at) return '';
    try {
      return new Date(user.created_at).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      });
    } catch {
      return '';
    }
  };

  return {
    profile,
    setProfile,
    loading,
    fetchError,
    fetchProfile,
    saveProfile,
    calculateAge,
    getMemberSince
  };
};
