import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { validateProfileData } from '@/utils/enhancedInputValidation';
import { enhancedRateLimit, logSecurityEvent } from '@/utils/securityEnhancements';

interface Profile {
  full_name: string;
  email: string;
  date_of_birth: string;
  location: string;
  zip_code: string;
  gender: string;
  profile_picture?: string;
  average_rating?: number;
  total_ratings?: number;
}

export const useSecureProfile = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [fetchError, setFetchError] = useState<string | null>(null);
  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({});
  const [profile, setProfile] = useState<Profile>({
    full_name: '',
    email: '',
    date_of_birth: '',
    location: '',
    zip_code: '',
    gender: '',
    profile_picture: '',
    average_rating: 0,
    total_ratings: 0
  });

  const fetchProfile = async () => {
    if (!user?.id) {
      console.log('No user ID available for profile fetch');
      return;
    }

    setLoading(true);
    setFetchError(null);
    
    try {
      console.log('Fetching profile for user:', user.id);
      
      const { data, error } = await supabase
        .from('profiles')
        .select(`
          *,
          player_ratings_rated_player_id_fkey!inner(rating)
        `)
        .eq('id', user.id)
        .maybeSingle();

      if (error) {
        console.error('Supabase error:', error);
        throw error;
      }

      console.log('Fetched profile data:', data);

      if (data) {
        // Calculate average rating if ratings exist
        const ratings = data.player_ratings_rated_player_id_fkey || [];
        const totalRatings = ratings.length;
        const averageRating = totalRatings > 0 
          ? ratings.reduce((sum: number, r: any) => sum + r.rating, 0) / totalRatings 
          : 0;

        setProfile({
          full_name: data.full_name || '',
          email: data.email || user.email || '',
          date_of_birth: data.date_of_birth || '',
          location: data.location || '',
          zip_code: data.zip_code || '',
          gender: data.gender || '',
          profile_picture: data.profile_picture || '',
          average_rating: averageRating,
          total_ratings: totalRatings
        });
      } else {
        console.log('No profile found, using default values');
        setProfile({
          full_name: user.user_metadata?.full_name || '',
          email: user.email || '',
          date_of_birth: '',
          location: '',
          zip_code: '',
          gender: '',
          profile_picture: '',
          average_rating: 0,
          total_ratings: 0
        });
      }
    } catch (error: any) {
      console.error('Error fetching profile:', error);
      setFetchError('Failed to load profile data. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user?.id) {
      fetchProfile();
    }
  }, [user?.id]);

  const updateProfile = async (profileData: {
    full_name?: string;
    location?: string;
    date_of_birth?: string;
    gender?: string;
    zip_code?: string;
  }) => {
    if (!user) {
      logSecurityEvent('Unauthorized profile update attempt', {}, 'medium');
      toast({
        title: "Error",
        description: "You must be logged in to update your profile",
        variant: "destructive"
      });
      return false;
    }

    // Enhanced rate limiting
    if (!enhancedRateLimit(`profile_update_${user.id}`, 10, 60 * 60 * 1000)) {
      logSecurityEvent('Rate limit exceeded for profile update', { userId: user.id }, 'medium');
      toast({
        title: "Rate Limit Exceeded",
        description: "Too many profile updates. Please wait before trying again.",
        variant: "destructive"
      });
      return false;
    }

    // Enhanced validation
    const validation = validateProfileData(profileData);
    if (!validation.isValid) {
      logSecurityEvent('Invalid profile data submitted', { errors: validation.errors }, 'low');
      setValidationErrors(validation.errors.reduce((acc, error) => {
        const field = error.includes('Full name') ? 'full_name' :
                     error.includes('Location') ? 'location' :
                     error.includes('Date of birth') ? 'date_of_birth' :
                     error.includes('Gender') ? 'gender' :
                     error.includes('Zip code') ? 'zip_code' : 'general';
        acc[field] = error;
        return acc;
      }, {} as Record<string, string>));
      toast({
        title: "Validation Error",
        description: validation.errors[0],
        variant: "destructive"
      });
      return false;
    }

    setValidationErrors({});
    setLoading(true);
    try {
      console.log('Updating profile with validated and sanitized data:', validation.sanitizedData);

      const { data, error } = await supabase
        .from('profiles')
        .update({
          ...validation.sanitizedData,
          updated_at: new Date().toISOString()
        })
        .eq('id', user.id)
        .select()
        .single();

      if (error) {
        console.error('Error updating profile:', error);
        logSecurityEvent('Profile update failed', { error: error.message }, 'medium');
        throw error;
      }

      logSecurityEvent('Profile updated successfully', { userId: user.id }, 'low');
      toast({
        title: "Success",
        description: "Profile updated successfully"
      });

      return data;
    } catch (error: any) {
      console.error('Error updating profile:', error);
      logSecurityEvent('Profile update exception', { error: error.message }, 'high');
      toast({
        title: "Error",
        description: "Failed to update profile. Please try again.",
        variant: "destructive"
      });
      return false;
    } finally {
      setLoading(false);
    }
  };

  const saveProfile = async (profileData: Profile) => {
    return await updateProfile(profileData);
  };

  const calculateAge = (dateOfBirth: string) => {
    if (!dateOfBirth) return '';
    const today = new Date();
    const birthDate = new Date(dateOfBirth);
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    
    return age.toString();
  };

  const getMemberSince = () => {
    if (!user?.created_at) return '';
    try {
      return new Date(user.created_at).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      });
    } catch {
      return '';
    }
  };

  return {
    profile,
    setProfile,
    loading,
    fetchError,
    fetchProfile,
    updateProfile,
    saveProfile,
    calculateAge,
    getMemberSince,
    validationErrors
  };
};
