
import { useState } from 'react';
import { useTeamJoinRequests } from '@/hooks/useTeamJoinRequests';

export const useTeamJoinActions = (teamId: string) => {
  const [joinRequestMessage, setJoinRequestMessage] = useState('');
  const [showJoinRequestForm, setShowJoinRequestForm] = useState(false);
  
  const { requests, sendJoinRequest, respondToRequest } = useTeamJoinRequests(teamId);

  const handleSendJoinRequest = async () => {
    const success = await sendJoinRequest(teamId, joinRequestMessage);
    if (success) {
      setJoinRequestMessage('');
      setShowJoinRequestForm(false);
    }
  };

  const handleCancelJoinRequest = () => {
    setShowJoinRequestForm(false);
    setJoinRequestMessage('');
  };

  const pendingRequests = requests.filter(r => r.status === 'pending');

  return {
    requests,
    pendingRequests,
    joinRequestMessage,
    setJoinRequestMessage,
    showJoinRequestForm,
    setShowJoinRequestForm,
    handleSendJoinRequest,
    handleCancelJoinRequest,
    respondToRequest
  };
};
