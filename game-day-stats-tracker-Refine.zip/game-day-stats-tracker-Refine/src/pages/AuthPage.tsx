
import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from "@/components/ui/use-toast";
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useSecureAuth } from '@/hooks/useSecureAuth';
import { generateCSRFToken, logSecurityEvent, isSessionValid } from '@/utils/securityEnhancements';

type AuthMode = 'login' | 'register' | 'reset';

const AuthPage: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { session } = useAuth();
  const { signUp, signIn, loading } = useSecureAuth();

  const [mode, setMode] = useState<AuthMode>('login');
  const [csrfToken, setCsrfToken] = useState<string>('');
  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [name, setName] = useState('');

  // Generate CSRF token on component mount
  useEffect(() => {
    const token = generateCSRFToken();
    setCsrfToken(token);
    sessionStorage.setItem('csrf_token', token);
  }, []);

  useEffect(() => {
    if (session) {
      // Validate session security
      isSessionValid().then(valid => {
        if (valid) {
          navigate('/dashboard');
        } else {
          logSecurityEvent('Invalid session detected on auth page', {}, 'medium');
          // Session cleanup handled by isSessionValid
        }
      });
    }
  }, [session, navigate]);

  useEffect(() => {
    const searchParams = new URLSearchParams(location.search);
    const verified = searchParams.get('verified');
    
    if (verified === 'true') {
      toast({
        title: "Email Verified",
        description: "Your email has been verified successfully. You can now sign in.",
      });
      setMode('login');
    }

    const hash = location.hash.replace('#', '');
    if (hash === 'login' || hash === 'register' || hash === 'reset') {
      setMode(hash);
    } else {
      setMode('login'); 
    }
    
    // Clear form when mode changes for security
    setEmail('');
    setPassword('');
    setConfirmPassword('');
    setName('');
    
    // Log mode changes for security monitoring
    logSecurityEvent('Auth page mode changed', { mode: hash || 'login' }, 'low');
  }, [location.hash, location.search]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // CSRF validation
    const storedToken = sessionStorage.getItem('csrf_token');
    if (!storedToken || storedToken !== csrfToken) {
      logSecurityEvent('CSRF token validation failed', {}, 'high');
      toast({
        title: "Security Error",
        description: "Please refresh the page and try again.",
        variant: "destructive"
      });
      return;
    }

    // Additional client-side validation for security
    if (!email || email.length > 254) {
      toast({
        title: "Validation Error",
        description: "Please enter a valid email address.",
        variant: "destructive"
      });
      return;
    }

    if (mode !== 'reset' && (!password || password.length < 8)) {
      toast({
        title: "Validation Error",
        description: "Password must be at least 8 characters long.",
        variant: "destructive"
      });
      return;
    }

    try {
      if (mode === 'register') {
        if (!name || name.length < 2) {
          toast({
            title: "Validation Error",
            description: "Please enter your full name.",
            variant: "destructive"
          });
          return;
        }

        const result = await signUp(email, password, confirmPassword, name);
        if (!result.error) {
          setMode('login');
          // Clear sensitive data
          setPassword('');
          setConfirmPassword('');
        }
      } else if (mode === 'login') {
        const result = await signIn(email, password);
        if (!result.error) {
          // Clear sensitive data
          setPassword('');
          navigate('/dashboard');
        }
      } else if (mode === 'reset') {
        try {
          const { error } = await supabase.auth.resetPasswordForEmail(email, {
            redirectTo: `${window.location.origin}/auth#login`,
          });
          
          if (error) {
            logSecurityEvent('Password reset failed', { error: error.message }, 'medium');
            toast({
              title: "Reset Error",
              description: error.message,
              variant: "destructive"
            });
          } else {
            logSecurityEvent('Password reset requested', { email: email.substring(0, 3) + '***' }, 'low');
            toast({
              title: "Reset Email Sent",
              description: "Please check your email for password reset instructions.",
            });
            setMode('login');
          }
        } catch (error: any) {
          logSecurityEvent('Password reset exception', { error: error.message }, 'high');
          toast({
            title: "Error",
            description: "An unexpected error occurred. Please try again.",
            variant: "destructive"
          });
        }
      }
    } catch (error: any) {
      logSecurityEvent('Auth form submission exception', { error: error.message, mode }, 'high');
      toast({
        title: "Error",
        description: error.message || "An unexpected error occurred. Please try again.",
        variant: "destructive"
      });
    }
  };

  const isRegisterMode = mode === 'register';
  const isResetMode = mode === 'reset';

  return (
    <div className="flex items-center justify-center py-12 animate-fade-in-up">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-2xl">
            {mode === 'login' && 'Welcome Back!'}
            {mode === 'register' && 'Join SportSphere'}
            {mode === 'reset' && 'Reset Password'}
          </CardTitle>
          <CardDescription>
            {mode === 'login' && 'Login to access your dashboard.'}
            {mode === 'register' && 'Create your account to get started.'}
            {mode === 'reset' && 'Enter your email to receive reset instructions.'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Hidden CSRF token field */}
            <input type="hidden" name="csrf_token" value={csrfToken} />
            
            {isRegisterMode && (
              <div className="space-y-2">
                <Label htmlFor="name">Full Name</Label>
                <Input 
                  id="name" 
                  type="text" 
                  placeholder="Your Name" 
                  value={name} 
                  onChange={(e) => setName(e.target.value)} 
                  required 
                  disabled={loading}
                  maxLength={100}
                  autoComplete="name"
                />
              </div>
            )}
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input 
                id="email" 
                type="email" 
                placeholder="you@example.com" 
                value={email} 
                onChange={(e) => setEmail(e.target.value)} 
                required 
                disabled={loading}
                maxLength={254}
                autoComplete="email"
              />
            </div>
            {!isResetMode && (
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input 
                  id="password" 
                  type="password" 
                  value={password} 
                  onChange={(e) => setPassword(e.target.value)} 
                  required 
                  disabled={loading}
                  minLength={8}
                  autoComplete={isRegisterMode ? "new-password" : "current-password"}
                />
              </div>
            )}
            {isRegisterMode && (
              <div className="space-y-2">
                <Label htmlFor="confirmPassword">Confirm Password</Label>
                <Input 
                  id="confirmPassword" 
                  type="password" 
                  value={confirmPassword} 
                  onChange={(e) => setConfirmPassword(e.target.value)} 
                  required 
                  disabled={loading}
                  minLength={8}
                  autoComplete="new-password"
                />
              </div>
            )}
            <Button 
              type="submit" 
              className="w-full" 
              variant={isRegisterMode ? "secondary" : "default"} 
              disabled={loading}
            >
              {loading ? 'Processing...' : (
                mode === 'login' ? 'Login' : 
                mode === 'register' ? 'Create Account' : 
                'Send Reset Email'
              )}
            </Button>
          </form>
        </CardContent>
        <CardFooter className="flex flex-col space-y-2">
          {mode === 'login' ? (
            <>
              <p className="text-sm text-muted-foreground">
                Don't have an account?{' '}
                <Button 
                  variant="link" 
                  className="p-0 h-auto" 
                  onClick={() => navigate('/auth#register')} 
                  disabled={loading}
                >
                  Sign up
                </Button>
              </p>
              <p className="text-sm text-muted-foreground">
                Forgot your password?{' '}
                <Button 
                  variant="link" 
                  className="p-0 h-auto" 
                  onClick={() => navigate('/auth#reset')} 
                  disabled={loading}
                >
                  Reset password
                </Button>
              </p>
            </>
          ) : mode === 'register' ? (
            <p className="text-sm text-muted-foreground">
              Already have an account?{' '}
              <Button 
                variant="link" 
                className="p-0 h-auto" 
                onClick={() => navigate('/auth#login')} 
                disabled={loading}
              >
                Login
              </Button>
            </p>
          ) : (
            <p className="text-sm text-muted-foreground">
              Remember your password?{' '}
              <Button 
                variant="link" 
                className="p-0 h-auto" 
                onClick={() => navigate('/auth#login')} 
                disabled={loading}
              >
                Back to login
              </Button>
            </p>
          )}
        </CardFooter>
      </Card>
    </div>
  );
};

export default AuthPage;
