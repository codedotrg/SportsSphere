
import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Plus } from 'lucide-react';
import { Navbar } from '@/components/Navbar';
import { BackButton } from '@/components/navigation/BackButton';
import { NewMessageDialog } from '@/components/messaging/NewMessageDialog';
import { MessagesTabs } from '@/components/messaging/MessagesTabs';
import { useDirectMessages } from '@/hooks/useDirectMessages';
import { ConversationView } from '@/components/messaging/ConversationView';
import { useAuth } from '@/contexts/AuthContext';

const MessagesPage: React.FC = () => {
  const [showComposer, setShowComposer] = React.useState(false);
  const [selectedConversation, setSelectedConversation] = React.useState<any>(null);
  const [replyToUserId, setReplyToUserId] = React.useState<string>('');
  const { user } = useAuth();
  const { 
    conversations: inboxConversations, 
    loading: inboxLoading, 
    refetch: refetchInbox,
    markAsRead
  } = useDirectMessages('inbox');
  const { 
    conversations: sentConversations, 
    loading: sentLoading,
    refetch: refetchSent
  } = useDirectMessages('sent');

  const handleConversationClick = (conversation: any) => {
    setSelectedConversation(conversation);
    if (conversation.otherUser) {
      setReplyToUserId(conversation.otherUser.id);
    } else {
       // Fallback for older conversation objects
       const otherId = user?.id === conversation.sender_id ? conversation.recipient_id : conversation.sender_id;
       setReplyToUserId(otherId);
    }
  };

  const handleReplySuccess = () => {
    setSelectedConversation(null);
    setReplyToUserId('');
    refetchInbox();
    refetchSent();
  };

  const handleBackToMessages = () => {
    setSelectedConversation(null);
  };

  const handleMessageSent = () => {
    setShowComposer(false);
    refetchInbox();
    refetchSent();
  };

  if (selectedConversation) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <main className="container mx-auto px-4 py-8">
          <ConversationView
            conversation={selectedConversation}
            replyToUserId={replyToUserId}
            onBack={handleBackToMessages}
            onReplySuccess={handleReplySuccess}
            onMarkAsRead={markAsRead}
          />
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="container mx-auto px-4 py-8">
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <BackButton fallbackPath="/dashboard" />
              <div>
                <h1 className="text-3xl font-bold">Messages</h1>
                <p className="text-muted-foreground">
                  Communication hub for events and teams
                </p>
              </div>
            </div>
            <Button onClick={() => setShowComposer(true)}>
              <Plus className="mr-2 h-4 w-4" />
              New Message
            </Button>
          </div>

          <Tabs defaultValue="direct" className="space-y-6">
            <TabsList>
              <TabsTrigger value="direct">Direct Messages</TabsTrigger>
              <TabsTrigger value="general">General</TabsTrigger>
            </TabsList>

            <TabsContent value="direct">
              <MessagesTabs
                inboxConversations={inboxConversations}
                sentConversations={sentConversations}
                inboxLoading={inboxLoading}
                sentLoading={sentLoading}
                onConversationClick={handleConversationClick}
              />
            </TabsContent>

            <TabsContent value="general">
              <Card>
                <CardHeader>
                  <CardTitle>General Messages</CardTitle>
                  <CardDescription>Event-related communications</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-8 text-muted-foreground">
                    <p>Please select an event to view its messages.</p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          <NewMessageDialog
            open={showComposer}
            onOpenChange={setShowComposer}
            onMessageSent={handleMessageSent}
          />
        </div>
      </main>
    </div>
  );
};

export default MessagesPage;
