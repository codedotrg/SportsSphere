
import React, { useState } from 'react';
import { Navbar } from '@/components/Navbar';
import { ConversationView } from '@/components/messaging/ConversationView';
import { MessagesHeader } from '@/components/messaging/MessagesHeader';
import { MessagesTabs } from '@/components/messaging/MessagesTabs';
import { NewMessageDialog } from '@/components/messaging/NewMessageDialog';
import { useDirectMessages } from '@/hooks/useDirectMessages';
import { useAuth } from '@/contexts/AuthContext';

const DirectMessagesPage: React.FC = () => {
  const [showComposer, setShowComposer] = useState(false);
  const [selectedConversation, setSelectedConversation] = useState<any>(null);
  const [replyToUserId, setReplyToUserId] = useState<string>('');
  const { user } = useAuth();
  const { 
    conversations: inboxConversations, 
    loading: inboxLoading, 
    refetch: refetchInbox,
    markAsRead
  } = useDirectMessages('inbox');
  const { 
    conversations: sentConversations, 
    loading: sentLoading,
    refetch: refetchSent
  } = useDirectMessages('sent');

  const handleConversationClick = (conversation: any) => {
    setSelectedConversation(conversation);
    if (conversation.otherUser) {
      setReplyToUserId(conversation.otherUser.id);
    } else {
       // Fallback for older conversation objects
       const otherId = user?.id === conversation.sender_id ? conversation.recipient_id : conversation.sender_id;
       setReplyToUserId(otherId);
    }
  };

  const handleReplySuccess = () => {
    setSelectedConversation(null);
    setReplyToUserId('');
    refetchInbox();
    refetchSent();
  };

  const handleNewMessageClick = () => {
    setShowComposer(true);
  };

  const handleMessageSent = () => {
    setShowComposer(false);
    refetchInbox();
    refetchSent();
  };

  const handleBackToMessages = () => {
    setSelectedConversation(null);
  };

  if (selectedConversation) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <main className="container mx-auto px-4 py-8">
          <ConversationView
            conversation={selectedConversation}
            replyToUserId={replyToUserId}
            onBack={handleBackToMessages}
            onReplySuccess={handleReplySuccess}
            onMarkAsRead={markAsRead}
          />
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="container mx-auto px-4 py-8">
        <div className="space-y-6">
          <MessagesHeader onNewMessage={handleNewMessageClick} />
          
          <MessagesTabs
            inboxConversations={inboxConversations}
            sentConversations={sentConversations}
            inboxLoading={inboxLoading}
            sentLoading={sentLoading}
            onConversationClick={handleConversationClick}
          />

          <NewMessageDialog
            open={showComposer}
            onOpenChange={setShowComposer}
            onMessageSent={handleMessageSent}
          />
        </div>
      </main>
    </div>
  );
};

export default DirectMessagesPage;
