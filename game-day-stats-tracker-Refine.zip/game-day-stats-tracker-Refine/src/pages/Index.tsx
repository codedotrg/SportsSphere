
import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Users, BarChart2, ShieldCheck, Trophy } from 'lucide-react';

const FeatureCard: React.FC<{ icon: React.ElementType, title: string, description: string }> = ({ icon: Icon, title, description }) => (
  <div className="bg-card p-6 rounded-lg shadow-lg transform hover:scale-105 transition-transform duration-300">
    <Icon className="h-12 w-12 text-primary mb-4" />
    <h3 className="text-xl font-semibold mb-2 text-foreground">{title}</h3>
    <p className="text-muted-foreground">{description}</p>
  </div>
);

const LandingPage = () => {
  return (
    <div className="animate-fade-in-up">
      {/* Hero Section */}
      <section className="text-center py-20">
        <Trophy className="h-24 w-24 text-secondary mx-auto mb-6 animate-bounce" />
        <h1 className="text-5xl md:text-6xl font-extrabold mb-6 text-transparent bg-clip-text bg-gradient-to-r from-primary via-sky-400 to-secondary">
          SportSphere
        </h1>
        <p className="text-2xl font-semibold text-foreground mb-4">
          Connect, Compete, Conquer.
        </p>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-10">
          The ultimate platform for players to showcase their skills and for organizers to manage thrilling sports events. Track stats, get rated, and climb the ranks!
        </p>
        <div className="space-x-4">
          <Button size="lg" variant="default" asChild>
            <Link to="/auth#register">
              <span>Join SportSphere</span>
            </Link>
          </Button>
          <Button size="lg" variant="secondary" asChild>
            <Link to="/auth#login">
              <span>Login</span>
            </Link>
          </Button>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16">
        <h2 className="text-3xl font-bold text-center mb-12 text-foreground">Platform Highlights</h2>
        <div className="grid md:grid-cols-3 gap-8">
          <FeatureCard
            icon={Users}
            title="For Players & Organizers"
            description="Join as a user and choose to be a player, organizer, or both! Switch roles anytime."
          />
          <FeatureCard
            icon={BarChart2}
            title="Track Your Performance"
            description="Get detailed statistics, track your ratings, and see your progress over time."
          />
          <FeatureCard
            icon={ShieldCheck}
            title="Fair & Transparent Ratings"
            description="Event organizers rate player performances, fostering a competitive and fair environment."
          />
        </div>
      </section>

      {/* Call to Action Section */}
      <section className="py-20 bg-card rounded-lg my-10">
        <div className="container mx-auto text-center">
          <h2 className="text-3xl font-bold mb-6 text-foreground">Ready to Elevate Your Game?</h2>
          <p className="text-muted-foreground mb-8 max-w-xl mx-auto">
            Join SportSphere today and become part of the ultimate sports community. Choose your role after you sign up!
          </p>
          <Button size="lg" variant="default" asChild>
            <Link to="/auth#register">
              <span>Get Started Now</span>
            </Link>
          </Button>
        </div>
      </section>
    </div>
  );
};

export default LandingPage;
