
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Calendar, Plus } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Navbar } from '@/components/Navbar';
import { BackButton } from '@/components/navigation/BackButton';
import { EventDetails } from '@/components/EventDetails';
import { TeamFormation } from '@/components/TeamFormation';
import { EventCard } from '@/components/events/EventCard';
import { EventsErrorState } from '@/components/events/EventsErrorState';
import { EventsEmptyState } from '@/components/events/EventsEmptyState';
import { EventsLoadingState } from '@/components/events/EventsLoadingState';
import { EventsAuthError } from '@/components/events/EventsAuthError';
import { useEvents } from '@/hooks/useEvents';

interface Event {
  id: string;
  title: string;
  description: string;
  sport: string;
  location: string;
  event_date: string;
  organizer_id: string;
  created_at: string;
}

const EventsPage: React.FC = () => {
  const navigate = useNavigate();
  const { events, loading, error, authLoading, user, refetch } = useEvents();
  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null);
  const [showEventDetails, setShowEventDetails] = useState(false);

  const handleViewDetails = (event: Event) => {
    setSelectedEvent(event);
    setShowEventDetails(true);
  };

  const closeEventDetails = () => {
    setSelectedEvent(null);
    setShowEventDetails(false);
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <main className="container mx-auto px-4 py-8">
          <div className="animate-fade-in-up">
            <div className="flex items-center gap-4 mb-6">
              <BackButton fallbackPath="/dashboard" />
              <h1 className="text-3xl font-bold">Events</h1>
            </div>
            <EventsLoadingState message="Loading..." />
          </div>
        </main>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <main className="container mx-auto px-4 py-8">
          <div className="flex items-center gap-4 mb-6">
            <BackButton fallbackPath="/dashboard" />
            <EventsAuthError />
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="container mx-auto px-4 py-8">
        <div className="animate-fade-in-up">
          <div className="flex justify-between items-center mb-6">
            <div className="flex items-center gap-4">
              <BackButton fallbackPath="/dashboard" />
              <h1 className="text-3xl font-bold flex items-center">
                <Calendar className="mr-3 h-8 w-8 text-primary" />
                Events
              </h1>
            </div>
            <Button onClick={() => navigate('/events/create')}>
              <Plus className="mr-2 h-4 w-4" />
              Create Event
            </Button>
          </div>

          {error ? (
            <EventsErrorState error={error} onRetry={refetch} />
          ) : loading ? (
            <EventsLoadingState />
          ) : events.length === 0 ? (
            <EventsEmptyState />
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {events.map((event) => (
                <EventCard 
                  key={event.id} 
                  event={event} 
                  onViewDetails={handleViewDetails}
                  currentUserId={user.id}
                />
              ))}
            </div>
          )}

          {/* Event Details Dialog */}
          <Dialog open={showEventDetails} onOpenChange={setShowEventDetails}>
            <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Event Details</DialogTitle>
              </DialogHeader>
              {selectedEvent && (
                <div className="space-y-6">
                  <EventDetails event={selectedEvent} />
                  
                  {/* Team Formation Section */}
                  <TeamFormation 
                    eventId={selectedEvent.id}
                    isOrganizer={user?.id === selectedEvent.organizer_id}
                    participants={[]} // Will be populated by the component
                  />
                </div>
              )}
            </DialogContent>
          </Dialog>
        </div>
      </main>
    </div>
  );
};

export default EventsPage;
