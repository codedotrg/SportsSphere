
import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { UserCircle, Star } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useSecureProfile } from '@/hooks/useSecureProfile';
import { Navbar } from '@/components/Navbar';
import { ProfileActions } from '@/components/profile/ProfileActions';
import { ProfileErrorDisplay } from '@/components/profile/ProfileErrorDisplay';
import { ProfileForm } from '@/components/profile/ProfileForm';
import { ProfilePictureUpload } from '@/components/profile/ProfilePictureUpload';
import { BackButton } from '@/components/navigation/BackButton';
import Footer from '@/components/Footer';

const ProfilePage: React.FC = () => {
  const { user, loading: authLoading } = useAuth();
  const {
    profile,
    setProfile,
    loading,
    fetchError,
    fetchProfile,
    saveProfile,
    calculateAge,
    getMemberSince,
    validationErrors
  } = useSecureProfile();
  const [isEditing, setIsEditing] = useState(false);

  const handleSave = async () => {
    const success = await saveProfile(profile);
    if (success) {
      setIsEditing(false);
    }
  };

  const handleCancel = () => {
    setIsEditing(false);
    fetchProfile(); // Reset to original values
  };

  const handlePictureUpdate = (url: string) => {
    setProfile({ ...profile, profile_picture: url });
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <Navbar />
        <main className="flex-1 container mx-auto px-4 py-8">
          <div className="animate-fade-in-up">
            <div className="text-center py-8">
              <p>Loading...</p>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <Navbar />
        <main className="flex-1 container mx-auto px-4 py-8">
          <div className="animate-fade-in-up">
            <div className="text-center py-8">
              <p>Please log in to view your profile.</p>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  const memberSince = getMemberSince();

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />
      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="animate-fade-in-up max-w-4xl mx-auto">
          <div className="mb-6 flex items-center space-x-4">
            <BackButton fallbackPath="/dashboard" />
            <div>
              <h1 className="text-3xl font-bold flex items-center">
                <UserCircle className="mr-3 h-8 w-8 text-primary" />
                Welcome, {profile.full_name || user.user_metadata?.full_name || 'User'}!
              </h1>
              {memberSince && (
                <p className="text-muted-foreground mt-2">
                  Member since {memberSince}
                </p>
              )}
            </div>
          </div>
          
          {fetchError ? (
            <ProfileErrorDisplay error={fetchError} onRetry={fetchProfile} />
          ) : (
            <div className="space-y-6">
              {/* Profile Picture Section */}
              <Card>
                <CardHeader>
                  <CardTitle>Profile Picture</CardTitle>
                  <CardDescription>Upload and manage your profile picture</CardDescription>
                </CardHeader>
                <CardContent className="flex justify-center">
                  <ProfilePictureUpload
                    profilePicture={profile.profile_picture}
                    userName={profile.full_name}
                    userEmail={profile.email}
                    onPictureUpdate={handlePictureUpdate}
                  />
                </CardContent>
              </Card>

              {/* Profile Information Section */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex justify-between items-center">
                    Profile Information
                    <ProfileActions
                      isEditing={isEditing}
                      loading={loading}
                      onEdit={() => setIsEditing(true)}
                      onSave={handleSave}
                      onCancel={handleCancel}
                    />
                  </CardTitle>
                  <CardDescription>
                    Manage your account details and personal information.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {loading && !isEditing ? (
                    <div className="text-center py-4">
                      <p className="text-muted-foreground">Loading profile...</p>
                    </div>
                  ) : (
                    <ProfileForm
                      profile={profile}
                      isEditing={isEditing}
                      calculateAge={calculateAge}
                      onProfileChange={setProfile}
                      validationErrors={validationErrors}
                    />
                  )}
                </CardContent>
              </Card>

              {/* Player Stats & Ratings Section */}
              <Card>
                <CardHeader>
                  <CardTitle>Player Stats & Ratings</CardTitle>
                  <CardDescription>
                    Your performance statistics and ratings from other players
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold">Overall Rating</h3>
                      <div className="flex items-center space-x-2">
                        <div className="flex items-center">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <Star
                              key={star}
                              className={`h-5 w-5 ${
                                star <= Math.round(profile.average_rating || 0)
                                  ? 'fill-yellow-400 text-yellow-400'
                                  : 'text-gray-300'
                              }`}
                            />
                          ))}
                        </div>
                        <span className="font-bold text-lg">
                          {profile.average_rating?.toFixed(1) || '0.0'}
                        </span>
                        <Badge variant="outline">
                          {profile.total_ratings || 0} rating{(profile.total_ratings || 0) !== 1 ? 's' : ''}
                        </Badge>
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold">Activity Summary</h3>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span>Events Participated:</span>
                          <Badge variant="secondary">Coming Soon</Badge>
                        </div>
                        <div className="flex justify-between">
                          <span>Teams Joined:</span>
                          <Badge variant="secondary">Coming Soon</Badge>
                        </div>
                        <div className="flex justify-between">
                          <span>Events Organized:</span>
                          <Badge variant="secondary">Coming Soon</Badge>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  {(!profile.total_ratings || profile.total_ratings === 0) && (
                    <div className="text-center py-8 text-muted-foreground">
                      <p>Play in events to build your player statistics and receive ratings!</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default ProfilePage;
