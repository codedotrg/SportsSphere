import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { AIMatchmakingCard } from '@/components/ai/AIMatchmakingCard';
import { useAIMatchmaking } from '@/hooks/useAIMatchmaking';
import { Brain, Settings, Users, ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { BackButton } from '@/components/navigation/BackButton';

const AIMatchmakingPage: React.FC = () => {
  const { preferences, savePreferences } = useAIMatchmaking();
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    preferred_skill_level: preferences?.preferred_skill_level || '',
    max_distance_km: preferences?.max_distance_km || 50,
    ai_personality_match: preferences?.ai_personality_match ?? true,
    preferred_sports: preferences?.preferred_sports || [],
  });

  const [newSport, setNewSport] = useState('');

  const handleSavePreferences = async () => {
    await savePreferences(formData);
  };

  const addSport = () => {
    if (newSport && !formData.preferred_sports.includes(newSport)) {
      setFormData(prev => ({
        ...prev,
        preferred_sports: [...prev.preferred_sports, newSport]
      }));
      setNewSport('');
    }
  };

  const removeSport = (sport: string) => {
    setFormData(prev => ({
      ...prev,
      preferred_sports: prev.preferred_sports.filter(s => s !== sport)
    }));
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-4">
        <BackButton fallbackPath="/dashboard" />
        <div>
          <h1 className="text-3xl font-bold flex items-center">
            <Brain className="mr-3 h-8 w-8" />
            AI Matchmaking
          </h1>
          <p className="text-muted-foreground">
            Find compatible players using artificial intelligence
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Preferences Card */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Settings className="mr-2 h-5 w-5" />
              Matching Preferences
            </CardTitle>
            <CardDescription>
              Customize your AI matching criteria
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="skill-level">Preferred Skill Level</Label>
              <Select 
                value={formData.preferred_skill_level} 
                onValueChange={(value) => setFormData(prev => ({ ...prev, preferred_skill_level: value }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select skill level" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="beginner">Beginner</SelectItem>
                  <SelectItem value="intermediate">Intermediate</SelectItem>
                  <SelectItem value="advanced">Advanced</SelectItem>
                  <SelectItem value="professional">Professional</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="distance">Maximum Distance (km)</Label>
              <Input
                type="number"
                value={formData.max_distance_km}
                onChange={(e) => setFormData(prev => ({ ...prev, max_distance_km: parseInt(e.target.value) || 50 }))}
                min="1"
                max="500"
              />
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                checked={formData.ai_personality_match}
                onCheckedChange={(checked) => setFormData(prev => ({ ...prev, ai_personality_match: checked }))}
              />
              <Label>Enable AI personality matching</Label>
            </div>

            <div>
              <Label>Preferred Sports</Label>
              <div className="flex space-x-2 mb-2">
                <Input
                  placeholder="Add a sport..."
                  value={newSport}
                  onChange={(e) => setNewSport(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && addSport()}
                />
                <Button onClick={addSport} size="sm">Add</Button>
              </div>
              <div className="flex flex-wrap gap-2">
                {formData.preferred_sports.map((sport, index) => (
                  <Badge key={index} variant="secondary" className="cursor-pointer" onClick={() => removeSport(sport)}>
                    {sport} ×
                  </Badge>
                ))}
              </div>
            </div>

            <Button onClick={handleSavePreferences} className="w-full">
              Save Preferences
            </Button>
          </CardContent>
        </Card>

        {/* AI Matchmaking Card */}
        <AIMatchmakingCard />
      </div>
    </div>
  );
};

export default AIMatchmakingPage;
