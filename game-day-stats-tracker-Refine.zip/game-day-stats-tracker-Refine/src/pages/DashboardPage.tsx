
import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Plus, Calendar, Users, MessageSquare, Trophy } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Navbar } from '@/components/Navbar';
import { useAuth } from '@/contexts/AuthContext';
import { DashboardHeader } from '@/components/dashboard/DashboardHeader';
import { RecentEventsCard } from '@/components/dashboard/RecentEventsCard';
import { MyTeamCard } from '@/components/dashboard/MyTeamCard';
import { RequirementsCard } from '@/components/dashboard/RequirementsCard';
import { QuickActionsCard } from '@/components/dashboard/QuickActionsCard';
import { ActivityFeedCard } from '@/components/dashboard/ActivityFeedCard';
import { StatsCard } from '@/components/dashboard/StatsCard';
import { SportsNewsCard } from '@/components/dashboard/SportsNewsCard';
import { WeatherCard } from '@/components/dashboard/WeatherCard';
import { LeaguesCard } from '@/components/dashboard/LeaguesCard';
import { MessagingCard } from '@/components/dashboard/MessagingCard';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { RequirementDetailsModal } from '@/components/requirements/RequirementDetailsModal';
import { useIsMobile } from '@/hooks/use-mobile';
import { ConnectionsCard } from '@/components/dashboard/ConnectionsCard';
import { FollowListModal } from '@/components/follow/FollowListModal';
import { WelcomeCard } from '@/components/dashboard/WelcomeCard';
import { MiniGameCard } from '@/components/dashboard/MiniGameCard';
import { MotivationalFooter } from '@/components/MotivationalFooter';

const DashboardPage: React.FC = () => {
  const navigate = useNavigate();
  const { user, loading } = useAuth();
  const isMobile = useIsMobile();
  const [selectedRequirementId, setSelectedRequirementId] = useState<string | null>(null);
  const [isFollowModalOpen, setFollowModalOpen] = useState(false);
  const [followModalInitialTab, setFollowModalInitialTab] = useState<'followers' | 'following'>('followers');

  const handleRequirementClick = (requirementId: string) => {
    setSelectedRequirementId(requirementId);
  };
  
  const handleViewFollowers = () => {
    setFollowModalInitialTab('followers');
    setFollowModalOpen(true);
  };

  const handleViewFollowing = () => {
    setFollowModalInitialTab('following');
    setFollowModalOpen(true);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <main className="container mx-auto px-2 sm:px-4 py-4 sm:py-8">
          <div className="text-center">Loading...</div>
        </main>
      </div>
    );
  }

  if (!user) {
    navigate('/auth');
    return null;
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />
      <main className="flex-1 container mx-auto px-2 sm:px-4 py-4 sm:py-8">
        <div className="animate-fade-in-up space-y-4 sm:space-y-6">
          <DashboardHeader />
          <WelcomeCard />

          {/* Mobile: Single column layout, Desktop: Multi-column */}
          {isMobile ? (
            <div className="space-y-4">
              <QuickActionsCard />
              <StatsCard />
              <MiniGameCard />
              <MessagingCard />
              <ConnectionsCard onViewFollowers={handleViewFollowers} onViewFollowing={handleViewFollowing} />
              <RequirementsCard onRequirementClick={handleRequirementClick} />
              <RecentEventsCard />
              <ActivityFeedCard />
              <MyTeamCard />
              <SportsNewsCard />
              <LeaguesCard />
            </div>
          ) : (
            <>
              {/* First Row - Quick Actions, Stats, Weather (3 cards) */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <QuickActionsCard />
                <StatsCard />
                <MiniGameCard />
              </div>

              {/* Messages and Requirements Row - Half page width each */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <MessagingCard />
                <RequirementsCard onRequirementClick={handleRequirementClick} />
              </div>
              
              {/* Connections and My Team Row */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <ConnectionsCard onViewFollowers={handleViewFollowers} onViewFollowing={handleViewFollowing} />
                <MyTeamCard />
              </div>

              {/* Recent Events & Activity Feed */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <RecentEventsCard />
                <ActivityFeedCard />
              </div>

              {/* Sports News and Leagues (full width) */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <SportsNewsCard />
                <LeaguesCard />
              </div>
            </>
          )}

          <Dialog open={!!selectedRequirementId} onOpenChange={() => setSelectedRequirementId(null)}>
            <DialogContent className="max-w-[95vw] sm:max-w-2xl max-h-[90vh] overflow-y-auto mx-2">
              <DialogHeader>
                <DialogTitle>Player Requirement Details</DialogTitle>
              </DialogHeader>
              {selectedRequirementId && (
                <RequirementDetailsModal 
                  requirementId={selectedRequirementId}
                  onClose={() => setSelectedRequirementId(null)}
                />
              )}
            </DialogContent>
          </Dialog>

          <FollowListModal
            isOpen={isFollowModalOpen}
            onClose={() => setFollowModalOpen(false)}
            initialTab={followModalInitialTab}
          />
        </div>
      </main>
      <MotivationalFooter />
    </div>
  );
};

export default DashboardPage;
