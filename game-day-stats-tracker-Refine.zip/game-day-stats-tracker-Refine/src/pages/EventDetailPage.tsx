
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/components/ui/use-toast';
import { useEventParticipants } from '@/hooks/useEventParticipants';
import { useEventJoinRequests } from '@/hooks/useEventJoinRequests';
import { EventLoadingState } from '@/components/event-detail/EventLoadingState';
import { EventAuthRequired } from '@/components/event-detail/EventAuthRequired';
import { EventErrorState } from '@/components/event-detail/EventErrorState';
import { EventJoinRequestButton } from '@/components/event-detail/EventJoinRequestButton';
import { PendingJoinRequests } from '@/components/event-detail/PendingJoinRequests';
import { EventTabs } from '@/components/event-detail/EventTabs';

interface Event {
  id: string;
  title: string;
  description: string;
  sport: string;
  location: string;
  event_date: string;
  organizer_id: string;
  created_at: string;
}

const EventDetailPage: React.FC = () => {
  const { eventId } = useParams<{ eventId: string }>();
  const { user, loading: authLoading } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [event, setEvent] = useState<Event | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  const { participants } = useEventParticipants(eventId || '');
  const { requests: joinRequests, sendJoinRequest, respondToRequest } = useEventJoinRequests(eventId);

  const fetchEvent = async () => {
    if (!eventId) {
      setError('No event ID provided');
      setLoading(false);
      return;
    }

    console.log('Fetching event details for:', eventId);
    setLoading(true);
    setError(null);
    
    try {
      const { data, error } = await supabase
        .from('events')
        .select('*')
        .eq('id', eventId)
        .single();

      if (error) {
        console.error('Supabase error:', error);
        throw error;
      }
      
      console.log('Successfully fetched event:', data);
      setEvent(data);
    } catch (error: any) {
      console.error('Error fetching event:', error);
      
      let errorMessage = 'Failed to load event details';
      if (error.message === 'TypeError: Failed to fetch') {
        errorMessage = 'Connection error. Please check your internet connection.';
      } else if (error.code === 'PGRST116') {
        errorMessage = 'Event not found';
      }
      
      setError(errorMessage);
      
      if (error.message !== 'TypeError: Failed to fetch') {
        toast({
          title: "Error",
          description: errorMessage,
          variant: "destructive"
        });
      }
    } finally {
      setLoading(false);
    }
  };

  const handleRetry = () => {
    fetchEvent();
  };

  const handleEventJoinRequest = async (message: string) => {
    if (!eventId) return;
    await sendJoinRequest(eventId, message);
  };

  const handleBackToEvents = () => {
    navigate('/events');
  };

  const handleGoToLogin = () => {
    navigate('/auth');
  };

  useEffect(() => {
    if (!authLoading) {
      fetchEvent();
    }
  }, [eventId, authLoading]);

  if (authLoading || loading) {
    return <EventLoadingState />;
  }

  if (!user) {
    return <EventAuthRequired onGoToLogin={handleGoToLogin} />;
  }

  if (error || !event) {
    return (
      <EventErrorState 
        error={error}
        onRetry={handleRetry}
        onBackToEvents={handleBackToEvents}
      />
    );
  }

  const isOrganizer = user?.id === event.organizer_id;
  const isParticipant = participants.some(p => p.player_id === user?.id);
  const hasJoinRequest = joinRequests.some(r => r.player_id === user?.id && r.status === 'pending');

  return (
    <div className="animate-fade-in-up">
      <div className="mb-6 flex justify-between items-center">
        <Button variant="outline" onClick={handleBackToEvents}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Events
        </Button>
        
        <EventJoinRequestButton
          isOrganizer={isOrganizer}
          isParticipant={isParticipant}
          hasJoinRequest={hasJoinRequest}
          onSendJoinRequest={handleEventJoinRequest}
        />
      </div>

      <PendingJoinRequests
        isOrganizer={isOrganizer}
        joinRequests={joinRequests}
        onRespondToRequest={respondToRequest}
      />

      <EventTabs
        event={event}
        isOrganizer={isOrganizer}
        isParticipant={isParticipant}
        participants={participants}
        userId={user?.id}
      />
    </div>
  );
};

export default EventDetailPage;
