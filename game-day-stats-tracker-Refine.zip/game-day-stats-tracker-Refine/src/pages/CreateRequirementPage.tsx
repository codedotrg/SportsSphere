
import React from 'react';
import { Users } from 'lucide-react';
import CreateRequirementForm from '@/components/CreateRequirementForm';
import { BackButton } from '@/components/navigation/BackButton';

const CreateRequirementPage: React.FC = () => {
  return (
    <div className="animate-fade-in-up">
      <div className="flex items-center space-x-4 mb-6">
        <BackButton fallbackPath="/dashboard" />
        <h1 className="text-3xl font-bold flex items-center">
          <Users className="mr-3 h-8 w-8 text-primary" /> Create Player Requirement
        </h1>
      </div>
      <CreateRequirementForm />
    </div>
  );
};

export default CreateRequirementPage;
