
import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';

const TermsPage: React.FC = () => {
  return (
    <div className="animate-fade-in-up max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-6">Terms & Conditions</h1>
      
      <Card>
        <CardContent className="prose prose-sm max-w-none p-6">
          <h2 className="text-xl font-semibold mb-4">Acceptance of Terms</h2>
          <p className="mb-4">
            By accessing and using SportSphere, you accept and agree to be bound by the terms 
            and provision of this agreement.
          </p>

          <h2 className="text-xl font-semibold mb-4">User Accounts</h2>
          <p className="mb-4">
            You are responsible for maintaining the confidentiality of your account and password 
            and for restricting access to your account.
          </p>

          <h2 className="text-xl font-semibold mb-4">Event Participation</h2>
          <p className="mb-4">
            Users participate in events at their own risk. SportSphere is not liable for any 
            injuries or damages that may occur during events.
          </p>

          <h2 className="text-xl font-semibold mb-4">User Conduct</h2>
          <p className="mb-4">
            Users must conduct themselves in a respectful manner and follow all community guidelines. 
            Inappropriate behavior may result in account suspension.
          </p>

          <h2 className="text-xl font-semibold mb-4">Limitation of Liability</h2>
          <p className="mb-4">
            SportSphere shall not be liable for any indirect, incidental, special, consequential, 
            or punitive damages.
          </p>

          <h2 className="text-xl font-semibold mb-4">Contact</h2>
          <p>
            For questions about these Terms & Conditions, contact us at legal@sportsphere.com
          </p>
        </CardContent>
      </Card>
    </div>
  );
};

export default TermsPage;
