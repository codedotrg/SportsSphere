
import React from 'react';
import { Plus, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import CreateEventForm from '@/components/CreateEventForm';
import { BackButton } from '@/components/navigation/BackButton';

const CreateEventPage: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="animate-fade-in-up">
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center space-x-4">
          <BackButton fallbackPath="/events" />
          <h1 className="text-3xl font-bold flex items-center">
            <Plus className="mr-3 h-8 w-8 text-primary" /> Create Event
          </h1>
        </div>
        <Button onClick={() => navigate('/create-requirement')} variant="outline">
          <Users className="mr-2 h-4 w-4" />
          Create Player Requirements
        </Button>
      </div>
      <CreateEventForm />
    </div>
  );
};

export default CreateEventPage;
